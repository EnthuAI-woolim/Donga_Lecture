#include <stdio.h>
#include <stdlib.h>

#define NODE_NUM 10

int main() {
    // Input (Weighted Adjacency Matrix)

    char nodes[NODE_NUM][10] = {"서울", "강릉", "천안", "원주", "대전", "논산", "광주", "대구", "포항", "부산"};

    int D[NODE_NUM][NODE_NUM] = {
    //   0  1  2  3  4  5  6  7  8  9
        {0, 0, 12, 15, 0, 0, 0, 0, 0, 0},   // ����
        {0, 0, 0, 21, 0, 0, 0, 0, 25, 0},   // ����
        {12, 0, 0, 0, 10, 4, 0, 0, 0, 0},  // õ��
        {15, 21, 0, 0, 0, 0, 0, 7, 0, 0},   // ����
        {0, 0, 10, 0, 0, 3, 0, 10, 0, 0},     // ����
        {0, 0, 4, 0, 3, 0, 13, 0, 0, 0},     // ����
        {0, 0, 0, 0, 0, 13, 0, 0, 0, 15},     // ����
        {0, 0, 0, 7, 10, 0, 0, 0, 19, 9},     // �뱸
        {0, 25, 0, 0, 0, 0, 0, 19, 0, 5},     // ����
        {0, 0, 0, 0, 0, 0, 15, 9, 5, 0}         // �λ�
    };

    // int D[NODE_NUM][NODE_NUM] = {-1};

    // ����� s�� �ʱ�ȭ
    int start = 0;  // ����


    for (int k = 0; k < NODE_NUM; k++) { 
		for (int i = 0; i < NODE_NUM ; i++) {
			if(i == k)
				continue;
			for(int j = 0; j < NODE_NUM; j++) {
				if(j == k || j == i)
					continue;
				
//				printf("D[%d][%d] = %d\n", i, j, D[i][j]);
				if (D[i][k] == 0 || D[k][j] == 0)
					continue;
	
				if (D[i][k] + D[k][j] < D[i][j] || D[i][j] == 0) {
					D[i][j] = D[i][k] + D[k][j];
					D[j][i] = D[i][k] + D[k][j];
				}
			}
		}
	}
				
    printf("\t  ");
    for(int i = 0; i < NODE_NUM; i = i + 1) { 
        printf("%s\t", nodes[i]);
    }
    printf("\n");
    for(int i = 0; i < NODE_NUM; i = i + 1) {
        printf("%s\t: ", nodes[i]);
        for(int j = 0; j < NODE_NUM; j = j + 1) {
            if (j > i)
                printf("%d\t", D[i][j]);
            else
                printf("\t");
        }
        printf("\n");
    }

}


    


