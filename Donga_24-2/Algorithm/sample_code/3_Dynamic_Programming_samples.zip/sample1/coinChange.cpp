#include <stdio.h>
#include <cstring>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define NUM_COIN 4
#define MONEY 20

int main() { 
    int d[NUM_COIN+1] = {0, 16, 10, 5, 1};
    int C[MONEY+1] = {0};
    for (int j = 1; j <= MONEY; j++) {
        C[j] = INT8_MAX; 
    }

    for(int j = 1; j <= MONEY; j++) { 
        for(int i = 1; i <= NUM_COIN; i++) {
            if (d[i] <= j && C[j-d[i]]+1 < C[j]) {
                C[j] = C[j-d[i]] + 1;
            }
        }
    }


    for(int j = 0; j <= MONEY; j++) { 
        if (j == 0)
            cout << 'j' << "\t";
        cout << j << "\t";
    }
    cout << endl;
    for(int j = 0; j <= MONEY; j++) { 
        if (j == 0)
            cout << 'c' << "\t";
        cout << C[j] << "\t";
    }
    cout << endl;
}