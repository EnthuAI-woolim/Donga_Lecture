#include <stdio.h>
#include <cstring>
#include <iostream>
#include <fstream>
using namespace std;

#define MATRIX_NUM 10

void mergeSort(int* arr, int size);
void writeArray(int* arr, int size, ofstream &fout);

int main() {
    int *input = new int;

	// Read input file
    ifstream fin;

    fin.open("./matrix_input.txt");

    char ident;
    int temp = 0;
    int leftCount = 0;
    int rightCount = 0;
    bool done = false;
    bool readCol = false;

    int rowCount = 0;
    int colCount = 0;

    int matrixNum = 0;

    int d[10];

    while(fin >> ident) {
    
        if(ident == '[') {
            leftCount++;
            colCount = 0;
            rightCount=0;
        }
        else if (ident == ']') {
            rightCount++;
            leftCount--;
            if(rightCount==2) {
                d[matrixNum++] = rowCount;
                d[matrixNum] = colCount;
                rowCount = 0;
            }
            else if(rightCount== 1) {
                rowCount++;
            }
        }
        else{
            if (ident == '-' || isdigit(ident)) {
                fin.putback(ident); 
                fin >> temp;
                colCount++;
            }
        }

    }
    d[matrixNum] = colCount;

    int C[matrixNum+1][matrixNum+1];
    memset(C, 0, sizeof(C));


    int j = 0;
    for (int L = 1; L < matrixNum; L++) { 
        for (int i = 1; i <= matrixNum - L; i++) { 
            j = i + L;
            C[i][j] = 0;   // 부분문제 크기 L만큼 오른쪽의 행렬 Aj와 사이에 곱셈 횟수
            for (int k = i; k < j; k++) { 
                temp = C[i][k] + C[k+1][j] + d[i-1]*d[k]*d[j];
                if(temp < C[i][j] || C[i][j] == 0)
                    C[i][j] = temp;
            }
        }
    }

    for(int j = 0; j <= matrixNum; j++) {
        cout << j << "\t";
    }
    cout << endl;
    for (int i = 0; i < matrixNum; i++) {
        for(int j = 0; j < matrixNum; j++) {
            if(j == 0)
                cout << i+1 << "\t";
            if(i <= j)
                cout << C[i+1][j+1] << "\t";
            else
                cout << "\t";
        }
        cout << endl;
    }

    cout << "최소 곱셈 횟수: " << C[1][matrixNum] << endl;
    
}