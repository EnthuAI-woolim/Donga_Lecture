// package quickSort;

import java.io.*;
import java.util.*;


public class editDistance {
    public static void main(String[] args) throws Exception {

        int m = 6;
        int n = 5;
        String S = "strong";
        String T = "stone";


        int E[][] = new int[m + 1][n + 1];

        for(int i = 0; i <= S.length(); i++) {
            E[i][0] = i;            // 0번 열의 초기화 (삭제 횟수)
        }
        for(int j = 0; j <= T.length(); j++) {
            E[0][j] = j;            // 0번 행의 초기화 (삽입 횟수)
        }

        int alpha = 0;
        for(int i = 1; i <= S.length(); i++) {
            for(int j = 1; j <= T.length(); j++) { 
                alpha = 0;
                E[i][j] = Math.min(E[i][j-1]+1, E[i-1][j]+1);
                if(S.charAt(i-1) != T.charAt(j-1)) {
                    alpha=1;
                }
                E[i][j] = Math.min(E[i][j], E[i-1][j-1]+alpha);
            }
        }

        // 결과 출력
        for(int i = 0; i <= S.length(); i++) {
            for(int j = 0; i == 0 && j <= T.length(); j++) { 
                if(i == 0 && j == 0)
                    System.out.printf("i\\j" + "\t");
                System.out.printf(j + "\t");
            }
            System.out.printf("\n");
            for(int j = 0; j <= T.length(); j++) { 
                if(j == 0)
                    System.out.printf(i + "\t");
                System.out.printf(E[i][j] + "\t");
            }
        }
        System.out.printf("\n");
    }
}
