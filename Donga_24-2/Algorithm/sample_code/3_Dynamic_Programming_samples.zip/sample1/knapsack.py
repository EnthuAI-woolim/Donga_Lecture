import numpy as np

if __name__ == '__main__': 
    weights = [5, 4, 6, 3]
    values = [10, 40, 30, 50]
    C = 10

    n = len(weights)
    
    K = np.zeros((n+1, C+1))

    for i in range(1, n+1):
        for w in range(1, C+1):
            if weights[i-1] > w:
                K[i, w] = K[i-1, w]
            else:
                K[i, w] = max(K[i-1, w], K[i-1, w-weights[i-1]] + values[i-1])


    # 결과 출력
    print('\t배낭용량 -> w=\t', end=' |\t')
    for i in range(C+1):
        print(i, end='\t')
    print()
    print('물건\t가치\t용량\t', end=' |\t')
    for i in range(C+1):
        print(0, end='\t')
    print()
    for i in range(C+1):
        print('-----------', end='')
    print()
    for i in range(1, n+1):
        print(f'{i}\t{weights[i-1]}\t{values[i-1]}\t', end=' |\t')
        for w in range(C+1):
            print(int(K[i, w]), end='\t')
        print()