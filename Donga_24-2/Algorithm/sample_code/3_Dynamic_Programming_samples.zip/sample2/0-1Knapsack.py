def knapsack(C, weights, values, n):
    # DP 테이블 초기화 (물건의 수 + 1) x (배낭 용량 + 1)
    dp = [[0 for x in range(C + 1)] for x in range(n + 1)]

    # DP 테이블 채우기
    for i in range(1, n + 1):
        for w in range(1, C + 1):
            if weights[i - 1] <= w:  # 현재 물건을 배낭에 넣을 수 있는 경우
                dp[i][w] = max(dp[i - 1][w], dp[i - 1][w - weights[i - 1]] + values[i - 1])
            else:  # 현재 물건을 배낭에 넣을 수 없는 경우
                dp[i][w] = dp[i - 1][w]

    # DP 테이블 출력
    print("배낭 용량 -> W=", end=" ")
    for w in range(C + 1): 
        print(f"{w:<3}", end="") 
    print()
    
    print(f"{'무게':<5}{'가치':<5}{'물건':<6}", end="")
    print("0  " * (C + 1)) 
    
    for i in range(1, n + 1): 
            print(f"{weights[i - 1]:<7}{values[i - 1]:<7}{i:<8}", end="")
            for w in range(C + 1): 
                print(f"{dp[i][w]:<3}", end="") 
            print()
            
    return dp[n][C]

# 예제 입력
C = 10  # 배낭 용량
weights = [5, 4, 6, 3]  # 각 물건의 무게
values = [10, 40, 30, 50]   # 각 물건의 가치
n = len(values)  # 물건의 개수

# 알고리즘 실행 및 결과 출력
max_value = knapsack(C, weights, values, n)
