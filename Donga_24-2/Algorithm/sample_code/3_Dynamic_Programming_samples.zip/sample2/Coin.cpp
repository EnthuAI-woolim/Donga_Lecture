#include <iostream>
#include <iomanip>
#include <climits>

using namespace std;

void coinChangeTable(const int coins[], int numCoins, int amount) {
    // DP 배열
    int dp[amount + 1];

    // 배열 초기화
    for (int i = 0; i <= amount; ++i) {
        dp[i] = (i == 0) ? 0 : INT_MAX; // 금액 0일 때는 동전이 필요 없음
    }

    // DP 알고리즘 구현
    for (int i = 0; i < numCoins; ++i) {
        for (int j = coins[i]; j <= amount; ++j) {
            if (dp[j - coins[i]] != INT_MAX) {
                dp[j] = min(dp[j], dp[j - coins[i]] + 1);
            }
        }
    }

    // 테이블 출력
    cout << "j ";
    for (int j = 0; j <= amount; ++j) {
        cout << setw(3) << j;
    }
    cout << endl;

    cout << "c ";
    for (int j = 0; j <= amount; ++j) {
        if (dp[j] == INT_MAX)
            cout << setw(3) << "-";
        else
            cout << setw(3) << dp[j];
    }
    cout << endl;
}

int main() {
    int coins[] = {1, 5, 10, 16};
    int numCoins = sizeof(coins) / sizeof(coins[0]);
    int amount = 20;

    coinChangeTable(coins, numCoins, amount);

    return 0;
}
