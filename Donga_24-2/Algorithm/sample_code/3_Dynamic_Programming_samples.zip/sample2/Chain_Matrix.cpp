#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <climits>
#include <iomanip>
using namespace std;

// 열 count
int countCol(const string &line) {
    int cols = 0;
    bool inValue = false;

    for (char c : line) {
        // 공백, 띄어쓰기, [ 제외
        if (c != ' ' && !inValue && c != '[') {
            inValue = true;
            cols+=1;
        } else if (c == ' ') {
            inValue = false;
        }
    }
    return cols;
}

// input의 행과 열 계산
vector<pair<int, int>> readInput(const string &filename) {
    ifstream file(filename);
    vector<pair<int, int>> dimensions;  // 행렬 저장 변수
    string line;
    int rows = 0, cols = 0;
    bool isMatrix = false;

    while (getline(file, line)) {
        if (line.find('=') != string::npos) { // '='을 만나면 새로운 행렬 시작
            if (isMatrix) {
                dimensions.emplace_back(rows, cols); // 이전 행렬 저장
            }
            // 초기화
            rows = 0;
            cols = 0;
            isMatrix = true;
        } else if (isMatrix) {
            if (cols == 0) {  // 첫 줄에서 열 개수 계산
                cols = countCol(line);
            }
            ++rows; // 행 증가
        }
    }

    // 마지막 행렬 크기 저장
    if (isMatrix) {
        dimensions.emplace_back(rows, cols); // Adjust column count here
    }

    file.close();
    
    return dimensions;
}

// 행렬의 최소 연산 횟수 계산
void chainMatrix(const vector<pair<int, int>> &dimensions) {
    int n = dimensions.size();
    vector<vector<int>> dp(n, vector<int>(n, 0)); // 최소 연산 횟수 저장 테이블
    vector<vector<int>> split(n, vector<int>(n, 0));

    // 계산
    for (int length = 2; length <= n; ++length) {
        for (int i = 0; i <= n - length; ++i) {
            int j = i + length - 1;
            dp[i][j] = INT_MAX;
            for (int k = i; k < j; ++k) {
                int cost = dp[i][k] + dp[k + 1][j] + dimensions[i].first * dimensions[k].second * dimensions[j].second;
                if (cost < dp[i][j]) {
                    dp[i][j] = cost;
                    split[i][j] = k;
                }
            }
        }
    }

    // 결과 출력
    cout << setw(5) << "C";
    for (int i = 1; i <= n; ++i) {
      cout << setw(10) << i;
    }
    cout << endl;
    for (int i = 0; i < n; ++i) {
      cout << setw(5) << i + 1;
      for (int j = 0; j < n; ++j) {
        if (j < i) { 
          cout << setw(10) << " "; 
        } else { 
          cout << setw(10) << dp[i][j]; 
        } 
      } 
      cout << endl; 
    } 
}

int main() {
    string filename = "matrix_input.txt";
    // 파일 읽기
    vector<pair<int, int>> dimensions = readInput(filename);

    chainMatrix(dimensions);
    return 0;
}
