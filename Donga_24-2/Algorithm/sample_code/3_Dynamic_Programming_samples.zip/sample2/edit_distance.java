package Edit_Distance;

public class edit_distance {

	// 편집 거리 표를 계산하고 출력하는 메서드
    public static void calculateEditDistance(String str1, String str2) {
        int m = str1.length();
        int n = str2.length();
        int[][] dp = new int[m + 1][n + 1];

        // 초기화
        for (int i = 0; i <= m; i++) {
            dp[i][0] = i; // 삭제 연산만으로 변환
        }
        for (int j = 0; j <= n; j++) {
            dp[0][j] = j; // 삽입 연산만으로 변환
        }

        // 동적 프로그래밍을 통한 편집 거리 계산
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1]; // 문자 동일할 경우 대체 없이 이동
                } else {
                    dp[i][j] = Math.min(dp[i - 1][j - 1], // 대체
                            Math.min(dp[i - 1][j], // 삭제
                                    dp[i][j - 1])) + 1; // 삽입
                }
            }
        }

        // 결과 출력
        printEditDistanceTable(dp, str1, str2);
    }

    // 편집 거리 표를 출력하는 메서드
    public static void printEditDistanceTable(int[][] dp, String str1, String str2) {
    	 int cellWidth = 3;
    	 System.out.printf("%" + cellWidth + "s", " ");
        for (int j = 0; j <= str2.length(); j++) {
            if (j > 0) System.out.printf("%" + cellWidth + "c", str2.charAt(j - 1));
            else System.out.printf("%" + cellWidth + "s", " ");
        }
        System.out.println();

        for (int i = 0; i <= str1.length(); i++) {
            if (i > 0) System.out.printf("%" + cellWidth + "c", str1.charAt(i - 1));
            else System.out.printf("%" + cellWidth + "s", " ");
            for (int j = 0; j <= str2.length(); j++) {
            	System.out.printf("%" + cellWidth + "d", dp[i][j]);
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        String str1 = "strong";
        String str2 = "stone";

        calculateEditDistance(str1, str2);
    }

}
