#include <stdio.h>
#include <time.h>
#define INF 99999
#define V 10
int dist[V][V];

// 결과 출력
void printSolution(int dist[][V]) {
    char *city_names[V] = {"서울", "천안", "논산", "대전", "원주", "강릉", "대구", "포항", "부산", "광주"};

    printf("     ");
    for (int i = 0; i < V; i++)
    {
        printf("%6s ", city_names[i]);
    }
    printf("\n");

    for (int i = 0; i < V; i++)
    {
        printf("%6s ", city_names[i]);
        for (int j = 0; j < V; j++)
        {
            if (j < i)
            {
                printf("     ");
            }
            else if (dist[i][j] == INF)
            {
                printf(" INF ");
            }
            else
            {
                printf(" %3d ", dist[i][j]);
            }
        }
        printf("\n");
    }
}

// Floyd Warshall 알고리즘 구현
void floydWarshall(int graph[][V]) {
    for (int i = 0; i < V; i++)
        for (int j = 0; j < V; j++)
            dist[i][j] = graph[i][j];

    for (int k = 0; k < V; k++) {
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                if (dist[i][k] + dist[k][j] < dist[i][j])
                    dist[i][j] = dist[i][k] + dist[k][j];
            }
        }
    }
}

int main() {
    // 입력 그래프
    int graph[V][V] = {
        {0, 12, INF, INF, 15, INF, INF, INF, INF, INF},
        {12, 0, 4, 10, INF, INF, INF, INF, INF, INF},
        {INF, 4, 0, 3, INF, INF, INF, INF, INF, 13},
        {INF, 10, 3, 0, INF, INF, 10, INF, INF, INF},
        {15, INF, INF, INF, 0, 21, 7, INF, INF, INF},
        {INF, INF, INF, INF, 21, 0, INF, 25, INF, INF},
        {INF, INF, INF, 10, 7, INF, 0, 19, 9, INF},
        {INF, INF, INF, INF, INF, 25, 19, 0, 5, INF},
        {INF, INF, INF, INF, INF, INF, 9, 5, 0, 15},
        {INF, INF, 13, INF, INF, INF, INF, INF, 15, 0}
    };
    
    clock_t sT, eT;

    sT = clock();
    floydWarshall(graph);
    eT = clock();
    
    printSolution(dist);
    printf("Running time: %.3f ms\n", ((double)(eT - sT)) / CLOCKS_PER_SEC * 1000);

    return 0;
}
