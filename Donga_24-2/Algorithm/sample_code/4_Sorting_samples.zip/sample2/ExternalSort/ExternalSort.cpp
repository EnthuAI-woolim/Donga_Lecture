#include <iostream>
#include <fstream>

#define ASSIST_N 1000
#define MEM_MAX 100

void initialSort(int* arr); // 내부 정렬
void Insertion(int* arr, int n); // 내부 정렬 method

void mergeAndSort(int* arr, int start, int end);
void merge(int* arr); // 합병

int main(void) {
    // txt 파일 읽기
    std::string ifname = "input.txt";
    std::string ofname = "external_output.txt";
    std::ifstream file(ifname);

    // 배열 생성
    int arr[ASSIST_N]; // 보조 메모리

    // 동적으로 배열의 크기를 늘리면서 입력 받음
    int number;
    int n = 0;
    while(file >> number) {
        arr[n] = number;
        n++;
    }
    file.close();

    initialSort(arr);
    
    merge(arr);

    std::ofstream ofile(ofname);
    for (int i = 0; i < ASSIST_N; i++) {
        ofile << arr[i] << "\n";
    }
    ofile.close();

    return 0;
}

void initialSort(int* arr) {
    int indicator = 0;
    for (int i = 0; i < ASSIST_N / MEM_MAX; i++) {
        int *main_mem = new int[MEM_MAX];

        // 주 메모리에 최초 메모리로부터 가져오기
        int idx = 0;
        for (int j = indicator; j < indicator + MEM_MAX; j++) {
            main_mem[idx] = arr[j];
            idx++;
        }

        Insertion(main_mem, MEM_MAX); // 정렬

        // 보조 메모리에 저장
        idx = 0;
        for (int j = indicator; j < indicator + MEM_MAX; j++) {
            arr[j] = main_mem[idx];
            idx++;
        }

        delete [] main_mem;
        indicator += MEM_MAX;
    }
}

void Insertion(int* arr, int n) {
    for (int i = 1; i < n; i++) {
        int cur = arr[i];
        int j = i - 1;

        while (j >= 0 && arr[j] > cur) {
            arr[j+1] = arr[j];
            j = j - 1;
        }
        arr[j+1] = cur;
    }
}

void mergeAndSort(int* arr, int start, int end) {
    int size = end - start;
    int *merged = new int[size];
    
    int mid = start + size / 2;
    int i = start, j = mid, k = 0;

    while (i < mid && j < end) {
        if (arr[i] < arr[j]) {
            merged[k++] = arr[i++];
        } else {
            merged[k++] = arr[j++];
        }
    }

    while (i < mid) {
        merged[k++] = arr[i++];
    }

    while (j < end) {
        merged[k++] = arr[j++];
    }

    for (int i = 0; i < size; i++) {
        arr[start + i] = merged[i];
    }

    delete[] merged;
}

void merge(int* arr) {
    int size = MEM_MAX;
    while (size < ASSIST_N) {
        int start = 0;
        while (start < ASSIST_N) {
            int end = std::min(start + 2 * size, ASSIST_N);
            mergeAndSort(arr, start, end);
            start += 2 * size;
        }
        size *= 2;
    }

    if (size / 2 < ASSIST_N) {
        int *merged = new int[ASSIST_N];
        
        int mid = size / 2;
        int i = 0, j = mid, k = 0;

        while (i < mid && j < ASSIST_N) {
            if (arr[i] < arr[j]) {
                merged[k++] = arr[i++];
            } else {
                merged[k++] = arr[j++];
            }
        }

        while (i < mid) {
            merged[k++] = arr[i++];
        }

        while (j < ASSIST_N) {
            merged[k++] = arr[j++];
        }

        for (int i = 0; i < ASSIST_N; i++) {
            arr[i] = merged[i];
        }

        delete[] merged;
    }
}
