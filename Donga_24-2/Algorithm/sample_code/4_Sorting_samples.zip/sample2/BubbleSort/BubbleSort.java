import java.io.*;
import java.util.ArrayList;

public class BubbleSort {
    public static void main(String[] args) throws IOException {
        // Read File
        BufferedReader reader = new BufferedReader(new FileReader("./input.txt"));

        String line;
        ArrayList<Integer> array = new ArrayList<Integer>();
        while ((line = reader.readLine()) != null) {
            array.add((int)Integer.parseInt(line));
        }
        reader.close();

        // Sorting
        BS bs = new BS();
        array = bs.Sorting(array);

        // Write Result on File
        FileOutputStream fileOutputStream = new FileOutputStream(new File("bubble_output.txt"));
        for (int i: array) {
            fileOutputStream.write((Integer.toString(i) + '\n').getBytes());
        }
        fileOutputStream.close();
    }
}

class BS {
    public ArrayList<Integer> Sorting(ArrayList<Integer> arr) {
        for (int i = 0; i < arr.size()-1; i++) {
            for (int j = 1; j < arr.size()-i; j++) {
                if ((Integer)arr.get(j-1) > (Integer)arr.get(j)) {
                    int temp = (Integer)arr.get(j);
                    arr.set(j, (Integer)arr.get(j-1));
                    arr.set(j-1, temp);
                }
            }
        }

        return arr;
    }
}