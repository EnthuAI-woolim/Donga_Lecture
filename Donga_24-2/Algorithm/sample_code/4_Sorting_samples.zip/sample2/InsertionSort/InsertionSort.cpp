#include <iostream>
#include <fstream>

void Insertion(int* arr, int n);

int main(void) {
    // txt 파일 읽기
    std::string ifname = "input.txt";
    std::string ofname = "insertion_output.txt";
    std::ifstream file(ifname);

    // 배열 생성 (동적 할당)
    int *arr = new int[1];

    // 동적으로 배열의 크기를 늘리면서 입력 받음
    int capacity = 1, size = 0, number = 0;
    while(file >> number) {
        if (capacity < size) {
            int* newArray = new int[capacity * 2];
            capacity *= 2;
            for(int i = 0; i < size; i++) {
                newArray[i] = arr[i];
            }
            delete [] arr;
            arr = newArray;
            newArray = NULL;
        }
        arr[size] = number;
        size++;
    }
    file.close();

    Insertion(arr, size);

    // 텍스트 파일에 결과 저장
    std::ofstream ofile(ofname);
    for (int i = 0; i < size; i++) {
        ofile << arr[i] << "\n";
    }
    ofile.close();

    return 0;
}

void Insertion(int* arr, int n) {
    for (int i = 1; i < n; i++) {
        int cur = arr[i];
        int j = i - 1;

        while (j >= 0 && arr[j] > cur) {
            arr[j+1] = arr[j];
            j = j - 1;
        }
        arr[j+1] = cur;
    }
}