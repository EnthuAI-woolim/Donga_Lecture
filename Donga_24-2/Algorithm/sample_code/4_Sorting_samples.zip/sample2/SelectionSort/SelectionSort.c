#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void selectionSort(int* arr, int n);

int main(void) {
    int size = 0;
    int capacity = 1;
    int *arr = (int*)malloc(sizeof(int) * capacity);
    if (arr == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return 1;
    }

    // 파일 입력
    FILE *fp = fopen("./input.txt", "r");
    if (fp == NULL) {
        fprintf(stderr, "Failed to open file\n");
        free(arr);
        return 1;
    }

    int input = 0;
    while (fscanf(fp, "%d", &input) != EOF) {
        if (size >= capacity) {
            capacity *= 2;
            int *temp = realloc(arr, sizeof(int) * capacity);
            if (temp == NULL) {
                fprintf(stderr, "Memory reallocation failed\n");
                free(arr);
                fclose(fp);
                return 1;
            }
            arr = temp;
        }

        arr[size] = input;
        size++;
    }
    fclose(fp);

    // Selection Sort 실행
    selectionSort(arr, size);

    // 텍스트 파일에 출력
    FILE *fout = fopen("./selection_output.txt", "w");
    if (fout == NULL) {
        fprintf(stderr, "Failed to open file\n");
        free(arr);
        return 1;
    }

    for (int i = 0; i < size; i++) {
        fprintf(fout, "%d\n", arr[i]);
    }

    fclose(fout);

    free(arr);
    return 0;
}

void selectionSort(int* arr, int n) {
    int min = INT_MAX;
    for (int i = 0; i < n; i++) {
        min = i;
        // 최소값 탐색
        for (int j = i+1; j < n; j++) {
            if (arr[j] < arr[min]) {
                min = j;
            }
        }
        // 최소값을 앞자리로 변경
        int temp = arr[i];
        arr[i] = arr[min];
        arr[min] = temp;
    }
}