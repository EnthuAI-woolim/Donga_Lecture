#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>

void heapSort(int* arr, int n);

void buildHeap(int* arr, int n);
void downHeap(int* arr, int i, int n);

int main(void) {
    int size = 0;
    int capacity = 1;
    int *arr = (int*)malloc(sizeof(int) * capacity);
    if (arr == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return 1;
    }

    // 파일 입력
    FILE *fp = fopen("./input.txt", "r");
    if (fp == NULL) {
        fprintf(stderr, "Failed to open file\n");
        free(arr);
        return 1;
    }

    int input = 0;
    while (fscanf(fp, "%d", &input) != EOF) {
        if (size >= capacity) {
            capacity *= 2;
            int *temp = realloc(arr, sizeof(int) * capacity);
            if (temp == NULL) {
                fprintf(stderr, "Memory reallocation failed\n");
                free(arr);
                fclose(fp);
                return 1;
            }
            arr = temp;
        }

        arr[size] = input;
        size++;
    }
    fclose(fp);

    heapSort(arr, size);

    // 텍스트 파일에 결과 저장
    FILE *fout = fopen("./heap_output.txt", "w");
    if (fout == NULL) {
        fprintf(stderr, "Failed to open file\n");
        free(arr);
        return 1;
    }

    for (int i = 0; i < size; i++) {
        fprintf(fout, "%d\n", arr[i]);
    }

    fclose(fout);

    free(arr);
    return 0;
}

void heapSort(int* arr, int n) {
    buildHeap(arr, n);
    int heapSize = n-1;

    // printf("%d %d\n", arr[0], arr[heapSize]);

    for (int i = heapSize; i > 0; i--) {
        int temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;
        
        heapSize--;
        // printf("%d %d\n", heapSize, arr[heapSize]);
        downHeap(arr, 0, heapSize);
    }
}

void buildHeap(int* arr, int n) {
    for (int i = n / 2 - 1; i >= 0; i--) {
        downHeap(arr, i, n-1);
    }
}

void downHeap(int* arr, int i, int n) {
    int leftChild = 2 * i + 1;
    int rightChild = 2 * i + 2;
    int bigger = i;

    if ((leftChild <= n) && (arr[leftChild] > arr[i])) {
        bigger = leftChild;
    } else {
        bigger = i;
    }

    if ((rightChild <= n) && (arr[rightChild] > arr[bigger])) {
        bigger = rightChild;
    }

    if (bigger != i) {
        int temp = arr[i];
        arr[i] = arr[bigger];
        arr[bigger] = temp;

        downHeap(arr, bigger, n);
    }
}