#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

void LSD(int* arr, int n, int k);
void MSD(int* arr, int n, int k);

void LSDcountingSort(std::string* str_arr, int n, int j);
void MSDcountingSort(std::vector<std::string>& str_arr, int left, int right, int pos);

int main(void) {
    // txt 파일 읽기
    std::string ifname = "input.txt";
    std::string lsdfname = "radix_lsd_output.txt";
    std::string msdfname = "radix_msd_output.txt";
    std::ifstream file(ifname);

    // 배열 생성 (동적 할당)
    int *arr = new int[1];

    // 동적으로 배열의 크기를 늘리면서 입력 받음
    int capacity = 1, size = 0, number = 0;
    int maxk = 0;
    while(file >> number) {
        if (capacity < size) {
            int* newArray = new int[capacity * 2];
            capacity *= 2;
            for(int i = 0; i < size; i++) {
                newArray[i] = arr[i];
            }
            delete [] arr;
            arr = newArray;
            newArray = NULL;
        }
        std::string temp = std::to_string(number);
        if (temp.size() > maxk) maxk = temp.size();
        arr[size] = number;
        size++;
    }
    file.close();

    int *arr2 = new int[size];
    for (int i = 0; i < size; i++) {
        arr2[i] = arr[i];
    }

    LSD(arr, size, maxk);
    MSD(arr2, size, maxk);

    // 텍스트 파일에 결과 저장
    std::ofstream ofile(lsdfname);
    for (int i = 0; i < size; i++) {
        ofile << arr[i] << "\n";
    }
    ofile.close();

    std::ofstream ofile2(msdfname);
    for (int i = 0; i < size; i++) {
        ofile2 << arr2[i] << "\n";
    }
    ofile2.close();
}

void LSDcountingSort(std::string* str_arr, int n, int j) {
    std::string output[n];
    int count[10] = {0};

    // Count the occurrences of each digit
    for (int i = 0; i < n; i++) {
        int digit = str_arr[i][j] - '0';
        count[digit]++;
    }

    // Calculate cumulative count
    for (int i = 1; i < 10; i++) {
        count[i] += count[i - 1];
    }

    // Build the output array in stable order
    for (int i = n - 1; i >= 0; i--) {
        int digit = str_arr[i][j] - '0';
        output[count[digit] - 1] = str_arr[i];
        count[digit]--;
    }

    // Copy the sorted strings back to str_arr
    for (int i = 0; i < n; i++) {
        str_arr[i] = output[i];
    }
}

void LSD(int* arr, int n, int k) {
    std::string str_arr[n];
    for (int i = 0; i < n; i++) {
        std::string temp = std::to_string(arr[i]);
        int r = k - temp.size();
        std::string prefix = "";
        for (int j = 0; j < r; j++) {
            prefix += "0";
        }
        temp = prefix + temp;
        str_arr[i] = temp;
    }

    std::string temp_arr[n];

    for (int i = k-1; i >= 0; i--) {
        LSDcountingSort(str_arr, n, i);
    }

    for (int i = 0; i < n; i++) {
        arr[i] = std::stoi(str_arr[i]);
    }
}

void MSDcountingSort(std::vector<std::string>& str_arr, int left, int right, int pos) {
    if (left >= right || pos >= str_arr[0].size()) {
        return;
    }

    // Counting sort을 수행하기 위해 0-9까지의 bucket을 만듭니다.
    std::vector<std::vector<std::string>> buckets(10);

    // 각 문자열의 현재 자리수(pos)를 기준으로 bucket에 문자열을 분배합니다.
    for (int i = left; i <= right; i++) {
        int digit = str_arr[i][pos] - '0';
        buckets[digit].push_back(str_arr[i]);
    }

    // 원래 배열에 bucket의 내용을 다시 합칩니다.
    int index = left;
    for (int i = 0; i < 10; i++) {
        for (const auto& str : buckets[i]) {
            str_arr[index++] = str;
        }
    }

    // 각 bucket에 대해 재귀적으로 정렬합니다.
    index = left;
    for (int i = 0; i < 10; i++) {
        if (!buckets[i].empty()) {
            MSDcountingSort(str_arr, index, index + buckets[i].size() - 1, pos + 1);
            index += buckets[i].size();
        }
    }
}

void MSD(int* arr, int n, int k) {
    std::vector<std::string> str_arr(n);
    for (int i = 0; i < n; i++) {
        std::string temp = std::to_string(arr[i]);
        int r = k - temp.size();
        std::string prefix(r, '0');
        temp = prefix + temp;
        str_arr[i] = temp;
    }

    MSDcountingSort(str_arr, 0, n - 1, 0);

    for (int i = 0; i < n; i++) {
        arr[i] = std::stoi(str_arr[i]);
    }
}