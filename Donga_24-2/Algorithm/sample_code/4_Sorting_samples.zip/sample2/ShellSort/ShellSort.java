import java.io.*;
import java.util.ArrayList;

public class ShellSort {
    public static void main(String[] args) throws IOException {
        // Read File
        BufferedReader reader = new BufferedReader(new FileReader("./input.txt"));

        String line;
        ArrayList<Integer> array = new ArrayList<Integer>();
        while ((line = reader.readLine()) != null) {
            array.add((int)Integer.parseInt(line));
        }
        reader.close();

        // Sorting
        SS ss = new SS();
        array = ss.Sorting(array);

         // Write Result on File
         FileOutputStream fileOutputStream = new FileOutputStream(new File("shell_output.txt"));
         for (int i: array) {
             fileOutputStream.write((Integer.toString(i) + '\n').getBytes());
         }
         fileOutputStream.close();
    }
}

class SS {
    public ArrayList<Integer> Sorting(ArrayList<Integer> arr) {
        for (int h = 100; h >= 1; h /= 2) {
            for (int i = h; i < arr.size(); i++) {
                int cur = (Integer)arr.get(i);
                int j = i;

                while (j >= h && (Integer)arr.get(j - h) > cur) {
                    arr.set(j, (Integer)arr.get(j - h));
                    j = j - h;
                }

                arr.set(j, cur);
            }
        }
        return arr;
    }
}