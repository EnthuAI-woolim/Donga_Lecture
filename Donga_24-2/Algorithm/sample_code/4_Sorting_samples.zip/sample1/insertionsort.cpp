#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int main() {
    vector<int> numbers;
    int num;

    // input.txt 파일 읽기
    ifstream input("input.txt");
    if (!input.is_open()) {
        cout << "파일을 열 수 없습니다." << endl;
        return 1;
    }

    // 파일에서 숫자를 읽어서 vector에 저장
    while (input >> num) {
        numbers.push_back(num);
    }
    input.close();
    
    // 1번째부터 시작
    for (int i = 1; i < numbers.size(); i++) { 
        int current_index = i;
        int current = numbers[i];
        int before = current_index - 1;
        int insertion_point = 0;  // 삽입 위치를 저장할 변수
        
        // 이전 원소들과 비교하면서 삽입 위치 찾기
        for(int j = before; j >= 0; j--) { 
            if(numbers[j] > current) {
                numbers[j + 1] = numbers[j];    // 큰 값을 오른쪽으로 밀기
            } else {
                insertion_point = j + 1;
                break;  // 적절한 위치를 찾았으면 중단
            }
        }
        numbers[insertion_point] = current;  // 찾은 위치에 현재 값을 삽입
    }
    // 정렬된 결과를 출력하는 코드 추가
    for(int i = 0; i < numbers.size(); i++) {
        cout << numbers[i] << " ";
    }

    // insertion_output.txt 파일 출력
    ofstream output("insertion_output.txt");
    for(int i = 0; i < numbers.size(); i++) {
        output << numbers[i] << " ";
    }
    output.close();
    cout << endl;

    return 0;
}