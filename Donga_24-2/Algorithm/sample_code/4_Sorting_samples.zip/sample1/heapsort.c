#include <stdio.h>
#define MAX_HEAP_SIZE 1001
/*
C언어는 인덱스 위치에 값이 없어도 자동으로 NULL 처리 안 해주기 때문에
쓰레기 값을 넣는다. 
따라서 자식 노드가 없는지 있는지 확인할때는 
right_c <= heapsize 처럼 현재 자식노드의 인덱스가 힙사이즈보다 작다면 자식이 존재한다고 가정한다. 아래는 예시
예시) heapsize = 5인 경우:
       1
     /   \
    2     3
   / \
  4   5

각 노드별로 getRightChild() 결과를 보면:
1. 노드 1: getRightChild(1) = 3   <= heapsize(5)    -> 자식 있음 (O)
2. 노드 2: getRightChild(2) = 5   <= heapsize(5)    -> 자식 있음 (O)
3. 노드 3: getRightChild(3) = 7   > heapsize(5)     -> 자식 없음 (X)
 */
    typedef struct {
        int heap[1001];
        int size;
    } MaxHeap;


    // 힙 초기화
    void initHeap(MaxHeap* h) {
        h->size = 0;
        // 부모,자식 노드 계산을 간결하게 하기 위해 0번 인덱스 사용 X 
        h->heap[0] = 0;
    }

    // 부모 노드의 인덱스 반환
    int getParent(int index) {
        return index  / 2;
    }

    // 왼쪽 자식 노드의 인덱스 반환
    int getLeftChild(int index) {
        return 2 * index;
    }
    
    // 오른쪽 자식 노드의 인덱스 반환
    int getRightChild(int index) {
        return index * 2 + 1;
    }
    
// 삽입 연산
void insert(MaxHeap* h, int value) {
    if (h->size >= MAX_HEAP_SIZE - 1) return;
    
    h->size++;
    int current = h->size;  // 1번 인덱스부터 시작
    h->heap[current] = value;

    // 부모 노드와 비교하여 위치 조정
    while (current > 1 && h->heap[current] > h->heap[getParent(current)]) {
        int temp = h->heap[current];
        h->heap[current] = h->heap[getParent(current)];
        h->heap[getParent(current)] = temp;
        current = getParent(current);
    }
}

void DownHeap(MaxHeap *heap, int heapsize) { 
        int node_position = 1;
        int max_idx; 
        int left_c, right_c;
        // 현위치가 heapsize보단 작아야하고, 적어도 왼쪽자식(완전이진트리는 왼쪽부터있으니)은 있어야됨
        while(node_position < heapsize && getLeftChild(node_position) <= heapsize) { 
            
            left_c= getLeftChild(node_position);
            right_c = getRightChild(node_position);

            max_idx = left_c; // 기본적으로 왼쪽 자식을 최대값으로 설정 (처음에는 max_idx = 0으로 했으나, 무한루프 걸림.)
            // 오른쪽 자식이 있는지 추가적으로 확인해야함.
            if (right_c <= heapsize && heap->heap[left_c] < heap->heap[right_c]) {
                max_idx = right_c;
            }

            // 현재 노드가 자식 노드들보다 크거나 같으면 종료
            if (heap->heap[node_position] >= heap->heap[max_idx]) {
                break;
            }

            // node change
            int temp = heap->heap[node_position];
            heap->heap[node_position] = heap->heap[max_idx];
            heap->heap[max_idx] = temp;
            // 바꾼 위치 현재위치로 저장
            node_position = max_idx;
            }
    }

int main()
{
    int list[1001];
    int temp = 0;
    int n = 0;
    // 최대 힙 초기화
    MaxHeap heap;
    initHeap(&heap);

    // 파일 입출력
    FILE *fp = fopen("input.txt", "r");
    if (fp == NULL) {
        printf("파일을 열 수 없습니다.\n");
        return 1;
    }
    // 파일 데이터 읽기 
    while(fscanf(fp, "%d",&list[n]) != EOF){ 
        n++;
    }
    // // list 출력
    // printf("\n list 출력\n");
    // for (int i=0; i< n; i++) {
    //     printf("%d ", list[i]);
    // }
    fclose(fp);  // 파일 닫기

    // 최대힙에 입력값 넣기
    for(int i=0 ; i< n; i++) {
        // 힙은 1번 인덱스부터 시작함.
        insert(&heap,list[i]);
    }
    // printf("\n heap 출력\n");
    // for(int i=1; i< n+1; i++) {
    //     printf("%d ", heap.heap[i]);
    // }

    int heap_size_var = n+1;

    for (int i=1; i < n+1; i++) { 
        // printf("진행중 %d\n",i);
        // 시작과 끝 교체
        temp = heap.heap[1];
        heap.heap[1] = heap.heap[heap_size_var];
        heap.heap[heap_size_var] = temp;
        heap_size_var = heap_size_var - 1;
        // 위배된 힙 조건을 다시 재조정하기 위함.
        DownHeap(&heap,heap_size_var);
    }

    // 출력
    printf("\n heap sort 출력\n");
    for (int i=1; i < n+2; i++) {
        printf("%d ", heap.heap[i]);
    }

    // 파일 쓰기
    FILE *outfp = fopen("heap_output.txt", "w");
    if (outfp == NULL) {
        printf("파일을 열 수 없습니다.\n");
        return 1;
    }
    
    for (int i=1; i < n+2; i++) {
        fprintf(outfp, "%d\n", heap.heap[i]);
    }
    
    fclose(outfp);
    return 0;
}
