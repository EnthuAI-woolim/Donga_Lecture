#include <iostream>
#include <vector>
#include <fstream>
#include <queue>
using namespace std;
// ※ 1000개의 input data 중, 메모리에는 100개만 처리 가능함
// ※ 메모리에서 처리되는 데이터들은 동적 메모리 할당으로 처리하고 보조기억장치에서 처리하는 것들은 일반 메모리 할당으로 처리
class Hdd {
private:
    int id;
    vector<vector<int>> blocks;
public:
    Hdd(int _id) : id(_id) {}
    
    void addBlock(const vector<int>& block) {
        blocks.push_back(block);
    }
    
    vector<vector<int>>& getBlocks() {
        return blocks;
    }
    
    void clearBlocks() {
        blocks.clear();
    }
    
    int getNumberOfBlocks() const {
        return blocks.size();
    }
};

// 초기 분할 정렬
void initialSort(vector<int>& input, Hdd& hdd) {
    const int memory_size = 100;
    int total_size = input.size();
    int num_blocks = (total_size + memory_size - 1) / memory_size;
    
    for (int t = 0; t < num_blocks; t++) {
        // 동적 메모리 할당 100크기.
        int* memory = new int[memory_size];
        vector<int> sorted_block;
        
        // 현재 블록의 실제 크기 계산
        int current_block_size = min(memory_size, total_size - t * memory_size);
        
        // 메모리로 데이터 복사
        for (int i = 0; i < current_block_size; i++) {
            memory[i] = input[t * memory_size + i];
        }
        
        // 삽입 정렬
        for (int i = 1; i < current_block_size; i++) {
            int key = memory[i];
            int j = i - 1;
            while (j >= 0 && memory[j] > key) {
                memory[j + 1] = memory[j];
                j--;
            }
            memory[j + 1] = key;
        }
        
        // 정렬된 데이터를 블록에 저장
        for (int i = 0; i < current_block_size; i++) {
            sorted_block.push_back(memory[i]);
        }
        // 정렬된 블록을 hdd에 추가
        hdd.addBlock(sorted_block);
        // 동적 메모리 해제
        delete[] memory;
    }
}

// 두 정렬된 블록 병합
vector<int> mergeBlocks(const vector<int>& block1, const vector<int>& block2) {
    const int memory_size = 100;
    vector<int> merged;
    int* memory = new int[memory_size];
    int pos1 = 0, pos2 = 0;
    
    while (pos1 < block1.size() || pos2 < block2.size()) {
        // 메모리 버퍼 채우기
        int mem_count = 0;
        while (mem_count < memory_size && (pos1 < block1.size() || pos2 < block2.size())) {
            if (pos2 >= block2.size() || (pos1 < block1.size() && block1[pos1] <= block2[pos2])) {
                memory[mem_count++] = block1[pos1++];
            } else {
                memory[mem_count++] = block2[pos2++];
            }
        }
        
        // 메모리 버퍼의 내용을 결과에 추가
        for (int i = 0; i < mem_count; i++) {
            merged.push_back(memory[i]);
        }
    }
    
    delete[] memory;
    return merged;
}

int main() {
    // HDD 초기화
    Hdd hdd_1(1), hdd_2(2);
    
    // 입력 파일 읽기
    vector<int> input;
    ifstream fin("input.txt");
    int num;
    while (fin >> num) {
        input.push_back(num);
    }
    fin.close();
    
    // 초기 분할 정렬 (input을 100개씩 쪼개서 정렬 (현재는 1000개니까 100개씩 10개))
    initialSort(input, hdd_1);
    
    // 병합 단계
    while (hdd_1.getNumberOfBlocks() > 1) {
        Hdd& source_hdd = hdd_1;
        Hdd& target_hdd = hdd_2;
        
        // 블록 병합 (블록 2개씩 병합)
        for (int i = 0; i < source_hdd.getNumberOfBlocks() - 1; i += 2) {
            vector<int> merged = mergeBlocks(source_hdd.getBlocks()[i],source_hdd.getBlocks()[i + 1]);
            // 병합된 블록을 target_hdd에 추가
            target_hdd.addBlock(merged);
        }
        
        // 홀수 개의 블록이 있는 경우 마지막 블록 처리 (1개 남은 블록, 3개 남은 블록 등등)
        if (source_hdd.getNumberOfBlocks() % 2 == 1) {
            // 남은것은 그냥 추가
            target_hdd.addBlock(source_hdd.getBlocks().back());
        }
        
        // HDD 교체 (swap은 값의 교환이 아니라 주소의 교환)
        // 홀짝으로 하려고했으나, 값 복사가 많아서 오래걸려, 주소 교환으로 변경
        source_hdd.clearBlocks(); // 원본 블록 삭제
        swap(hdd_1, hdd_2);
    }
    
    // 결과 출력
    if (hdd_1.getNumberOfBlocks() > 0) {
        ofstream fout("external_sort_output.txt");
        for (int num : hdd_1.getBlocks()[0]) {
            fout << num << " ";
        }
        fout.close();
    }
    // cout 결과 출력
    for(int num : hdd_1.getBlocks()[0]) {
        cout << num << " ";
    }
    cout << endl;
    
    return 0;
}