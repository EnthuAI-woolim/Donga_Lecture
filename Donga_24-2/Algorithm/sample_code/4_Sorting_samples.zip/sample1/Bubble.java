import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.FileWriter;
public class Bubble {
    // input.txt 읽기
    public static void main(String[] args) throws Exception {  // 파일 입출력을 위한 예외처리 추가

    Scanner sc = new Scanner(new File("input.txt"));
    ArrayList<Integer> list = new ArrayList<>();
    
    // 파일의 모든 숫자를 읽어서 arraylist에 저장
    while (sc.hasNextInt()) {
        list.add(sc.nextInt());
    }

    int temp = 0;
    // n-1 회전
    for (int i=0; i<list.size()-1;i++){ 
        for (int j =0; j<list.size()-1-i ;j++){ 
            if(list.get(j) > list.get(j+1)) {
                temp = list.get(j);
                list.set(j, list.get(j+1));
                list.set(j+1, temp);
            }
        }
    }

    // 정렬된 배열 출력
    for (int c = 0; c < list.size(); c++) {
        System.out.print(list.get(c) + " ");
        }
        
    // 정렬된 배열 bubble_output.txt 파일에 출력
    FileWriter fw = new FileWriter("bubble_output.txt");
    for (int c = 0; c < list.size(); c++) {
        fw.write(list.get(c) + " ");
    }
    fw.close();
    
    }

}
