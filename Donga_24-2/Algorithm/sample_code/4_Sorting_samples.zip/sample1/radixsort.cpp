#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
/*
lsd 처럼 해서는 제대로 정렬되지 않음. 자리수별로 따로 돌려야함.
따로 저장할 벡터 생성 및 재귀함수를 사용해서 함수 구현 필요

1. 4째자리 숫자부터 시작해서
2. 각 자리수별로 버킷을 만들어서 분배한다. 
3. 같은 버킷에 있는 숫자들에 대해 그 아래(다음)자리수로 재귀호출한다
4. 모든 버킷을 순차적으로 합쳐서 최종결과 생성
*/
void msdRadixSort(vector<int>& arr, int exp) {
    // 기저 조건: 배열 크기가 1 이하거나 자릿수가 없으면 종료
    if (arr.size() <= 1 || exp == 0) return;

    // 0-9까지의 버킷 생성
    vector<vector<int>> buckets(10);
    
    // 현재 자릿수에 따라 숫자들을 버킷에 분배
    for(int num : arr) {
        int digit = (num / exp) % 10;  // 현재 자릿수 추출
        buckets[digit].push_back(num); // 해당 버킷에 숫자 추가
    }
    
    arr.clear();  // 원본 배열 비우기
    
    // 각 버킷 처리
    for(int i = 0; i < 10; i++) {
        if(buckets[i].size() > 1) {
            // 버킷 내 숫자가 2개 이상이면 다음 자릿수로 재귀 호출
            msdRadixSort(buckets[i], exp/10);
        }
        // 정렬된 버킷의 내용을 원본 배열에 추가
        arr.insert(arr.end(), buckets[i].begin(), buckets[i].end());
    }
}

int main() { 
    vector<int> numbers;
    int num;

    // input.txt 파일 읽기
    ifstream input("input.txt");
    if (!input.is_open()) {
        cout << "파일을 열 수 없습니다." << endl;
        return 1;
    }

    // 파일에서 숫자를 읽어서 vector에 저장
    while (input >> num) {
        numbers.push_back(num);
    }
    input.close();
    vector<int> numbers_lsd = numbers;
    vector<int> numbers_msd = numbers;
    vector<int> temp;
    vector<int> msd_temp;

    // LSD radixSort
    for(int exp = 1; exp <= 1000; exp *= 10) {  // pow() 대신 exp 사용
        for(int k = 0; k < 10; k++) { // 0~9
            for(int j = 0; j < numbers_lsd.size(); j++) { // 전체순회 
                if((numbers_lsd[j] / exp) % 10 == k) {
                    temp.push_back(numbers_lsd[j]);
                }
            }
        }
        numbers_lsd = temp;  // 벡터 복사
        temp.clear();    // temp 초기화
    }
    
    // cout 값 출력
    for(int i = 0; i < numbers_lsd.size(); i++) {
        cout << numbers_lsd[i] << " ";
    }
    cout << endl;
    
    // rdix_lsd_output.txt 파일에 출력 
    ofstream output("radix_lsd_output.txt");
    for(int i=0;i<numbers_lsd.size();i++) { 
            output << numbers_lsd[i] << endl; 
    } 

    // radix_msd_output.txt 파일에 출력    
    msdRadixSort(numbers_msd, 1000);
    ofstream output_msd("radix_msd_output.txt");
    // 파일에 데이터 쓰기
    for(int i = 0; i < numbers_msd.size(); i++) { 
        output_msd << numbers_msd[i] << endl; 
    }
    // 파일 쓰기가 끝난 후 닫기
    output_msd.close();

}