#include <stdio.h>
/*
변수 n은 파일에서 읽은 숫자의 개수를 저장하는 변수이다.
*/
int main()
{
    int list[1001];
    int temp = 0;
    int n = 0;

    // 파일 입출력
    FILE *fp = fopen("input.txt", "r");
    if (fp == NULL) {
        printf("파일을 열 수 없습니다.\n");
        return 1;
    }
    // 파일 데이터 읽기 
    while(fscanf(fp, "%d",&list[n]) != EOF){ 
        n++;
    }
    fclose(fp);  // 파일 닫기
    
    for(int i =0; i<n; i++){ 
        int min = 99999;
        int min_index = 0;
        for(int j =i ;j <n; j++){ 
            if(list[j] < min) {
                min = list[j];
                min_index = j;
            }
        }
        temp = list[i];
        list[i] = min;
        list[min_index] = temp;
    }

    // 출력
    for(int i =0; i<n; i++){ 
        printf("%d ", list[i]);
    }

    // 파일 출력 selection_output.txt
    FILE *fp2 = fopen("selection_output.txt", "w");
    for(int i =0; i<n; i++){ 
        fprintf(fp2, "%d ", list[i]);
    }
    fclose(fp2);
    return 0;
}