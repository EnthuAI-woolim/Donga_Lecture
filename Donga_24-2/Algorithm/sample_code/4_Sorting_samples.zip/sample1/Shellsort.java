import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;  // PrintWriter import 추가

public class Shellsort {
    public static void main(String[] args) throws Exception { 
        int current =0;
        Scanner sc = new Scanner(new File("input.txt"));
        ArrayList<Integer> list = new ArrayList<>();
        while (sc.hasNextInt()) {
            list.add(sc.nextInt());
        }
        int[] gaps = {100, 50, 10, 5, 1};

        // for(int gap : gaps) { 
        //     // insertion sort. , start-point set on 0+gap
        //     for(int i = gap; i<list.size();i++) { 
        //         current = list.get(i);
        //         int j = i;
        //         int insertion_point= j;// 삽입 위치를 현재 위치로 초기화

        //         if(j+gap <= list.size()){
        //             for(int before_index = j-gap; before_index>=0; before_index-=gap){
        //                 if(current < list.get(before_index)) {
        //                     list.set(before_index+gap, list.get(before_index));
        //                 }
        //                 else {
        //                     insertion_point = before_index+gap;
        //                     break;
        //                 }
        //             }
        //             list.set(insertion_point, current);
        //         }  
        //     }
        // }
        for(int gap : gaps) { 
            // insertion sort. , start-point set on 0+gap
            for(int i = gap; i<list.size();i++) { 
                current = list.get(i);
                int j = i;

                while(j >= gap && list.get(j-gap) > current){
                    list.set(j,list.get(j-gap));
                    j -= gap;
                }
                list.set(j, current);
            }
        }
        // 정렬 결과를 파일로 출력
        PrintWriter writer = new PrintWriter("shellsort_output.txt");
        for (int num : list) {
            writer.print(num + " ");
        }
        writer.close();
        
        System.out.println(list);  
    }
  
   /*
    간격을 정하고 간격을 이용해서 멀리 떨어진 작은 값을 앞으로 보내고, 너무 앞에있는 큰 값을 뒤로 보내는 작업을
    해서 일반적인 insertion sort를 향상시킨 방법이다. 
    지난 과제에서는 insertion sort를 for문을 이용해서 구현했는데, 이번에는 머리가 아파서 교재에 수도코드 형식을
    참고하여 while문으로 구현했다. 훨씬 간결하고 이해하기 쉬운 코드이다.
    */
}