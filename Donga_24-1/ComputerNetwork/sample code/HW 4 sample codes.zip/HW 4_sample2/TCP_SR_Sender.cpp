#include "Common.h"
#include <pthread.h>
#include <unistd.h>

#define SERVERPORT 9000
#define BUFSIZE    512


int main(int argc, char *argv[])
{
	int retval;

	// 소켓 생성
	SOCKET listen_sock = socket(AF_INET, SOCK_STREAM, 0);
	if (listen_sock == INVALID_SOCKET) err_quit("socket()");

	// bind()
	struct sockaddr_in serveraddr;
	memset(&serveraddr, 0, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = bind(listen_sock, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
	if (retval == SOCKET_ERROR) err_quit("bind()");

	// listen()
	retval = listen(listen_sock, SOMAXCONN);
	if (retval == SOCKET_ERROR) err_quit("listen()");

	// 데이터 통신에 사용할 변수
	SOCKET client_sock;
	struct sockaddr_in clientaddr;
	socklen_t addrlen;
	char buf[2];

	while (1) {
		// accept()
		addrlen = sizeof(clientaddr);
		client_sock = accept(listen_sock, (struct sockaddr *)&clientaddr, &addrlen);
		if (client_sock == INVALID_SOCKET) {
			err_display("accept()");
			break;
		}

		// 접속한 클라이언트 정보 출력
		char addr[INET_ADDRSTRLEN];
		inet_ntop(AF_INET, &clientaddr.sin_addr, addr, sizeof(addr));
		printf("\n[TCP 서버] 클라이언트 접속: IP 주소=%s, 포트 번호=%d\n",
			addr, ntohs(clientaddr.sin_port));
		
		int timeout =5; //timeout 시간
		int packet = 0; //보낼 패킷
		int recvack = 0; 
		int pac2 = 1; //loss 된 패킷
        int sendpk_ack[10] = {0, }; //ack 받은 패킷
		// 클라이언트와 데이터 통신
		while(1)
		{
			if (timeout == 5)
			{
				timeout = 0;
				for(int i=0; i<4; i++)
				{
                    if (sendpk_ack[packet] == 1)
                    {
                        sendpk_ack[packet+1] =1;
                        packet += 1;
                        continue;
                    }
					if (pac2 == 1 && packet == 2)	pac2 =0;
					else
					{
						sprintf(buf, "%d", packet);
						send(client_sock, buf, 2, 0);
					}
					printf("\"packet %d\" is transmitted.\n", packet);

					packet += 1;
					
					timeout +=1;
					sleep(0.5);
				}

				if (packet == 6)	break;
			}

			else
			{
				recv(client_sock, buf, 2, 0);
				packet = atoi(buf);
                sendpk_ack[packet] = 1;
				if (recvack == packet)
				{
					printf("\"ACK %d\" received, ", packet);
					packet = packet + 4;
					sprintf(buf, "%d", packet);
					send(client_sock, buf, 2, 0);
					printf("\"packet %d\" is transmitted.\n", packet);

					recvack += 1;
				}
				else
				{
					printf("\"ACK %d\" is received and recorded.\n", packet);
					timeout += 1;
					if (timeout == 5)
					{
						printf("\"packet %d\" is timeout.\n", recvack);
						packet = recvack;
						sleep(0.5);
						
					}
				}
			}


		}
			

		// 소켓 닫기
		close(client_sock);
		printf("[TCP 서버] 클라이언트 종료: IP 주소=%s, 포트 번호=%d\n",
			addr, ntohs(clientaddr.sin_port));

		break;
	}

	// 소켓 닫기
	close(listen_sock);
	return 0;
}