#include "Common.h"

char *SERVERIP = (char *)"127.0.0.1";
#define SERVERPORT 9000
#define BUFSIZE    512


int main(int argc, char *argv[])
{
	int retval;

	// 명령행 인수가 있으면 IP 주소로 사용
	if (argc > 1) SERVERIP = argv[1];

	// 소켓 생성
	SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock == INVALID_SOCKET) err_quit("socket()");

	// connect()
	struct sockaddr_in serveraddr;
	memset(&serveraddr, 0, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	inet_pton(AF_INET, SERVERIP, &serveraddr.sin_addr);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = connect(sock, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
	if (retval == SOCKET_ERROR) err_quit("connect()");
	char buf[2];
    int ACK = 0;
	int sendack = 0;
	int sendpk[10] = {0, };
	sendpk[2] = 1;
    int last1 = -1;
	while(1)
	{

		recv(sock, buf, 2, 0);
		ACK = atoi(buf);
		if (sendack == ACK)
		{
			sprintf(buf, "%d", ACK);
			send(sock, buf, 2, 0);
            
            sendpk[ACK] = 1;			
			printf("\"packet %d\" is received. ", ACK);
            if (last1 != -1)
            {
                int count = 0;

                for (int i=ACK; i<ACK+4; i++)
                {
                    if(i == last1 && sendpk[i] == 1)
                    {
                        if (count > 0)
                            printf("and packet %d are delivered. ", i);
                        else if(count == 0)
                            printf("packet %d is delivered.", i);
                    }
                    else if(i != last1 && sendpk[i] == 1)
                    {
                        printf("packet %d, ", i);
                        count += 1;
                    }   
                        
                    if (sendpk[i] == 0) sendack = i;
                        
                }
                if (sendack == ACK) sendack = sendack+3;
            }
            printf("\"ACK %d\" is transmitted.\n", ACK);
            
			sendack += 1;
            last1 = -1;
			if (sendack == 6)	break;
		}
		else
		{
            sendpk[ACK] = 1;
			sprintf(buf, "%d", ACK);
			send(sock, buf, 2, 0);
			printf("\"packet %d\" is received and buffered. \"ACK %d\" is transmitted.\n", ACK, ACK);
            last1 = ACK;
		}
		


	}

	// 소켓 닫기
	close(sock);
	return 0;
}