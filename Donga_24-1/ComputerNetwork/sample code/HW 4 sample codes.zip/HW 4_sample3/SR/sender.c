#include "Common.h"

#define SERVERPORT 9000
#define BUFSIZE    512
#define WINDOW_SIZE 4
#define TIMEOUTINTERVAL 5

struct packet {
	int send_time; // ������ �ð�
	char pkt_number;
};

struct packet pkt[10];
struct packet* p = pkt; // ���� ��ġ

int main(int argc, char* argv[]) {
	for (int i = 0; i < 10; i++) {
		pkt[i].pkt_number = i + '0'; // ���ڸ� ���ڷ� ����
	}

	int retval;

	// ���� ����
	SOCKET listen_sock = socket(AF_INET, SOCK_STREAM, 0);
	if (listen_sock == INVALID_SOCKET) err_quit("socket()");

	// bind()
	struct sockaddr_in serveraddr;
	memset(&serveraddr, 0, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = bind(listen_sock, (struct sockaddr*)&serveraddr, sizeof(serveraddr));
	if (retval == SOCKET_ERROR) err_quit("bind()");

	// listen()
	retval = listen(listen_sock, SOMAXCONN);
	if (retval == SOCKET_ERROR) err_quit("listen()");

	// ������ ��ſ� ����� ����
	SOCKET client_sock;
	struct sockaddr_in clientaddr;
	socklen_t addrlen;
	char buf[BUFSIZE + 1];
	char ackrecord;

	while (1) {
		// accept()
		addrlen = sizeof(clientaddr);
		client_sock = accept(listen_sock, (struct sockaddr*)&clientaddr, &addrlen);
		if (client_sock == INVALID_SOCKET) {
			err_display("accept()");
			break;
		}
		// ���Ŵܰ� ������ ���
		while (1) {
			// ����
			for (int i = 0; i < WINDOW_SIZE; i++) {
				buf[0] = p[i].pkt_number;
				printf("\"packet %c\" is transmitted.\n", buf[0]);
				if (i == 2) { sleep(1); continue; }
				retval = send(client_sock, buf, sizeof(char), 0);
				if (retval == SOCKET_ERROR) {
					err_display("send()");
					break;
				}
				sleep(1);
				p[i].send_time = time(NULL);
			}
			while (1) {
				// timeout üũ
				if (time(NULL) - p[0].send_time >= TIMEOUTINTERVAL) break;
				// ����
				retval = recv(client_sock, buf, BUFSIZE, 0);
				if (retval == SOCKET_ERROR) {
					err_display("recv()");
					break;
				}
				else if (retval == 0) break;
				buf[retval] = '\0';
				if (p[0].pkt_number == buf[0]) {
					printf("\"ACK %c\" is received. ", buf[0]);
					p++;
					buf[0] = p[3].pkt_number;
					// ����
					retval = send(client_sock, buf, sizeof(char), 0);
					if (retval == SOCKET_ERROR) {
						err_display("send()");
						break;
					}
					printf("\"packet %c\" is transmitted.\n", p[3].pkt_number);
					sleep(1);
				}
				else {
					printf("\"ACK %c\" is received and recorded.\n", buf[0]);
					ackrecord = buf[0];
				}
			}
			printf("packet %c is timeout.\n", p[0].pkt_number);
			buf[0] = 'r';
			retval = send(client_sock, buf, sizeof(char), 0);
			if (retval == SOCKET_ERROR) {
				err_display("send()");
				break;
			}
			buf[0] = p[0].pkt_number;
			printf("\"packet %c\" is transmitted.\n", buf[0]);
			retval = send(client_sock, buf, sizeof(char), 0);
			if (retval == SOCKET_ERROR) {
				err_display("send()");
				break;
			}
			sleep(1);
			break;
		}
		// ���� �ݱ�
		close(client_sock);
	}
	// ���� �ݱ�
	close(listen_sock);
	return 0;
}