#include "Common.h"

#define SERVERPORT 9000
#define BUFSIZE    512
#define WINDOW_SIZE 4

int main(int argc, char* argv[])
{
	int retval;

	// ���� ����
	SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock == INVALID_SOCKET) err_quit("socket()");

	// ������ �μ��� ������ IP �ּҷ� ���
	char SERVERIP[] = "127.0.0.1";
	if (argc > 1) strcpy(SERVERIP, argv[1]);

	// connect()
	struct sockaddr_in serveraddr;
	memset(&serveraddr, 0, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	inet_pton(AF_INET, SERVERIP, &serveraddr.sin_addr);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = connect(sock, (struct sockaddr*)&serveraddr, sizeof(serveraddr));
	if (retval == SOCKET_ERROR) err_quit("connect()");

	// ������ ��ſ� ����� ����
	char buf[BUFSIZE + 1];
	char pkbuf[BUFSIZE + 1];
	int size = 0; // ���۸��� ��Ŷ ����
	int len;

	char pkn = '0'; // ��Ŷ ��ȣ
	char prev = 'x';
	int i = 0;
	int re = 0;

	// ������ ������ ���
	while (1) {
		// ������ �ޱ�
		retval = recv(sock, buf, BUFSIZE, 0);
		if (retval == SOCKET_ERROR) {
			err_display("recv()");
			break;
		}
		else if (retval == 0) break;
		buf[retval] = '\0';
		if (buf[0] == 'r') { re = 1; continue; }
		if (pkn != buf[0]) {
			printf("\"packet %c\" is received and buffered. \"ACK %c\" is retransmitted.\n", buf[0], buf[0]);
			buf[0] = prev;
			pkbuf[size] = buf[0];
			size++;
			retval = send(sock, buf, retval, 0);
			if (retval == SOCKET_ERROR) {
				err_display("send()");
				break;
			}
			sleep(1);
			continue;
		}
		else if (re != 0) {
			retval = send(sock, buf, retval, 0);
			if (retval == SOCKET_ERROR) {
				err_display("send()");
				break;
			}
			printf("\"packet %c\" is received. packet %c, packet %c, packet %c, and packet %c are delivered. \"ACK %c\" is transmitted.\n", buf[0], buf[0], pkbuf[0], pkbuf[1], pkbuf[2], buf[0]);
			size = 0;
			break;
		}
		else {
			retval = send(sock, buf, retval, 0);
			if (retval == SOCKET_ERROR) {
				err_display("send()");
				break;
			}
			printf("\"packet %c\" is received. \"ACK %c\" is transmitted.\n", buf[0], buf[0]);
		}
		prev = buf[0];
		i++;
		pkn = '0' + i;
		sleep(1);
	}
	// ���� �ݱ�
	close(sock);
	return 0;
}