#include "Common.h"
#include <pthread.h>

#define SERVERPORT 9000
#define BUFSIZE 512
#define WINDOWSIZE 4 //윈도우 사이즈
#define SIZE 6 //패킷 수
#define WANNALOSS 2 //로스를 발생시기코자 하는 패킷 넘버
SOCKET listen_sock, client_sock;
struct sockaddr_in serveraddr, clientaddr;
socklen_t addrlen;
int tmp_num = -1;
char buf[BUFSIZE + 1];


int ack_check[SIZE]; // ACK 확인 배열
int timeout_check[SIZE]; //패킷별 시간 측정
int send_index = 0; //보낸 패킷의 index
int send_count = 0; //WINDOWSIZE 중 몇번째 까지 보냈는지 확인하기 위한 변수
int timeout_packet = -1; //타임아웃된 패킷이 있는지 확인하기 위한 변수 
int retrans = 0; //리트랜스미션 중인지 확인하기 위한 변수
int prev_ack = -1; //이전 ack

void* func_recv(void* arg);
int sum_of_num(char *str); //문자열에서 숫자만 골라내는 함수

int main(int argc, char *argv[]) {
    int overflow = 0; //index가 SIZE를 넘어갔는지 확인
    int send_check[SIZE]; //보냈던 패킷인지 확인
    pthread_t recv_thread;

    // 소켓 생성
    listen_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_sock == INVALID_SOCKET) err_quit("socket()");

    memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serveraddr.sin_port = htons(SERVERPORT);
    if (bind(listen_sock, (struct sockaddr *)&serveraddr, sizeof(serveraddr)) == SOCKET_ERROR)
        err_quit("바인드 오류");

    if (listen(listen_sock, SOMAXCONN) == SOCKET_ERROR)
        err_quit("listen 오류");

    addrlen = sizeof(clientaddr);
    client_sock = accept(listen_sock, (struct sockaddr *)&clientaddr, &addrlen);
    if (client_sock == INVALID_SOCKET) {
        err_display("accept 오류");
        exit(1);
    }

    char addr[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &clientaddr.sin_addr, addr, sizeof(addr));
    printf("\n[TCP 서버] 클라이언트 접속: IP 주소=%s, 포트 번호=%d\n", addr, ntohs(clientaddr.sin_port));

    if(pthread_create(&recv_thread, NULL, func_recv, NULL) != 0) {
        fprintf(stderr, "스레드 생성 오류\n");
        return 1;
    }
    int flag = 0;

	while(send_index <= SIZE) {
		while(send_count < WINDOWSIZE && send_index < SIZE) { //send_index가 SIZE보다 작고 WINDOWSIZE보다 덜 보냈으면 반복해서 send
            usleep(300000);
            char packet[100];
            sprintf(packet, "packet %d", send_index);
            if(flag == 0 && sum_of_num(packet) == WANNALOSS) { //loss시킬 패킷은 보냈다고 표시만 하고 send하지는 않아 인위적으로 loss를 발생시킴.
                printf("\"%s\" is transmitted.\n", packet);
                timeout_check[send_index]++;
                flag = 1;
                send_index++;
                send_count++;
            }
            else {
                if(timeout_packet == -1) { //timeout 발생x
                    for(int i=0; i<SIZE; i++) { //모든 보냈던 패킷들 타임 1 증가
                        if(timeout_check[i] != 0)
                            timeout_check[i]++;
                    }
                    if(send_check[send_index] == 1) { //이미 보낸 패킷이 send_index라면
                        while(send_check[send_index] == 1) {
                            send_index++; //보내지 않은 패킷이 send_index일때까지 증가.
                            if(send_index >= SIZE) {
                                overflow = 1;
                            }
                        }
                    }
                }
                if(overflow == 1) //overflow가 발생하면 중단.
                    break;
                if(timeout_check[send_index] == 0) //이제 보낼 패킷 타임 1 증가
                    timeout_check[send_index]++;
                sprintf(packet, "packet %d", send_index);
                send(client_sock, packet, BUFSIZE, 0); //패킷 전송
                printf("\"%s\" is transmitted.\n", packet);
                send_check[send_index] = 1;
                
                if(send_index == timeout_packet) { //현재 보내는 패킷이 타임아웃이 일어났던 패킷이면 재전송 했으니 timeout_packet을 -1로 바꾼다.
                    tmp_num = timeout_packet; //타임아웃 된 패킷의 ack를 수신할 때 필요한 tmp_num 변수
                    timeout_packet = -1;

                }
                send_index++; send_count++; //인덱스와 카운트 1씩 증가
            }
		}
        for(int i=0; i<SIZE; i++) {
            if(timeout_check[i] == 5) { //timeout이 발생하면
                timeout_check[i] = 0; //재전송 해야하니 time을 0으로 바꾼 후
                send_count--; //전송횟수를 1 줄인다.
                send_index = i; //i번째 패킷을 전송해야하니 index는 i
                send_check[send_index] = 0; //재전송 해야하니 보냈던 표시도 없앤다.
                retrans = 0;
                timeout_packet = i; //timeout된 패킷의 인덱스를 저장한다.
                printf("\"packet %d\" is timeout.\n", i);
                break;
            }
        }

	}

    pthread_join(recv_thread, NULL); // 스레드 종료 후 자원 회수

    close(client_sock);
    printf("[TCP 서버] 클라이언트 종료: IP 주소=%s, 포트 번호=%d\n", addr, ntohs(clientaddr.sin_port));
    close(listen_sock);
    return 0;
}

void* func_recv(void* arg) {
    int tmp = 0;
    int retval;
    while(1) {
        retval = recv(client_sock, buf, BUFSIZE, 0);
		if (retval == SOCKET_ERROR) {
			err_display("recv()");
			break;
		}
		else if (retval == 0) {
			break;
		}
        buf[retval] = '\0';
        int ack_index = sum_of_num(buf);

        if(prev_ack + 1 != ack_index || tmp_num == ack_index) { //현재 받은 ack가 이전에 받은 ack+1이 아니거나 현재 받은 ack가 timeout된 패킷의 ack이면
            ack_check[ack_index] = 1; //받았다고 표시는 해두고 저장해둔다.
            if(tmp_num == ack_index) {
                printf("\"%s\" is received\n", buf);
            }
            else {
                printf("\"%s\" is received and recorded\n", buf);
            }
           

            timeout_check[ack_index] = 0; //받았으니 시간은 0으로 초기화
            for(int i=0; i<SIZE; i++) { //나머지는 시간 1씩 증가
                if(timeout_check[i] != 0) {
                    timeout_check[i]++;
                }
            }
            tmp++;
            if(tmp == 4) { //WINDOWSIZE만큼 다 받고 나면 
                send_count = 0; //카운트 0으로 초기화 하여 이어서 WINDOWSIZE만큼 보낼 준비를 한다.
                send_index = ack_index + 3; //보낼 인덱스 정리
                tmp_num = -1;
                prev_ack = ack_index + 3; //이전에 받은 ack도 정리한다.
            }

        }
        else {
            if(retrans == 0) {
                ack_check[ack_index] = 1; // ACK 수신 표시
                printf("\"%s\" is received. ", buf);

                if(send_index == SIZE)
                    printf("\n");
                timeout_check[ack_index] = 0;
                prev_ack = ack_index;
            }
            send_count--;
        }
    }
	pthread_exit(NULL);
}
int sum_of_num(char *str) {
    int sum = 0;
    for(int i=0; i<strlen(str); i++) {
        if(str[i] >= '0' && str[i] <= '9') {
            sum = sum*10 + (str[i]-'0');
        }
    }
    return sum;
}