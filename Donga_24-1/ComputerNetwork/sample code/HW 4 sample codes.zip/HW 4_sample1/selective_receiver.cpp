#include "Common.h"
#include <pthread.h>

#define SERVERPORT 9000 //포트번호
#define BUFSIZE    512 //버퍼의 최대사이즈
#define SIZE 6 //총 패킷 갯수
#define WINDOWSIZE 4 //윈도우 사이즈



char *SERVERIP = (char *)"127.0.0.1"; //서버의 ip주소
struct sockaddr_in serveraddr; //서버주소 정보를 담는 구조체
SOCKET sock; //소켓 선언
pthread_t tid1;	

int prev_packet_num = -100; //이전에 들어온 패킷
int current_packet_num = -100; //현재 들어온 패킷

int ack_check[SIZE]; //ack 확인
int ack_index = 0; //ack인덱스
int flag = 0;
int tmp = -100; //현재 들어온 패킷이 retransmission 된 패킷인지 확인할 때 필요한 변수

void *func_recv(void* arg); //스레드가 수행 할 recv함수
int sum_of_num(char *str); //문자열에서 숫자만 골라내는 함수

int main(int argc, char *argv[])
{
	int retval;
	// 명령행 인수가 있으면 IP 주소로 사용
	if (argc > 1) SERVERIP = argv[1];
	sock = socket(AF_INET, SOCK_STREAM, 0); // 소켓 생성
	if (sock == INVALID_SOCKET) err_quit("socket()");

	// connect()

	memset(&serveraddr, 0, sizeof(serveraddr)); //서버주소 구조체 초기화
	serveraddr.sin_family = AF_INET; //주소체계 인터넷
	inet_pton(AF_INET, SERVERIP, &serveraddr.sin_addr); //서버주소 구조체에 할당
	serveraddr.sin_port = htons(SERVERPORT);
	retval = connect(sock, (struct sockaddr *)&serveraddr, sizeof(serveraddr)); //서버에 연결 요청
	if (retval == SOCKET_ERROR) err_quit("connect()");

	// 데이터 통신에 사용할 변수
	char buf[BUFSIZE + 1];
	int len;
	//스레드 생성
	if(pthread_create(&tid1, NULL, func_recv, NULL) != 0) { //recv함수를 수행하는 스레드 생성
		fprintf(stderr, "thread create error\n");
		exit(1);
	}

	
	//스레드 자원 회수
	pthread_join(tid1, NULL);

	// 소켓 닫기
	close(sock);
	return 0;
}
void *func_recv(void* arg) {
	//printf("리시브 생김\n");

	char recv_buf[BUFSIZE+1] = {}; //서버에서 받은 메시지를 담는 버퍼
	int retval;
	while(1) { //스레드 종료조건이 되기 전까지는 반복해서 recv 수행
		retval = recv(sock, recv_buf, BUFSIZE, 0); //recv함수를 통해 서버로부터 메시지를 전달받아 버퍼에 저장
		if (retval == SOCKET_ERROR) {
			err_display("recv()");
			break;
		}
		else if (retval == 0) {
			break;
		}
		recv_buf[retval] = '\0';
		current_packet_num = sum_of_num(recv_buf); //현재 받은 패킷의 인덱스
		usleep(1000000);
		if(current_packet_num == 0 || current_packet_num == prev_packet_num+1) { //최초 0번 패킷이 도착했거나 이전 패킷+1이 현재 패킷이면 순서대로 오고 있다는 뜻
			printf("\"%s\" received. ", recv_buf);
			prev_packet_num = current_packet_num; //이전 패킷 번호 갱신
			ack_check[current_packet_num] = 1;
			char ack_message[100];
			sprintf(ack_message, "ack %d", current_packet_num);
			//sleep(1);
			send(sock, ack_message, BUFSIZE, 0);
			if(current_packet_num == tmp) { //현재 들어온 패킷이 retransmission 된 패킷인지 확인하는 조건
				prev_packet_num = tmp + 3; //이전 패킷 넘버 조정
				for(int i=tmp; i<tmp+WINDOWSIZE; i++) {

					if(i == tmp+3) {
						printf("and packet %d are delivered. ", i); 
					}
					else {
						printf("packet %d, ", i);
					}
				}
			}
			printf("\"%s\" is transmitted.\n", ack_message);
			
		}
		else { //순서대로 패킷이 도착하지 않았으면

			if(flag == 0) { //받지못한 패킷 기록
				tmp = current_packet_num-1;
				flag = 1;
			}
			char ack_message[100];
			sprintf(ack_message, "ack %d", current_packet_num);
			ack_check[current_packet_num] = 1; //받았다고 표시하고
			printf("\"%s\" is received and buffered. \"%s\" is transmitted.\n", recv_buf, ack_message); //ack를 전송한다.
			send(sock, ack_message, BUFSIZE, 0);
		}

	}
	printf("리시브 없어짐\n");
	pthread_exit(NULL);
}
int sum_of_num(char *str) {
    int sum = 0;
    for(int i=0; i<strlen(str); i++) {
        if(str[i] >= '0' && str[i] <= '9') {
            sum = sum*10 + (str[i]-'0');
        }
    }
    return sum;
}