#include "Common.h"
#include <pthread.h>

#define SERVERPORT 9000
#define BUFSIZE 512
#define WINDOWSIZE 4 //윈도우 사이즈
#define SIZE 6 //총 패킷 갯수
#define WANNALOSS 2 //로스 발생시킬 패킷 넘버
SOCKET listen_sock, client_sock;
struct sockaddr_in serveraddr, clientaddr;
socklen_t addrlen;
char buf[BUFSIZE + 1];

int ack_check[SIZE]; // ACK 확인 배열
int prev_ack = -100; //이전 ack
int timeout_check[SIZE]; //타임아웃 체크
int send_index = 0; //보내는 패킷의 인덱스
int send_count = 0; //보낸 패킷의 수(WINDOWSIZE 내에서)
int timeout_packet = 0; //타임아웃 된 패킷
int retrans = 0;

int sum_of_num(char *str); //문자열에서 숫자만 골라내는 함수
void* func_recv(void* arg);

int main(int argc, char *argv[]) {

    int send_check[SIZE];
    pthread_t recv_thread;

    // 소켓 생성
    listen_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_sock == INVALID_SOCKET) err_quit("socket()");

    memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serveraddr.sin_port = htons(SERVERPORT);
    if (bind(listen_sock, (struct sockaddr *)&serveraddr, sizeof(serveraddr)) == SOCKET_ERROR)
        err_quit("바인드 오류");

    if (listen(listen_sock, SOMAXCONN) == SOCKET_ERROR)
        err_quit("listen 오류");

    addrlen = sizeof(clientaddr);
    client_sock = accept(listen_sock, (struct sockaddr *)&clientaddr, &addrlen);
    if (client_sock == INVALID_SOCKET) {
        err_display("accept 오류");
        exit(1);
    }

    char addr[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &clientaddr.sin_addr, addr, sizeof(addr));
    printf("\n[TCP 서버] 클라이언트 접속: IP 주소=%s, 포트 번호=%d\n", addr, ntohs(clientaddr.sin_port));

    if(pthread_create(&recv_thread, NULL, func_recv, NULL) != 0) {
        fprintf(stderr, "스레드 생성 오류\n");
        return 1;
    }
    int flag = 0;

	while(send_index <= SIZE) {
		while(send_count < WINDOWSIZE && send_index < SIZE) {
            usleep(300000);

            char packet[100];
            sprintf(packet, "packet %d", send_index);
            if(flag == 0 && sum_of_num(packet) == WANNALOSS) { //loss 발생시킬 패킷.
                printf("\"%s\" is transmitted.\n", packet);
                timeout_check[send_index]++;
                flag = 1; //loss는 1회만 발생해야하니 flag를 통해 이 조건문에 더 들어오지 못하게 함
                send_index++;
                send_count++;
            }
            else {
                for(int i=0; i<SIZE; i++) { //모든 패킷의 time 1씩 증가
                    if(timeout_check[i] != 0)
                        timeout_check[i]++;
                }
                if(timeout_check[send_index] == 0) //현재 보내는 패킷의 타임 1 증가
                    timeout_check[send_index]++;
                send(client_sock, packet, BUFSIZE, 0);
                printf("\"%s\" is transmitted.\n", packet);
                send_check[send_index] = 1; //보냈다고 표시
                send_index++; send_count++;        
            }
		}

        for(int i=0; i<SIZE; i++) {
            if(timeout_check[i] == 5) { //타임아웃이 발생하면
                send_count=0; //타임아웃이 발생 한 곳 부터 WINDOWSIZE만큼 다시 보내야하니 0으로 조정
                send_index = i; //i번 패킷부터 보내야 하니 인덱스는 i로 조정
                retrans = 1; //retransmission 발생했음을 알리는 변수
                timeout_packet = i; //타임아웃 발생 한 패킷의 인덱스를 저장
                printf("\"packet %d\" is timeout.\n", i);
                for(int j=0; j<SIZE; j++) { //모든 패킷을의 시간을 0으로 조정한다.(다 다시 보내야 하니까)
                    timeout_check[j] = 0;
                }
                break;
            }
        }
	}

    pthread_join(recv_thread, NULL); // 스레드 종료 대기

    close(client_sock);
    printf("[TCP 서버] 클라이언트 종료: IP 주소=%s, 포트 번호=%d\n", addr, ntohs(clientaddr.sin_port));
    close(listen_sock);
    return 0;
}

void* func_recv(void* arg) {
    int tmp = 0;
    int tmp_num = -100;
    int retval;
    int zero_check = 0; //통신을 시작하고 최초로 오는 패킷이 0인지 확인할 때 사용하는 변수
    while(1) {
        retval = recv(client_sock, buf, BUFSIZE, 0);
		if (retval == SOCKET_ERROR) {
			err_display("recv()");
			break;
		}
		else if (retval == 0) {
			break;
		}
        buf[retval] = '\0';
        int ack_index = sum_of_num(buf);
        if(ack_check[0] == 0 && ack_index == 0) //최초 ack0을 수신.
            zero_check = 0;
        if(ack_check[0] == 0 && ack_index != 0 && zero_check == 0) { //최초로 들어오는 ack가 ack 0 이 아니라면
            printf("\"%s\" is received and ignored.\n", buf); //패킷을 무시하고
            for(int i=0; i<SIZE; i++) { //모든 패킷의 시간 1씩 증가
                if(timeout_check[i] != 0)
                    timeout_check[i]++;
            } 
            zero_check = 1; //플래그 1
            continue;
        }
        if(retrans == 1 && ack_index == timeout_packet) //타임아웃 발생 한 패킷을 리트랜스미션하면
            retrans = 0; //이후에 들어오는 ack는 정상 수신 해야하니 retrans를 0으로 조정해준다
        if(ack_index == tmp_num) { //현재 받은 ack인덱스가 retransmission한 패킷의 ack이면
            prev_ack = tmp_num - 1; //prev_ack 조정
            tmp_num = -100;
        }
        if(zero_check == 0) { //ack 0 을 처음에 수신 하여 정상적인 순서가 됬다면
            if(ack_check[ack_index] == 1 && prev_ack+1 != ack_index) { //정상적인 순서로 ack가 들어오지 않으면
                if(tmp == 0) {
                    tmp = 1; //loss발생했다고 tmp를 1로 바꿔 줌
                    tmp_num = ack_index - 1; //loss발생한 패킷의 ack인덱스 기록
                }
                if(retrans == 0) {
                    printf("\"%s\" is received and ignored.\n", buf);
                    for(int i=0; i<SIZE; i++) { //모든 패킷의 시간 1씩 증가
                        if(timeout_check[i] != 0)
                            timeout_check[i]++;
                    }
                }
            }
            else {
                if(retrans == 0) { //리트랜스미션 시작한 이후에 들어오는 ack는 걸러내기 위해 retrans를 이용해 조절
                    ack_check[ack_index] = 1; // ACK 수신 표시
                    printf("\"%s\" is received. ", buf); //여기는 send할 때 시간이 1씩 증가하니까 증가 x

                    if(send_index == SIZE)
                        printf("\n");
                    timeout_check[ack_index] = 0; //ack를 받았으니 패킷의 시간 0으로 조정
                    send_count--; //한개 받았으니 한개 더 보낼 수 있도록 카운트 1 감소
                    prev_ack = ack_index; //prev_ack 갱신
                }

            }
        }
    }
	pthread_exit(NULL);
}
int sum_of_num(char *str) {
    int sum = 0;
    for(int i=0; i<strlen(str); i++) {
        if(str[i] >= '0' && str[i] <= '9') {
            sum = sum*10 + (str[i]-'0');
        }
    }
    return sum;
}