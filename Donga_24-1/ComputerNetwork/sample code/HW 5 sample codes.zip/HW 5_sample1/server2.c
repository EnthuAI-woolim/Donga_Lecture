#include "Common.h"
#include <sys/select.h>

#define BUFSIZE 1024
#define NUM_PACKETS 5
#define SERVERPORT 9000
#define TIME_UNIT 1
#define TIMEOUT_INTERVAL (TIME_UNIT * 15)

// 패킷 구조체를 정의한다.
struct packet
{
    int packet_num;          // 패킷 번호를 저장할 변수
    int seq_num;             // 시퀀스 번호를 저장할 변수
    int size;                // 패킷의 크기를 저장할 변수
    char data[BUFSIZE];      // 패킷의 데이터를 저장할 배열
    unsigned short checksum; // 체크섬 값을 저장할 변수
};
typedef struct packet Packet;

// 전송할 텍스트 데이터를 배열로 선언한다.
const char *text_arr[NUM_PACKETS] = {
    "I am a boy.",
    "You are a girl.",
    "There are many animals in the zoo.",
    "철수와 영희는 서로 좋아합니다!",
    "나는 점심을 맛있게 먹었습니다."};

// 체크섬 계산 함수를 정의한다.
unsigned short checksum(char *data, int len)
{
    unsigned short *buf = (unsigned short *)data; // 데이터를 unsigned short 포인터로 변환
    unsigned int sum = 0;                         // 체크섬 계산을 위한 합을 저장할 변수 선언
    int count = len >> 1;                         // 데이터 길이를 2로 나누어 16비트 단위로 그룹화

    // 16비트 단위로 데이터를 읽어와 합을 계산한다.
    for (int i = 0; i < count; i++)
    {
        sum += buf[i];
    }

    // 데이터 길이가 홀수인 경우, 마지막 바이트를 처리한다.
    if (len & 1)
    {
        sum += (unsigned char)data[len - 1];
    }

    // 32비트 합을 16비트로 줄이기 위해 상위 16비트와 하위 16비트를 더한다.
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);

    return ~sum; // 1의 보수를 취하고, 최종 체크섬 값을 반환한다.
}

int main()
{
    int server_fd, client_fd; // 서버와 클라이언트의 파일 디스크립터를 저장할 변수
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len;
    Packet packets[NUM_PACKETS]; // 패킷 배열을 선언한다.

    // 패킷 초기화
    for (int i = 0; i < NUM_PACKETS; i++)
    {
        packets[i].packet_num = i;
        packets[i].seq_num = i == 0 ? 0 : packets[i - 1].seq_num + packets[i - 1].size;
        strcpy(packets[i].data, text_arr[i]);
        packets[i].size = strlen(text_arr[i]);
        packets[i].checksum = 0;
    }

    // 서버 소켓을 생성한다.
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == -1)
    {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // 서버 주소 정보를 초기화한다.
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(SERVERPORT);

    // 서버 소켓을 주소에 바인딩한다.
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1)
    {
        perror("bind");
        exit(EXIT_FAILURE);
    }

    // 클라이언트의 연결을 대기한다.
    if (listen(server_fd, 1) == -1)
    {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    printf("서버가 포트 %d에서 연결 대기 중입니다...\n", SERVERPORT); // 서버가 클라이언트의 연결을 대기 중임을 출력한다.

    // 클라이언트의 연결을 수락한다.
    client_len = sizeof(client_addr);
    client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &client_len);
    if (client_fd == -1)
    {
        perror("accept");
        exit(EXIT_FAILURE);
    }

    printf("클라이언트에 연결되었습니다.\n"); // 클라이언트가 연결되었음을 출력한다.

    // 패킷 전송
    for (int i = 0; i < NUM_PACKETS; i++)
    {
        if (i == 1)
        {
            printf("* packet 1 is transmitted. (%s)\n", text_arr[i]); // 과제의 요구사항에 맞게, 패킷 1은 전송하지 않고 출력만 한다.
            usleep(1000);                                             // 1ms 동안 대기한다.
            continue;                                                 // 패킷 1은 전송하지 않고 건너뛴다.
        }

        // 체크섬 계산
        packets[i].checksum = checksum(packets[i].data, packets[i].size);

        // 패킷 전송
        if (send(client_fd, &packets[i], sizeof(Packet), 0) == -1)
        {
            perror("send");
            exit(EXIT_FAILURE);
        }

        printf("* packet %d is transmitted. (%s)\n", i, text_arr[i]); // 전송한 패킷의 번호와 데이터를 출력한다.
        usleep(1000);                                                 // 1ms 동안 대기한다.
    }

    // ACK 수신
    int ack;               // ACK 값을 저장할 변수 선언
    int ack_count = 0;     // 중복 ACK의 개수를 저장할 변수
    int last_ack = -1;     // 마지막으로 수신한 ACK 값을 저장할 변수
    int timeout_flag = 0;  // 타임아웃 발생 여부를 저장할 플래그
    int retransmitted = 0; // 재전송 여부를 저장할 플래그

    while (1)
    {
        fd_set read_fds;
        FD_ZERO(&read_fds);
        FD_SET(client_fd, &read_fds);

        struct timeval timeout;
        timeout.tv_sec = 0;
        timeout.tv_usec = TIMEOUT_INTERVAL * 1000; //  타임아웃 시간을 설정한다. TIME_INTERVAL은 15 * 1000 즉, 15ms로 설정한다.

        int ret = select(client_fd + 1, &read_fds, NULL, NULL, &timeout);
        if (ret == -1)
        {
            perror("select"); // select 함수 실패 시 에러 메시지를 출력하고 프로그램을 종료한다.
            exit(EXIT_FAILURE);
        }
        else if (ret == 0)
        {
            // 타임아웃 발생
            timeout_flag = 1;
        }
        else
        {
            // ACK 수신
            if (recv(client_fd, &ack, sizeof(int), 0) <= 0)
            {
                perror("recv"); // 수신 실패 시 에러 메시지를 출력하고 프로그램을 종료한다.
                exit(EXIT_FAILURE);
            }

            printf("* (ACK=%d) is received.\n", ack); // 수신한 ACK 값을 출력한다.

            // 중복 ACK일 경우 개수를 증가시킨다.
            if (ack == last_ack)
            {
                ack_count++;
                // 아닌 경우 새로운 ACK일 경우 마지막 ACK 값을 갱신하고, 중복 ACK 개수를 1로 초기화한다.
            }
            else
            {
                last_ack = ack;
                ack_count = 1;
            }
        }

        // 동일한 ack가 4번 진입하거나, 타임아웃이 되었을 경우 진입한다.
        // 왜 triple duplicate ACK를 구현하는데 동일한 ack를 4번 받는 것으로 구현하였느냐면, 정상적으로 보낸 ACK 1회, 그리고 패킷 로스로 인하여 반복해서 보내는 ACK 3회를 더하여 4회로 구현하였다.
        if (ack_count == 4 || timeout_flag)
        {
            // 재전송할 패킷 번호 계산
            int retransmit_packet_num = -1;
            for (int i = 0; i < NUM_PACKETS; i++)
            {
                if (packets[i].seq_num + packets[i].size == last_ack)
                {
                    retransmit_packet_num = i + 1; // 재전송할 패킷의 번호를 설정한다.
                    break;
                }
            }

            if (retransmit_packet_num != -1 && retransmit_packet_num < NUM_PACKETS)
            {
                // 재전송할 패킷의 포인터를 설정한다.
                Packet *retransmit_packet = &packets[retransmit_packet_num];

                // 재전송할 패킷의 체크섬을 다시 계산한다.
                retransmit_packet->checksum = checksum(retransmit_packet->data, retransmit_packet->size);

                // 패킷 재전송
                if (send(client_fd, retransmit_packet, sizeof(Packet), 0) == -1)
                {
                    perror("send"); // 재전송 실패 시 에러 메시지를 출력하고 프로그램을 종료한다.
                    exit(EXIT_FAILURE);
                }

                // 재전송한 패킷의 번호와 데이터를 출력한다.
                printf("* packet %d is retransmitted. (%s)\n", retransmit_packet_num, retransmit_packet->data);
                usleep(1000);      // 1ms 동안 대기한다.
                retransmitted = 1; // 재전송 플래그를 1로 설정한다.
            }

            ack_count = 0;
            timeout_flag = 0;
        }

        if (retransmitted)
        {
            usleep(10000);
            close(client_fd);
            break;
        }
    }

    close(server_fd);

    return 0;
}