#include "Common.h"
#include <sys/select.h>

#define BUFSIZE 1024
#define NUM_PACKETS 5
#define SERVERPORT 9000

struct packet
{
    int packet_num;
    int seq_num;
    int size;
    char data[BUFSIZE];
    unsigned short checksum;
};
typedef struct packet Packet;

// 체크섬 계산 함수를 정의한다.
unsigned short checksum(char *data, int len)
{
    unsigned short *buf = (unsigned short *)data; 
    unsigned int sum = 0;                         // 체크섬 계산을 위한 합을 저장할 변수 선언
    int count = len >> 1;                         // 데이터 길이를 2로 나누어 16비트 단위로 그룹화

    // 16비트 단위로 데이터를 읽어와 합을 계산한다.
    for (int i = 0; i < count; i++)
    {
        sum += buf[i];
    }

    // 데이터 길이가 홀수인 경우, 마지막 바이트를 처리한다.
    if (len & 1)
    {
        sum += (unsigned char)data[len - 1];
    }

    // 32비트 합을 16비트로 줄이기 위해 상위 16비트와 하위 16비트를 더한다.
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);

    return sum; // 1의 보수를 제거함
}

// 이진수 형태로 출력하는 함수
void print_binary(unsigned short value)
{
    for (int i = 15; i >= 0; i--)
    {
        printf("%d", (value >> i) & 1);
    }
    printf("\n");
}

int main()
{
    int client_fd;
    struct sockaddr_in server_addr;
    int expected_seq_num = 0; // 예상 시퀀스 번호를 저장할 변수
    int ack = 0;              // ACK 값을 저장할 변수

    // 소켓 생성
    client_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (client_fd == -1)
    {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // 서버 주소 정보 설정
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    server_addr.sin_port = htons(SERVERPORT);

    // 서버에 연결
    if (connect(client_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1)
    {
        perror("connect");
        exit(EXIT_FAILURE);
    }

    printf("서버에 연결되었습니다.\n"); // 서버 연결 성공 메시지 출력

    while (1)
    {
        Packet received_packet;
        // 서버로부터 패킷 수신
        int bytes_received = recv(client_fd, &received_packet, sizeof(Packet), 0);
        if (bytes_received <= 0)
        {
            break; // 수신 실패 시 루프 종료
        }

        // 수신한 체크섬 값을 출력한다. 다만 과제의 요구상 이 부분의 출력을 요구하지 않으므로 주석처리.
        //printf("Received Checksum: ");
        //print_binary(received_packet.checksum);

        // 수신한 데이터를 16비트 이진수화하여 출력한다. 다만 과제의 요구상 이 부분의 출력을 요구하지 않으므로 주석처리.
        unsigned short calculated_checksum = checksum(received_packet.data, received_packet.size);
        //printf("Calculated data: ");
        //print_binary(calculated_checksum); // 1의 보수를 취하지 않은 값을 출력

        char received_data[BUFSIZE];
        memcpy(received_data, received_packet.data, received_packet.size);

        // 수신한 체크섬과 계산된 데이터의 합이 1111111111111111인지 확인한다.
        if ((calculated_checksum + received_packet.checksum) == 0xFFFF)
        {
            int packet_num = received_packet.packet_num;
            int seq_num = received_packet.seq_num;
            char *data = received_packet.data;

            // 예상 시퀀스 번호와 일치하는지 확인
            if (seq_num == expected_seq_num)
            {
                printf("* packet %d is received and there is no error. (%s)", packet_num, data);
                ack = seq_num + received_packet.size; // ACK 값 계산
                printf(" (ACK=%d) is transmitted.\n", ack);

                // ACK 전송
                if (send(client_fd, &ack, sizeof(int), 0) == -1)
                {
                    perror("send");
                    exit(EXIT_FAILURE);
                }

                expected_seq_num = ack; // 다음 예상 시퀀스 번호 업데이트
            }
            else
            {
                // 예상 시퀀스 번호와 일치하지 않는 경우 (중복 패킷 수신)
                printf("* packet %d is received and there is no error. (%s)", packet_num, data);
                ack = expected_seq_num; // 이전 ACK 값 사용
                printf(" (ACK=%d) is transmitted.\n", ack);

                // ACK 전송
                if (send(client_fd, &ack, sizeof(int), 0) == -1)
                {
                    perror("send");
                    exit(EXIT_FAILURE);
                }
            }
        }
        else
        {
            // 체크섬이 일치하지 않는 경우 (오류 발생)
            printf("* Packet %d: Checksum is invalid. Packet corrupted.\n", received_packet.packet_num);
        }
    }

    close(client_fd); // 소켓 닫기

    return 0;
}