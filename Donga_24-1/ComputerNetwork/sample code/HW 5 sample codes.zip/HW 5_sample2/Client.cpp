#include <stdio.h>
#include <string.h>
#include "Common.h"

char *TARGET_IP = (char *)"127.0.0.1"; 

#define TARGET_PORT 9000     
#define BUFFER_SIZE 512      
#define ACK_BUFFER_SIZE 5

int total_sequence = 0;
int elapsed_time = 0;
int retry_interval = 15;

// 보낼 패킷 구조체 정의
struct DataPacket {
    int id;
    char content[100];
    int size;
    int checksum;
    int seq_num;
};

// 멀티바이트 문자 체크 (한글 포함)
bool is_multibyte_char(char c) {
    return (c & 0xC0) == 0x80;
}

// 문자열의 바이트 수 계산
int count_bytes(const char* str) {
    int count = 0;
    while (*str) {
        if (!is_multibyte_char(*str))
            count++;
        str++;
    }
    return count;
}

// 체크섬 계산
int compute_checksum(const char* str) {
    int checksum = 0;
    for (int i = 0; i < strlen(str); i++) {
        int ascii_val = (int)str[i];
        int binary_val = 0;
        int multiplier = 1;
        
        while (ascii_val > 0) {
            binary_val += (ascii_val % 2) * multiplier;
            ascii_val /= 2;
            multiplier *= 10;
        }

        checksum += binary_val;
    }
    return checksum;
}

int main(int argc, char *argv[]) {

    struct DataPacket data_packets[5];

    // 패킷의 문자열 초기화
    strcpy(data_packets[0].content, "I am a boy.");
    strcpy(data_packets[1].content, "You are a girl.");
    strcpy(data_packets[2].content, "There are many animals in the zoo.");
    strcpy(data_packets[3].content, "철수와 영희는 서로 좋아합니다!");
    strcpy(data_packets[4].content, "나는 점심을 맛있게 먹었습니다.");

    // 각 패킷 번호, 바이트 수, 시퀀스 번호 초기화
    for (int i = 0; i < 5; i++) {
        data_packets[i].id = i;
        data_packets[i].size = count_bytes(data_packets[i].content);
        data_packets[i].checksum = 0;
        data_packets[i].seq_num = 0;
    }

    int retval;

    if (argc > 1) TARGET_IP = argv[1];

    // 소켓 생성
    SOCKET socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_fd == INVALID_SOCKET) err_quit("socket()");

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    inet_pton(AF_INET, TARGET_IP, &server_addr.sin_addr);
    server_addr.sin_port = htons(TARGET_PORT);

    retval = connect(socket_fd, (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (retval == SOCKET_ERROR) err_quit("connect()");

    // 처음 받아야 할 ACK 값 초기화
    int expected_ack = data_packets[0].size;

    int temp_ack = 0;
    int duplicate_ack_count = 0;
    int current_packet_index = 0;

    while (1) {
        // 5개 패킷 전송
        for (int i = 0; i < 5; i++) {
            // 시퀀스 넘버 설정
            data_packets[i].seq_num = total_sequence;

            // 체크섬 계산
            data_packets[i].checksum = compute_checksum(data_packets[i].content);

            // 패킷 전송
            retval = send(socket_fd, &data_packets[i], sizeof(struct DataPacket), 0);
            if (retval == SOCKET_ERROR) {
                err_display("send()");
                break;
            }

            elapsed_time++;

            printf("packet %d is transmitted. (%s)\n", i, data_packets[i].content);

            // 다음 시퀀스 넘버 계산
            total_sequence += data_packets[i].size;
        }

        while (elapsed_time < retry_interval) {
            int received_ack = 0;

            retval = recv(socket_fd, &received_ack, sizeof(received_ack), 0);
            if (retval == SOCKET_ERROR) {
                err_display("recv()");
                break;
            } else if (retval == 0) {
                break;
            }

            // 예상된 ACK와 받은 ACK가 같으면 처리
            if (expected_ack == received_ack) {
                temp_ack = data_packets[current_packet_index].size;
                expected_ack = data_packets[current_packet_index + 1].size;
                current_packet_index++;
            } else if ((expected_ack != received_ack) && (temp_ack == received_ack)) {
                // 중복된 ACK 처리
                duplicate_ack_count++;
            }

            printf("(ACK =%d) is received.\n", received_ack);

            // 중복된 ACK가 3번 연속 수신된 경우
            if (duplicate_ack_count == 3) {
                duplicate_ack_count = 0;
                retval = send(socket_fd, &data_packets[current_packet_index], sizeof(struct DataPacket), 0);
                if (retval == SOCKET_ERROR) {
                    err_display("send()");
                    break;
                }
                elapsed_time++;
                printf("packet %d is retransmitted. (%s)\n", current_packet_index, data_packets[current_packet_index].content);
                break;
            }
        }
        break;
    }

    // 소켓 닫기
    sleep(1);
    close(socket_fd);
    return 0;
}
