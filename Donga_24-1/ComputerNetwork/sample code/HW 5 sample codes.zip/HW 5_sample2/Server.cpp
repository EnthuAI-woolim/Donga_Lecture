#include <stdio.h>
#include <string.h>
#include "Common.h"

#define TARGET_PORT 9000 
#define BUFFER_SIZE 512  
#define PACKET_DATA_SIZE 8

int next_expected_packet = 0; 
int ack_to_send = 0;   
int lost_packet = 1;   
int loss_flag = 0;  
int cumulative_sequence = 0;  

// 패킷 정보 구조체
struct DataPacket {
    int id;
    char content[100];
    int size;
    int checksum;
    int seq_num;
};

// 체크섬 계산
int compute_checksum(const char* str) {
    int checksum = 0;
    for (int i = 0; i < strlen(str); i++) {
        int ascii_val = (int)str[i]; 
        int binary_val = 0;
        int multiplier = 1;
        
        while (ascii_val > 0) {
            binary_val += (ascii_val % 2) * multiplier;
            ascii_val /= 2;
            multiplier *= 10;
        }

        checksum += binary_val;
    }
    return checksum;
}

int main(int argc, char *argv[])
{
   int retval;

   SOCKET server_socket = socket(AF_INET, SOCK_STREAM, 0);   
   if (server_socket == INVALID_SOCKET) err_quit("socket()");  

   // bind()
   struct sockaddr_in server_address;     
   memset(&server_address, 0, sizeof(server_address));     
   server_address.sin_family = AF_INET;    
   server_address.sin_addr.s_addr = htonl(INADDR_ANY);     
   server_address.sin_port = htons(TARGET_PORT);    
    
   retval = bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address));  
   if (retval == SOCKET_ERROR) err_quit("bind()");  

   // listen()
   retval = listen(server_socket, SOMAXCONN);   
   if (retval == SOCKET_ERROR) err_quit("listen()");  

   // 데이터 통신에 사용할 변수
   SOCKET client_socket;   
   struct sockaddr_in client_address;
   socklen_t addrlen;
   char buffer[BUFFER_SIZE + 1];

   while (1) {
      addrlen = sizeof(client_address);   
      client_socket = accept(server_socket, (struct sockaddr *)&client_address, &addrlen); 
      if (client_socket == INVALID_SOCKET) {    
         err_display("accept()");
         break;
      }

      struct DataPacket received_packet;

      while (1) {
         int computed_checksum = 0;

         retval = recv(client_socket, &received_packet, sizeof(struct DataPacket), 0); 
         if (retval == SOCKET_ERROR) {
             err_display("recv()");  
             break;
         } else if (retval == 0) {
             break;              
         }

         // 패킷 유실 가정
         if ((next_expected_packet == lost_packet) && (loss_flag == 0)) {
             loss_flag = 1;
             continue;
         }

         // 받은 데이터의 체크섬 계산
         computed_checksum = compute_checksum(received_packet.content);

         // 체크섬 확인
         if (computed_checksum == received_packet.checksum) {
             printf("packet %d is received and there is no error. (%s)\n", received_packet.id, received_packet.content);
         } else {
             printf("Checksum error\n");
             break;
         }

         // 기대한 패킷이 도착한 경우 ACK 업데이트
         if (received_packet.id == next_expected_packet) {
             ack_to_send = received_packet.size;
         }

         // 기대한 패킷이 아닌 경우 이전 ACK 전송
         if (received_packet.id != next_expected_packet) {
             int ack_buffer = ack_to_send;
             retval = send(client_socket, &ack_buffer, sizeof(ack_buffer), 0);  
             if (retval == SOCKET_ERROR) {   
                 err_display("send()");
                 break;
             }
             printf("(ACK = %d) is transmitted.\n", ack_buffer);
         } else {
             cumulative_sequence += received_packet.size;
             int ack_buffer = cumulative_sequence;
             retval = send(client_socket, &ack_buffer, sizeof(ack_buffer), 0);  
             if (retval == SOCKET_ERROR) {   
                 err_display("send()");
                 break;
             }
             printf("(ACK = %d) is transmitted.\n", ack_buffer);
             next_expected_packet++;
         }
      }
      close(client_socket);
      break;
   }

   close(server_socket);
   return 0;
}
