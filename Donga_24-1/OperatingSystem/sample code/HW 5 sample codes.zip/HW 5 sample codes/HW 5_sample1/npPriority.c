#include "schedule.h"

#define N 5

Node* calculateRealtime(Node* Head);
void processing(Process process);

int main(void) {

    // set head
    Node* Q = NULL;
    Node* head = (Node*)malloc(sizeof(Node));
    head->next = NULL;
    InsertNewHead(&Q, head);

    // 입력부
    printf("준비 큐 입력\n");
    printf("번호 | 도착 시간 | 실행 시간 | 우선 순위\n");
    for (int i = 0; i < N; i++) {
        Node* node = (Node*)malloc(sizeof(Node));
        scanf("%d %d %d %d", &node->process.no, &node->process.arrive, &node->process.runtime, &node->process.priority);

        node->next = NULL;
        Node* before = GetNodeAt(Q, i);
        InsertAfter(before, node);
    }
    printf("===================\n");
    printf("간트 차트\n");
    
    Node* NewQ = calculateRealtime(Q);

    int returnTime[N];
    int waitingTime[N];
    double avgRetTime = 0.0;
    double avgwaitTime = 0.0;
    for (int i = 0; i < N; i++) {
        Node* Current = GetNodeAt(NewQ, i+1);
        printf("P%d (%d-%d)\n", Current->process.no, Current->process.rt.start, Current->process.rt.end);
        returnTime[Current->process.no - 1] = Current->process.rt.end - Current->process.arrive;
        waitingTime[Current->process.no - 1] = Current->process.rt.start - Current->process.arrive;
        avgRetTime += returnTime[Current->process.no - 1];
        avgwaitTime += waitingTime[Current->process.no - 1];
    }

    avgRetTime = avgRetTime / N;
    avgwaitTime = avgwaitTime / N;

    printf("===================\n");
    printf("반환 시간 | 대기 시간\n");

    for (int i = 0; i < N; i++) {
        printf("%2d        | %2d\n", returnTime[i], waitingTime[i]);
    }

    printf("전체 평균 반환시간: %.2lf\n", avgRetTime);
    printf("전체 평균 대기시간: %.2lf\n", avgwaitTime);
    printf("===================\n\n");
    printf("스케줄 실행\n");
    printf("===================\n");

    pid_t pid;

    int status;
    Node* Current = NewQ->next;
    while(Current != NULL) {
        pid = fork();
        if (pid == 0) {
            processing(Current->process);
            exit(2);
        } else {
            while(wait(&status) != pid) continue;
        }
        Current = Current->next;
    }
    return 0;
}

// 실제 실행에 필요한 시간 계산
Node* calculateRealtime(Node* Head) {
    Node* NewQ = NULL;
    Node* head = (Node*)malloc(sizeof(Node));
    head->next = NULL;
    InsertNewHead(&NewQ, head);

    Node* before = head;

    int t = 0;
    while(GetNodeCount(Head) > 1) {
        Node* cur = Head->next->next;
        Node* Prior = Head->next;

        while(cur != NULL) {
            if (cur->process.arrive <= t && cur->process.priority > Prior->process.priority) {
                Prior = cur;
            }
            cur = cur->next;
        }

        Node* NewNode = (Node*)malloc(sizeof(Node));
        NewNode->next = NULL;
        NewNode->process = Prior->process;

        NewNode->process.rt.start = before->process.rt.end;
        NewNode->process.rt.end = NewNode->process.rt.start + NewNode->process.runtime;
        t = NewNode->process.rt.end;

        InsertAfter(before, NewNode);
        RemoveNode(&Head, Prior);

        before = before->next;
    }

    return NewQ;
}

// 스레드 함수
void processing(Process process) {
    
    for (int i = 1; i <= process.rt.end-process.rt.start; i++) {
        printf("P%d: %d X %d = %d\n", process.no, i, process.no, i * process.no);
    }

}

// head 부분에 새 헤드 삽입
void InsertNewHead(Node** Head, Node* NewHead) {
    if (Head == NULL) {
        (*Head) = NewHead;
    } else {
        NewHead->next = (*Head);
        (*Head) = NewHead;
    }
}

// Current 뒤에 새 노드 삽입
void InsertAfter(Node* Current, Node* NewNode) {
    NewNode->next = Current->next;
    Current->next = NewNode;
}

// Location 위치의 노드를 반환
Node* GetNodeAt(Node* Head, int Location) {
    Node* Current = Head;
    while (Current != NULL && (--Location) >= 0) {
        Current = Current->next;
    }

    return Current;
}

int GetNodeCount(Node* Head) {
    int Count = 0;
    Node* Current = Head;
    while (Current != NULL) {
        Current = Current->next;
        Count++;
    }

    return Count;
}

void RemoveNode(Node** Head, Node* Remove) {
    if (*Head == Remove) {
        *Head = Remove->next;
    } else {
        Node* Current = *Head;
        while (Current != NULL && Current->next != Remove) {
            Current = Current->next;
        }

        if(Current != NULL) {
            Current->next = Remove->next;
        }
    }
    free(Remove);
}