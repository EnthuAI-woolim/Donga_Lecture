#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

char gantt[500];    //간트차트 저장 버퍼
typedef struct Process {    //큐 처리를 위한 링크드 리스트 구조체
    int id;                 //P1,P2 등 프로세스 이름
    int arrivalTime;        //도착 시간
    int executeTime;        //실행 시간
    int remainingTime;      //남은 시간
    int waitTime;           //대기 시간
    int returnTime;         //반환시간
    struct Process *next;   //링크드 리스트 사용
} Process;

typedef struct {
    Process *head;
} LinkedList;

void appendProcess(LinkedList *list, int id, int arrival, int burst) {  //프로세스를 도착 시간 순으로 리스트에 삽입
    Process *new_node = (Process *)malloc(sizeof(Process));
    new_node->id = id;
    new_node->arrivalTime = arrival;
    new_node->executeTime = burst;
    new_node->remainingTime = burst;
    new_node->waitTime = 0;
    new_node->returnTime = 0;
    new_node->next = NULL;

    if (list->head == NULL || list->head->arrivalTime > arrival) {
        //첫번째 들어온 노드이거나 들어온 노드의 도착시간이 이전 노드의 도착시간 보다 빠르다면
        new_node->next = list->head;    //현재노드가 앞으로 온다.
        list->head = new_node;
    } else {    //도착 순대로 링크드리스트에 삽입
        Process *current = list->head;
        while (current->next != NULL && current->next->arrivalTime <= arrival) {
            current = current->next;
        }
        new_node->next = current->next;
        current->next = new_node;
    }
}

int finishProcess(LinkedList *list) {   //모든 프로세스 완료시
    Process *current = list->head;
    while (current) {
        if (current->remainingTime > 0) {
            return 0;  //남은 시간이 없는 프로세스 종료
        }
        current = current->next;
    }
    return 1;
}

void roundRobin(LinkedList *list, int quantum) {    //라운드 로빈 스케줄링 실행
    Process *current = list->head;
    int currentTime = 0;
    pid_t pid;

    while (!finishProcess(list)) {  //모든 프로세스가 종료되기 전까지
        if (current == NULL) {
            current = list->head;  //프로세스가 종료되기 전까지 처음부터 다시 시작
        }
        if (current->remainingTime > 0 && current->arrivalTime <= currentTime) {    //실행시간이 아직 남았다면
            int runTime = (current->remainingTime < quantum) ? current->remainingTime : quantum;
            //규정 시간량보다 작게 남았으면 남은 시간만큼, 아니라면 규정시간량만큼만 실행
            sprintf(gantt+strlen(gantt),"P%d (%d-%d)\n", current->id, currentTime, currentTime + runTime);
            //간트차트 버퍼에 저장
            current->remainingTime -= runTime;  //규정시간량 실행 후 남은시간에서 빼기
            currentTime += runTime;

            if (current->remainingTime == 0) {  //남은시간이 없다면
                current->returnTime = currentTime - current->arrivalTime;   //반환시간 저장
                current->waitTime = current->returnTime - current->executeTime; //대기시간 저장
            }

            pid = fork();
            if (pid == 0) { //자식 프로세스에서 곱 계산
                for (int i = 1; i <= runTime; i++) {
                    printf("P%d: %d X %d = %d\n", current->id, i, current->id, i * current->id);
                }
                exit(0);
            } else if (pid > 0) { //부모 프로세스면
                wait(NULL);     //자식이 종료될때까지 대기
            } else {
                fprintf(stderr, "Failed to fork\n");
                exit(1);
            }
        }
        current = current->next;
    }
}

void printTimes(LinkedList *queue) {    //프로세스의 대기시간, 반환시간 출력
    float totalReturn = 0.0, totalWait = 0.0;
    int count = 0;
    Process *p = queue->head;

    while (p != NULL) {
        printf("P%d: Return Time = %d, Waiting Time = %d\n", p->id, p->returnTime, p->waitTime);
        totalReturn += p->returnTime;
        totalWait += p->waitTime;
        count++;
        p = p->next;
    }

    if (count > 0) {
        printf("Average Return Time: %.2f\n", totalReturn / count);
        printf("Average Waiting Time: %.2f\n", totalWait / count);
    }
}


int main() {
    LinkedList processList = {NULL};
    appendProcess(&processList, 1, 0, 10);
    appendProcess(&processList, 2, 1, 28);
    appendProcess(&processList, 3, 2, 6);
    appendProcess(&processList, 4, 3, 4);
    appendProcess(&processList, 5, 4, 14);

    roundRobin(&processList, 5);    //규정시간량은 5
    printf("%s",gantt);     //간트차트 출력
    printTimes(&processList);   //프로세스 대기시간, 반환시간 출력

    Process *temp;
    while (processList.head != NULL) {  //메모리 해제
        temp = processList.head;
        processList.head = temp->next;
        free(temp);
    }

    return 0;
}
