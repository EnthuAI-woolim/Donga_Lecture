#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

char gantt[500];    //간트차트 저장 버퍼
typedef struct Process {    //큐 처리를 위한 링크드 리스트 구조체
    int id;                 //P1,P2 등 프로세스 이름
    int arrivalTime;        //도착 시간
    int executeTime;        //실행 시간
    int remaining;          //남은 시간
    int startTime;          //시작 시간
    int endTime;            //끝나는 시간
    int priority;           //우선 순위
    int check;              //선점시 체크 위한 변수
    struct Process *next;   //링크드 리스트사용
} Process;

typedef struct {
    Process *head;
} LinkedList;

void appendProcess(LinkedList *list, int id, int priority, int arrival, int burst) {  //프로세스를 도착 시간 순으로 리스트에 삽입
    Process *new_node = (Process*) malloc(sizeof(Process));
    new_node->id = id;
    new_node->priority = priority;
    new_node->arrivalTime = arrival;
    new_node->executeTime = burst;
    new_node->remaining = burst;
    new_node->startTime = 1;
    new_node->endTime = 0;
    new_node->check = 0;
    new_node->next = NULL;

    if (list->head == NULL || list->head->arrivalTime > arrival) {
        //첫번째 들어온 노드이거나 들어온 노드의 도착시간이 이전 노드의 도착시간 보다 빠르다면
        new_node->next = list->head;    //현재노드가 앞으로 온다.
        list->head = new_node;
    } else {    //도착 순대로 링크드리스트에 삽입
        Process *current = list->head;
        while (current->next != NULL && current->next->arrivalTime <= arrival) {
            current = current->next;
        }
        new_node->next = current->next;
        current->next = new_node;
    }
}

void printTimes(LinkedList *completed_list) {   //프로세스의 반환시간, 대기시간 계산 및 출력
    float totalReturn = 0.0, totalWait = 0.0;
    int count = 0;
    Process *iter = completed_list->head;

    while (iter) {
        int back = iter->endTime - iter->arrivalTime;
        int waiting = iter->endTime - iter->arrivalTime - iter->executeTime;
        printf("P%d: Return Time = %d, Waiting Time = %d\n", iter->id, back, waiting);
        totalReturn += back;
        totalWait += waiting;
        count++;
        iter = iter->next;  //다음 노드의 반환시간, 대기시간 사용
    }

    if (count > 0) {
        printf("Average Return Time: %.2f\n", totalReturn / count); //평균 반환 시간
        printf("Average Waiting Time: %.2f\n", totalWait / count);  //평균 대기 시간 
    }
}

void multiplyRange(Process *p, int current_time) {
    if(p->check==0){
        for (int i = p->startTime; i <= current_time-p->endTime; i++) {
            //선점으로 들어온 프로세스가 아닐때
            printf("P%d: %d X %d = %d\n",p->id, i, p->id, i*p->id);
        }
    }else{
        for (int i = p->startTime; i < p->startTime+current_time-p->endTime; i++) {
            //선점으로 들어온 프로세스일 때
            printf("P%d: %d X %d = %d\n",p->id, i, p->id, i*p->id);
        }
    }
}

void makePriority(LinkedList *list, LinkedList *completed_list) {   //선점 우선순위 스케줄링 계산 함수
    int current_time = 0;
    Process *current = NULL;
    pid_t pid;
    int status;

    while (list->head) {    //리스트에 노드가 남아있을때까지 실행
        Process *highpriority = NULL;
        Process **iter = &list->head;

        while (*iter) {
            if ((*iter)->arrivalTime <= current_time && (highpriority == NULL || (*iter)->priority > highpriority->priority)) {
                //현재노드의 도착시간이 현재시간보다 작고 우선순위가 가장 높은 프로세스를 선택
                highpriority = *iter;
            }
            iter = &(*iter)->next;
        }

        if (highpriority && (!current || highpriority->priority > current->priority)) {
            //highpriority가 존재하고 현재 프로세스가 없거나 우선순위가 높은 프로세스이면 선점
            if (current && current->endTime < current_time) {
                sprintf(gantt+strlen(gantt),"P%d (%d-%d)\n", current->id, current->endTime, current_time);
                //간트차트 버퍼에 저장
                pid = fork();
                if (pid == 0) { //자식 프로세스에서 곱 계산
                    multiplyRange(current,current_time);
                    exit(0); //자식 프로세스 완료되면 종료
                } else if (pid > 0) { //부모 프로세스면
                    wait(&status); //자식이 종료될때까지 대기
                } else {
                    fprintf(stderr, "Failed to fork\n");
                    exit(1);
                }
                current->check++;   //선점이므로 check에 표시
                current->startTime = current_time+1;//선점시 끝난 부분의 다음부터 시작하기 위함
            }
            current = highpriority;
            current->endTime = current_time;
        }

        if (current) {
            current->remaining--;
            current_time++;

            if (current->remaining == 0) {  //남은시간이 0이 되면 종료
                sprintf(gantt+strlen(gantt),"P%d (%d-%d)\n", current->id, current->endTime, current_time);
                //간트차트 버퍼에 저장
                pid = fork();
                if (pid == 0) { //자식 프로세스에서 곱 계산
                    multiplyRange(current,current_time);
                    exit(0); //자식 프로세스 완료되면 종료
                } else if (pid > 0) { //부모 프로세스면
                    wait(&status); //자식이 종료될때까지 대기
                } else {
                    fprintf(stderr, "Failed to fork\n");
                    exit(1);
                }
                current->endTime = current_time; //실행이 끝나는 시간 저장
                iter = &list->head;
                while (*iter != current) iter = &(*iter)->next;
                *iter = current->next; //실행 완료된 프로세스 제거

                current->next = completed_list->head;   //반환시간 계산시 사용할 completed_list에 추가
                completed_list->head = current;
                current = NULL;
            }
        } else {
            current_time++;
        }
    }
}

int main() {
    LinkedList active_list = {NULL};
    LinkedList completed_list = {NULL};

    appendProcess(&active_list, 1, 3, 0, 10);
    appendProcess(&active_list, 2, 2, 1, 28);
    appendProcess(&active_list, 3, 4, 2, 6);
    appendProcess(&active_list, 4, 1, 3, 4);
    appendProcess(&active_list, 5, 2, 4, 14);

    makePriority(&active_list, &completed_list);    //선점 우선 순위 스케줄링 계산
    printf("%s",gantt);                   //간트차트 출력
    printTimes(&completed_list);                //반환시간, 대기시간 출력

    // 메모리 해제
    while (completed_list.head != NULL) {   // 메모리 해제
        Process *temp = completed_list.head;
        completed_list.head = completed_list.head->next;
        free(temp);
    }

    return 0;
}
