#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

typedef struct Process {    //큐 처리를 위한 링크드 리스트 구조체
    int id;                 //P1,P2 등 프로세스 이름
    int priority;           //우선순위
    int arrivalTime;        //도착 시간
    int executeTime;        //실행 시간
    int startTime;          //시작 시간
    int endTime;            //끝나는 시간
    int returnTime;         //반환 시간
    int waitTime;           //대기 시간
    struct Process *next;   //링크드 리스트 사용
} Process;

typedef struct {
    Process *head;
} PriorityQueue;

void appendProcess(PriorityQueue *queue, int id, int priority, int arrival, int burst) {
    Process *new_node = (Process*) malloc(sizeof(Process));
    new_node->id = id;
    new_node->priority = priority;
    new_node->arrivalTime = arrival;
    new_node->executeTime = burst;
    new_node->startTime = -1;
    new_node->endTime = 0;
    new_node->next = NULL;

    Process **iter = &queue->head;     //프로세스를 우선순위에 따라 추가
    while (*iter != NULL && ((*iter)->priority > priority || ((*iter)->priority == priority && (*iter)->arrivalTime <= arrival))) {
        //우선순위가 높은 순대로 링크드리스트에 삽입 만약 우선순위가 같다면 먼저 도착한 순서대로 링크드리스트에 삽입
        iter = &(*iter)->next;
    }
    new_node->next = *iter;
    *iter = new_node;
}

void makePriority(Process **headRef) {
    Process *head = *headRef;   //링크드 리스트의 시작노드를 가리킴
    Process *current, *selected, *prev, *prevSelected = NULL;   //current 현재 검토하고 있는 노드, selected 최종 선택된 노드,
    //prev는 current포인터가 가리키는 이전 노드, prevSelected는 selected가 가리키는 이전 노드
    Process *completed = NULL, *lastCompleted = NULL;   //completed는 완료된 프로세스 목록의 헤드, lastCompleted는 완료된 프로세스 목록의 마지막 노드
    int currentTime = 0;

    while (head) {  //리스트에 노드가 남아있을때까지 실행
        current = head;
        selected = NULL;
        prev = NULL;
        
        while (current) {
            if (current->arrivalTime <= currentTime && (!selected || current->priority > selected->priority)) {
                //현재노드의 도착시간이 현재시간보다 작고 우선순위가 가장 높은 프로세스를 선택
                selected = current;     //조건에 맞는 노드 selected에 저장
                prevSelected = prev;    //노드가 결정 될 때 selected의 이전 노드 저장
            }
            prev = current; //current가 움직일때 그 이전 노드 저장
            current = current->next;    //각각의 노드들을 차례대로 검사
        }

        if (!selected) {    //선택되지 않았으면 현재시간을 더한다
            currentTime++;  //실행가능한 프로세스가 없을 때 도착할때까지 currentTime 움직인다
            continue;
        }

        selected->startTime = currentTime;      //시작시간
        selected->endTime = selected->startTime + selected->executeTime;    //끝나는 시간은 시작시간과 실행시간의 합
        selected->returnTime = selected->endTime - selected->arrivalTime;   //반환 시간은 끝나는 시간 - 도착시간
        selected->waitTime = selected->startTime - selected->arrivalTime;   //대기시간은 시작시간 - 도착시간
        currentTime = selected->endTime;    //현재시간은 이전노드의 끝나는 시간

        if (selected == head) { //선택된 노드가 리스트의 첫번째 노드라면
            head = selected->next;  //헤드포인터 다음 노드로 이동
        } else if (prevSelected) {  //선택된 노드가 첫번째 노드가 아니고 선택된 노드의 이전노드가 존재한다면
            prevSelected->next = selected->next;    //selected 노드를 리스트에서 삭제
        }
        selected->next = NULL;  //selected노드는 어떠한 리스트와도 연결되지 않는다

        if (lastCompleted) {    //완료된 프로세스 목록에 노드가 있다면
            lastCompleted->next = selected; //새로 완료된 리스트가 완료된 리스트 뒤에 저장
        } else {        //완료된 프로세스 목록이 비어있다면
            completed = selected;   //selected가 첫번째 노드로 들어간다
        }
        lastCompleted = selected;   //selected노드를 완료된 리스트의 새로운 마지막 노드로 설정
    }

    *headRef = completed;   //완료된 프로세스 목록이 원래 리스트를 대체
}

void printGantt(PriorityQueue *queue) {     //간트차트 출력
    Process *p = queue->head;
    int currentTime = 0;
    while (p != NULL) {
        p->startTime = currentTime;
        p->endTime = currentTime + p->executeTime;
        printf("P%d (%d-%d)\n", p->id, p->startTime, p->endTime);
        currentTime += p->executeTime;
        p = p->next;
    }
}

void printTimes(PriorityQueue *queue) {     //프로세스의 반환시간, 대기시간 출력
    float totalReturn = 0.0, totalWait = 0.0;
    int count = 0;
    Process *p = queue->head;

    while (p != NULL) {
        printf("P%d: Return Time = %d, Waiting Time = %d\n", p->id, p->returnTime, p->waitTime);
        totalReturn += p->returnTime;
        totalWait += p->waitTime;
        count++;
        p = p->next;
    }

    if (count > 0) {
        printf("Average Return Time: %.2f\n", totalReturn / count);
        printf("Average Waiting Time: %.2f\n", totalWait / count);
    }
}

void multiplyRange(Process *p) {
    for (int i = 1; i <= p->executeTime; i++) {
        printf("P%d: %d X %d = %d\n",p->id, i, p->id, i*p->id);
    }
}


int main() {
    PriorityQueue queue = {NULL};
    pid_t pid;

    appendProcess(&queue, 1, 3, 0, 10); //P1, 우선순위, 도착시간, 실행시간
    appendProcess(&queue, 2, 2, 1, 28);  //P2, 우선순위, 도착시간, 실행시간
    appendProcess(&queue, 3, 4, 2, 6); //P3, 우선순위, 도착시간, 실행시간
    appendProcess(&queue, 4, 1, 3, 4); //P4, 우선순위, 도착시간, 실행시간
    appendProcess(&queue, 5, 2, 4, 14);  //P5, 우선순위, 도착시간, 실행시간

    makePriority(&queue.head);
    printGantt(&queue);
    printTimes(&queue);

    Process *iter = queue.head;
    int status;
     for (int i = 0; iter != NULL && i < 5; i++, iter= iter->next) {
        pid = fork();

        if (pid == 0) {
            multiplyRange(iter);
            exit(0);
        }else if (pid > 0) {
            wait(&status);      // 자식 프로세스 종료시까지 부모 프로세스 대기
        } else {
            fprintf(stderr, "Failed to fork\n");
            exit(1);
        }
    }

    Process *current;
    while (queue.head != NULL) {    //메모리 해제
        current = queue.head;
        queue.head = current->next;
        free(current);
    }

    return 0;
}
