#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define PN 3

typedef struct Realtime {
    int start;
    int end;
} Realtime;

// 구조체 정의
typedef struct Process {
    int pid;             // 프로세스 ID
    int running_time;      // 실행 시간
    int ran_time; // 누적 실행시간
    Realtime rt;
} Process;

typedef struct Node {
    Process process;
    struct Node* next;
    int turnaround_time;
} Node;

void insert_head(Node** Head, Node* NewHead);
void enqueue(Node* Current, Node* NewNode);
Node* GetNode(Node* Head, int Location);
int GetNodeCount(Node* Head);
void dequeue(Node** Head, Node* Remove);

Node* find_Queue(Node* Head, int Location);
Node* find_parent(Node* Head, Node* Current);
Node* find_lastnode(Node* Head);

Node* MLFQ(Node* Head);
Node* RoundRobin(Node* Head);
void fun(Node* Current, int ran);

int main(void) {
   
    Node* Q = NULL;
    Node* head = (Node*)malloc(sizeof(Node));
    head->next = NULL;
    insert_head(&Q, head);

    Node* Q2 = NULL;
    Node* head2 = (Node*)malloc(sizeof(Node));
    head2->next = NULL;
    insert_head(&Q2, head2);

    Process process[] = {
        {1, 30},
        {2, 20},
        {3, 10}
    };

    for(int i=0; i<PN; i++){
        Node* node = (Node*)malloc(sizeof(Node));
        Node* node2 = (Node*)malloc(sizeof(Node));

        node->process.pid = process[i].pid;
        node->process.running_time = process[i].running_time;

        node->process.pid = i+1;
        node2->process.pid = node->process.pid;
        node2->process.running_time = node->process.running_time;

        node2->next = NULL;
        node->next = NULL;

        Node *before = GetNode(Q, i);
        Node* before2 = GetNode(Q2, i);

        enqueue(before2, node2);
        enqueue(before, node);
    }

    // 간트 차트 출력
    printf("\n===== 간트차트 출력 =====\n\n");
    
    Node* result_MLFQ = MLFQ(Q);
    Node* result_RR = RoundRobin(Q2);

    printf("1. Round Robin\n");
    printf("-------\n\n");
    
    int RRcount = GetNodeCount(result_RR->next);
    int RR_returntime[3]; // 반환 시간
    int RR_waitingtime[3]; // 대기 시간
    double RR_avg_returntime = 0.0;
    double RR_avg_waitingtime = 0.0;
    for (int i = 0; i < RRcount; i++) {
        // 간트 차트 출력
        Node* Current = GetNode(result_RR, i+1);
        printf("P%d (%d-%d)\n", Current->process.pid, Current->process.rt.start, Current->process.rt.end);
    }
    
    for (int i = 1; i <= 3; i++) {
        int processed_time[3][3] = {{0,},};
        int processed = 0;
        Node* Current = NULL;
        Node* node = GetNode(result_RR, 1);
        while (node != NULL) {
            if (node->process.pid == i) {
                Current = node;
              
                if ((Current->process.rt.end - Current->process.rt.start) > 0)
                    processed_time[i-1][processed] = (Current->process.rt.end - Current->process.rt.start);
                
                processed++;
            }
            node = node->next;
        }
        for (int j = 0; j < 2; j++) {
            if (processed_time[i-1][j+1] == 0) break;
            processed_time[i-1][2] += processed_time[i-1][j];
        }

        RR_returntime[i-1] = Current->process.rt.end;
        RR_waitingtime[i-1] = Current->process.rt.start - processed_time[i-1][2];
        RR_avg_returntime += RR_returntime[i-1];
        RR_avg_waitingtime += RR_waitingtime[i-1];
    }

    RR_avg_returntime = RR_avg_returntime / 3;
    RR_avg_waitingtime = RR_avg_waitingtime / 3;

    int MLFQcount = GetNodeCount(result_MLFQ);
    int MLFQ_returntime[3]; // 반환 시간
    int MLFQ_waitingtime[3]; // 대기 시간
    double MLFQ_avg_returntime = 0.0;
    double MLFQ_avg_waittime = 0.0;

    printf("--------\n");
    printf("2. MLFQ\n");
    for (int i = 0; i < MLFQcount; i++) {
        // 간트 차트 출력
        Node* Current = GetNode(result_MLFQ, i);
        if (Current->turnaround_time > 0) 
            printf("\b\b\b\nQ%d:", Current->process.pid);
        else 
            printf(" P%d (%d-%d),", Current->process.pid, Current->process.rt.start, Current->process.rt.end);
    }
    printf("\n");

    printf("====================== \n");

    // 반환 시간 및 대기시간 출력
    for (int i = 1; i <= 3; i++) {
        Node* Current = result_MLFQ;
        Node* node = NULL;
        int processed = 0;

        while (Current != NULL) {
            if (Current->process.pid == i && Current->turnaround_time <= 0) {
                node = Current;
                processed += Current->process.ran_time;
            }
            Current = Current->next;
        }
        MLFQ_returntime[i-1] = node->process.rt.end;
        MLFQ_waitingtime[i-1] = node->process.rt.end - processed;
        MLFQ_avg_returntime += MLFQ_returntime[i-1];
        MLFQ_avg_waittime += MLFQ_waitingtime[i-1];
    }

    MLFQ_avg_returntime = MLFQ_avg_returntime / 3;
    MLFQ_avg_waittime = MLFQ_avg_waittime / 3;
    
    // RR
    printf("\nRoundRobin\n");
    printf("================================================= \n");
    printf("프로세스   |      반환시간     |     대기시간\n");
    printf("-------------------------------------------------\n");

    for (int i = 0; i < 3; i++) {
        printf("%d          |         %2d        |        %2d\n", i+1, RR_returntime[i], RR_waitingtime[i]);
    }

    printf("\n\n");
    
    printf("<총 반환 시간 | 총 대기 시간>\n");
    printf("전체 평균 반환시간: %.2lf\n", RR_avg_returntime);
    printf("전체 평균 대기시간: %.2lf\n", RR_avg_waitingtime);
    printf("\n\n");

    // MLFQ
    printf("\nMLFQ\n");
    printf("================================================= \n");
    printf("프로세스   |      반환시간     |     대기시간\n");
    printf("-------------------------------------------------\n");

    for (int i = 0; i < 3; i++) {
        printf("%d          |         %2d        |        %2d\n", i+1, MLFQ_returntime[i], MLFQ_waitingtime[i]);
    }

    printf("\n\n");
    
    printf("<총 반환 시간 | 총 대기 시간>\n");
    printf("전체 평균 반환시간: %.2lf\n", MLFQ_avg_returntime);
    printf("전체 평균 대기시간: %.2lf\n", MLFQ_avg_waittime);
    printf("\n\n");

    pid_t pid;

    int status;
    Node* Current = result_MLFQ;
    
    while(Current != NULL) {
        pid = fork();
        if (pid == 0) {
            int ran;
            Node* cur = result_MLFQ;
            while (cur != Current) {
                if (cur->process.pid == Current->process.pid && cur->turnaround_time <= 0) {
                    ran += cur->process.ran_time;
                }
                cur = cur->next;
            }
            fun(Current, ran);
            exit(2);
        } 
        else {
            while(wait(&status) != pid) continue;
        }
        Current = Current->next;
    }
    return 0;
}

Node* MLFQ(Node* Head) {
    Node* NewQ = NULL;
    Node* Q1 = (Node*)malloc(sizeof(Node));
    Node* Q2 = (Node*)malloc(sizeof(Node));
    Node* Q3 = (Node*)malloc(sizeof(Node));

    int turnaround_times[3] = {1, 2, 4};
    Q1->turnaround_time = 1;
    Q2->turnaround_time = 2;
    Q3->turnaround_time = 4;

    Q1->process.pid = 1;
    Q2->process.pid = 2;
    Q3->process.pid = 3;

    insert_head(&NewQ, Q1);
    enqueue(Q1, Q2);
    enqueue(Q2, Q3);

    Node* Current = Head->next;
    Node* Before = NULL;

    int t = 0;
    int queue_no = 0;
    while(Current != NULL) {
        Node* C = Current;

        if (GetNodeCount(Head) <= 2) {
            queue_no = 1;
        } 
        else {
            int n = 1;
            while (n < 3) {
                Node* start = find_Queue(NewQ, n);
                Node* end = find_lastnode(start);
                Node* NextQ = find_Queue(NewQ, n+1);

                int same = 0;
                Node* cur = start->next;
                while(cur != NextQ && (cur->next != end->next || cur != NULL)) {
                    if (Current->process.pid == cur->process.pid) {
                        same = 1;
                        break;
                    }
                    cur = cur->next;
                }
                
                if (same == 1 && (NextQ == NULL && NextQ->turnaround_time >= (Current->process.running_time - Current->process.ran_time))) {
                    queue_no = n+1;
                } 
                else if(same == 0) {
                    queue_no = n;
                    break;
                }

                n++;

                if (n == 3) {
                    queue_no = 3;
                    int m = 3;
                    while (m >= 1) {
                        if (find_Queue(NewQ, m)->turnaround_time >= Current->process.running_time - Current->process.ran_time) {
                            queue_no = m;
                        }
                        m--;
                    }
                }
            }
        }

        Node* InsertQueue = NULL;
        if (Before != NULL && ((queue_no != find_parent(NewQ, Before)->process.pid && Before->next == NULL))) {
            Node* newQ = (Node*)malloc(sizeof(Node));
            newQ->turnaround_time = turnaround_times[queue_no-1];
            newQ->process.pid = queue_no;
            newQ->next = NULL;
            enqueue(Before, newQ);
            InsertQueue = newQ;
        } 
        else {
            InsertQueue = find_Queue(NewQ, queue_no);
        }
        
        Node* NewNode = (Node*)malloc(sizeof(Node));
        NewNode->next = NULL;
        NewNode->process = Current->process;
        NewNode->process.rt.start = Before != NULL ? Before->process.rt.end : 0;

        if (GetNodeCount(Head) == 2) {
            NewNode->process.rt.end = NewNode->process.rt.start + (NewNode->process.running_time - NewNode->process.ran_time);
            NewNode->process.ran_time = Current->process.running_time - Current->process.ran_time;
        } 
        else {
            NewNode->process.ran_time = Current->process.running_time - Current->process.ran_time <= InsertQueue->turnaround_time ? Current->process.running_time - Current->process.ran_time : InsertQueue->turnaround_time;
            NewNode->process.rt.end = NewNode->process.rt.start + NewNode->process.ran_time;
        }
        
        Current->process.ran_time += NewNode->process.ran_time;

        if (find_parent(NewQ, Before)->process.pid == InsertQueue->process.pid) 
            enqueue(Before, NewNode);
        else 
            enqueue(InsertQueue, NewNode);
        Before = NewNode; // 이전 노드를 새 노드를 가리키도록 업데이트

        if (Current->next == NULL) 
            Current = Head->next;
        else 
            Current = Current->next;

        // 실행할 시간이 남아있지 않으면 삭제
        if (C->process.running_time - C->process.ran_time <= 0) {
            dequeue((&Head), C);
        }

        if(GetNodeCount(Head) == 1) 
            break;
    }
    
    return NewQ;
}

Node* RoundRobin(Node* Head) {
    Node* NewQ = NULL;
    Node* head = (Node*)malloc(sizeof(Node));
    head->next = NULL;
    insert_head(&NewQ, head);
    Node* Before = head;

    int t = 0;
    int i = 0;
    int ran = 1;
    Node* Current = Head;
    while(Head->next != NULL) {
        if (t == 0 ||(ran % 5 == 0) || ran == Current->process.running_time) {
            Current->process.ran_time = ran;
            Before->process.ran_time = ran;
            if (Current->process.ran_time >= Current->process.running_time && Current->process.pid != 0) {
                Node* C = Current;
                dequeue((&Head), C);
            }
            if (GetNodeCount(Head) > 0) {
                if (Current->next == NULL) {
                    if(GetNodeCount(Head) > 1)
                        Current = Head->next;
                } 
                else {
                    Current = Current->next;
                }
            }
            Node* NewNode = (Node*)malloc(sizeof(Node));
            NewNode->next = NULL;
            NewNode->process = Current->process;
            ran = NewNode->process.ran_time;

            NewNode->process.rt.start = t;
            Before->process.rt.end = t;

            enqueue(Before, NewNode);
            i++;
            Before = Before->next;
        }
        t++;
        ran++;
    }
    Node* lastNode = GetNode(NewQ, i);
    dequeue(&NewQ, lastNode);
    
    return NewQ;
}

void fun(Node* Current, int ran) {
    if (Current->turnaround_time <= 0) {
        for (int i = ran+1; i < ran + 1 + Current->process.ran_time; i++) {
            printf("P%d: %d X %d = %d\n", Current->process.pid, i, Current->process.pid, i * Current->process.pid);
        }
    }
}

void insert_head(Node** Head, Node* NewHead) {
    if (Head == NULL) {
        (*Head) = NewHead;
    } 
    else {
        NewHead->next = (*Head);
        (*Head) = NewHead;
    }
}

void enqueue(Node* Current, Node* NewNode) {
    NewNode->next = Current->next;
    Current->next = NewNode;
}

Node* GetNode(Node* Head, int Location) {
    Node* Current = Head;
    while (Current != NULL && (--Location) >= 0) {
        Current = Current->next;
    }

    return Current;
}

int GetNodeCount(Node* Head) {
    int Count = 0;
    Node* Current = Head;
    while (Current != NULL) {
        Current = Current->next;
        Count++;
    }

    return Count;
}

void dequeue(Node** Head, Node* Remove) {
    if (*Head == Remove) {
        *Head = Remove->next;
    } 
    else {
        Node* Current = *Head;
        while (Current != NULL && Current->next != Remove) {
            Current = Current->next;
        }

        if(Current != NULL) {
            Current->next = Remove->next;
        }
    }
    free(Remove);
}

Node* find_Queue(Node* Head, int Location) {
    Node* Current = Head;
    int count = 0;
    while(Current != NULL) {
        
        if(Current->turnaround_time > 0) count++;
        if(count == Location) break;

        if (Current->next == NULL) return NULL;
        Current = Current->next;
    }

    return Current;
}

Node* find_parent(Node* Head, Node* Current) {
    Node* cur = Head;

    Node* Queue = NULL;
    while(cur != NULL){
        if (cur->turnaround_time > 0) Queue = cur;
        if (cur == Current) break;

        cur = cur->next;
    }

    return Queue;
}

Node* find_lastnode(Node* Head) {
    Node* Current = Head;
    while(Current->next->turnaround_time <= 0 && Current->next != NULL) {
        Current = Current->next;
    }

    return Current;
}