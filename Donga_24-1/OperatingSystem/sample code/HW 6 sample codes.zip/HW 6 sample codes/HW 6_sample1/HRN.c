#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define PN 5

// 구조체 정의
typedef struct Process {
    int pid;             // 프로세스 ID
    int arrival_time;    // 도착 시간
    int running_time;    // 실행 시간
    float priority;      // 우선순위
} Process;

// 연결 리스트 노드 구조체
typedef struct ListNode {
    Process data;            // 데이터는 프로세스 구조체
    struct ListNode* link;   // 다음 노드를 가리키는 포인터
} ListNode;

void error(char* message);
ListNode* insert_first(ListNode* head, Process value);
ListNode* insert(ListNode* head, ListNode* pre, Process value);
ListNode* insertSort(ListNode* head, Process value);
ListNode* delete_first(ListNode* head);
ListNode* delete_target(ListNode* head, ListNode* target);
ListNode* HRN(ListNode* head);
void* func(void* arg);

int main() {
    ListNode* head = NULL;

    for(int i = 0; i < PN; i++) {
        Process process;
        printf("P%d의 도착시간 및 실행시간 입력 (띄어쓰기로 구분): ", i + 1);
        scanf("%d %d", &process.arrival_time, &process.running_time);
        process.pid = i + 1;
        process.priority = 0;

        head = insertSort(head, process);
    }

    ListNode* Newhead = HRN(head);

    ListNode* current = Newhead;
    ListNode* pre = Newhead;
    int pre_time = 0;

    // 간트 차트 출력
    printf("\n===== 간트차트 출력 =====\n");
    while (current != NULL) {
        printf("P%d (%d-%d) \n", current->data.pid, pre_time, pre_time+current->data.running_time);
        pre = current;
        pre_time += pre->data.running_time;
        current = current->link;
    }
    printf("====================== \n");

    current = Newhead;
    pre = Newhead;
    int pre_time_end = 0;
    int pre_time_start = 0;
    double sum_return, sum_wait = 0.0;
    printf("================================================= \n");
    printf("프로세스   |      반환시간     |     대기시간\n");
    printf("-------------------------------------------------\n");
    while (current != NULL) {
        printf("P%d         |     (%2d-%d)=%2d     |    (%2d-%d)=%2d\n",
        current->data.pid,
        current->data.running_time+pre_time_end, current->data.arrival_time, current->data.running_time+pre_time_end-current->data.arrival_time,
        pre_time_end, current->data.arrival_time, pre_time_end-current->data.arrival_time);

        sum_return += current->data.running_time+pre_time_end-current->data.arrival_time;
        sum_wait += pre_time_end-current->data.arrival_time;
        pre = current;
        pre_time_start = pre_time_end;
        pre_time_end += pre->data.running_time;  
        current = current->link;
    }
    printf("================================================= \n");
    printf("전체 평균 반환시간: %.1f \n", sum_return / (double)PN);
    printf("전체 평균 대기시간: %.1f \n", sum_wait / (double)PN);
    printf("================================================= \n");

    // 프로세스 생성
    pid_t pid1, pid2, pid3;
    int process_num=1;
    int status;

    pid1 = fork();
    pid2 = fork();
    
    if(pid1 == 0) {
        process_num = process_num * 3;
        if (pid2 == 0) {
            process_num = process_num + 1;
            pid3 = fork();
            if(pid3 == 0){
                process_num += 1; 
            }
        }
    } 
    else { 
        if(pid2 == 0) process_num = process_num + 1;
    }

    ListNode * new_temp = Newhead;
    if(process_num == 1){
        func(new_temp);
    }
    else if(process_num == 2){
        new_temp = new_temp -> link;
        func(new_temp);
    }
    else if(process_num == 3){
        new_temp = new_temp -> link;
        new_temp = new_temp -> link;
        func(new_temp);
    }
    else if(process_num == 4){
        new_temp = new_temp -> link;
        new_temp = new_temp -> link;
        new_temp = new_temp -> link;
        func(new_temp);
    }
    else if(process_num == 5){
        new_temp = new_temp -> link;
        new_temp = new_temp -> link;
        new_temp = new_temp -> link;
        new_temp = new_temp -> link;
        //new_temp = new_temp -> link;
        func(new_temp);
    }

    if(pid3 == 0) {
        exit(2);
        }
        else if(pid2 == 0) {
            while(wait(&status) != pid3) continue;
            exit(2);
        } else if(pid1 == 0) {
            while(wait(&status) != pid2) continue;
            exit(2);
        } else {
            while(wait(&status) != pid1) continue;
        }

    return 0;
}

//------------------------------------------------------------------------------
// 연결리스트 구현 함수
void error(char* message) {
    fprintf(stderr, "%s\n", message);
    exit(1);
}

ListNode* insertSort(ListNode* head, Process value) {
    ListNode* p = (ListNode*)malloc(sizeof(ListNode));
    p->data = value;
    p->link = NULL;

    if (head == NULL) {
        return p;
    }

    ListNode* current = head;
    ListNode* previous = NULL;

    while (current != NULL && current->data.arrival_time <= value.arrival_time) {
        previous = current;
        current = current->link;
    }

    if (previous == NULL) {
        p->link = head;
        head = p;
    } else {
        p->link = current;
        previous->link = p;
    }

    return head;
}

ListNode* insert_first(ListNode* head, Process value) {
    ListNode* p = (ListNode*)malloc(sizeof(ListNode));
    p->data = value;
    p->link = head;
    head = p;
    return head;
}

ListNode* insert(ListNode* head, ListNode* pre, Process value) {
    ListNode* p = (ListNode*)malloc(sizeof(ListNode));
    p->data = value;
    p->link = pre->link;
    pre->link = p;
    return head;
}

ListNode* delete_first(ListNode* head) {
    if (head == NULL) return NULL;
    ListNode* removed = head;
    head = head->link;
    free(removed);
    return head;
}

ListNode* delete_target(ListNode* head, ListNode* target) {
    if (head == NULL || target == NULL) return head;

    if (head == target) {
        ListNode* temp = head;
        head = head->link;
        free(temp);
        return head;
    }

    ListNode* current = head;
    while (current != NULL && current->link != target) {
        current = current->link;
    }

    if (current != NULL) {
        ListNode* temp = current->link;
        current->link = target->link;
        free(temp);
    }

    return head;
}

ListNode* HRN(ListNode* head) {
    ListNode* current = head;
    ListNode* Newhead = NULL;
    int pre_running = 0;

    // 첫번째 노드 새 큐에 추가
    Process process;
    process.arrival_time = current->data.arrival_time;
    process.pid = current->data.pid;
    process.running_time = current->data.running_time;
    Newhead = insert_first(Newhead, process);

    if (head != NULL) {
        pre_running = head->data.running_time;
        head = delete_first(head);
    }

    while (head != NULL) {
        current = head;
        float maxP = -1.0f;
        ListNode* selected = NULL;
        ListNode* selected_prev = NULL;

        // 우선순위 계산 및 최대 우선순위 노드 선택
        while (current != NULL) {
            current->data.priority = 1 + (float)(pre_running - current->data.arrival_time) / current->data.running_time;
            if (current->data.priority > maxP) {
                maxP = current->data.priority;
                selected = current;
            }
            current = current->link;
        }

        if (selected != NULL) {
            // 선택된 노드를 Newhead로 이동
            Process process = selected->data;
            if (Newhead == NULL) {
                Newhead = insert_first(Newhead, process);
            } else {
                ListNode* new_current = Newhead;
                while (new_current->link != NULL) {
                    new_current = new_current->link;
                }
                Newhead = insert(Newhead, new_current, process);
            }
            pre_running += selected->data.running_time;
            head = delete_target(head, selected);
        }
    }

    return Newhead;
}

void* func(void* arg) {
    ListNode* node = (ListNode*)arg;
    Process* process = &(node->data); // 처리해야 할 구조체의 주소 포인터

    for(int i=1; i<=process->running_time; i++) {
        printf("P%d: %d x %d = %d \n", process->pid, i, process->pid, process->pid * i);
    }

    return 0;
}
