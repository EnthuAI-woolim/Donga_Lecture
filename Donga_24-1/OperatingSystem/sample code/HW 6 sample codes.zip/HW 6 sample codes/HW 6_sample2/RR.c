#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <semaphore.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <asm-generic/fcntl.h> // O_CREAT


typedef struct {
    int processNum;
    int run_time;
    int start_time;
} ProcessNode;

typedef struct Queue{
    ProcessNode processWork;
    struct Queue* next;
} Queue;

typedef struct {
    int processNum;
    int return_time;
    int wait_time;
} ProcessWorkINFO;

typedef struct {
    ProcessWorkINFO repo[3];
    int work_time;
    int prev_time;
    int control_turn;
    char gant[100][30];
    int prev_gant;
    int gant_count;
} WorkINFOLIST;

ProcessNode* createProcessNode(int processNum, int runt_time){
    ProcessNode *newnode = (ProcessNode *)malloc(sizeof(ProcessNode));
    newnode->processNum = processNum;
    newnode->run_time = runt_time;
    newnode->start_time = 1;
    return newnode;
}
Queue* init_Queue(){ return NULL; }


void shared_processChange(ProcessNode* sharedNode, ProcessNode* node){
    sharedNode->processNum = node->processNum;
    sharedNode->run_time = node->run_time;
    sharedNode->start_time = node->start_time;
}


void enQueue(Queue **head, ProcessNode* node){
    Queue* newNode = (Queue*)malloc(sizeof(Queue));
    newNode->processWork = *node;
    newNode->next = NULL;
    if(*head == NULL){ *head = newNode; }
    else{
        Queue* temp = *head;
        while(temp->next != NULL){ temp = temp->next; }
        temp->next = newNode;
    }
}
ProcessNode* deQueue(Queue **head){
    if(*head == NULL){ return NULL; }
    Queue* temp = *head;
    *head = (*head)->next;
    ProcessNode* frontnode = &(temp->processWork);
    free(temp);
    return frontnode;
}
ProcessNode* front_Queue(Queue **head){
    if(*head == NULL){ return NULL; }
    ProcessNode* frontnode = &((*head)->processWork);
    return frontnode;
}

int size_Queue(Queue **head){
    int count = 0;
    Queue* current = *head;
    while(current != NULL){ count++; current = current->next; }
    return count;
}

// 간트차트용 시작시간 추출 함수
int startTime(char* gant_chart_entry) {
    char* open_bracket = strchr(gant_chart_entry, '(');
    if(open_bracket != NULL){ return atoi(open_bracket + 1); }
    return -1;
}

int main(){
    int rpt = 0;

    sem_t *sem; // 세마포어 선언
    int shmid_PINFO, shmid_GINFO; // 공유 메모리 세팅 저장 변수(PINFO=프로세스정보 / GINFO=간트차트용 정보저장)
    ProcessNode *shared_ProcessINFO;
    shared_ProcessINFO = createProcessNode(0,0);
    WorkINFOLIST *timer;
    key_t key_PINFO = IPC_PRIVATE, key_GINFO = IPC_PRIVATE;


    // Queue 3개 생성
    Queue* Que = init_Queue();

    // 프로세스 3개 생성 및 처음 큐인 Q1에 삽입
    ProcessNode *node1 = createProcessNode(1, 30);
    enQueue(&Que, node1); 

    ProcessNode *node2 = createProcessNode(2, 20);
    enQueue(&Que, node2);

    ProcessNode *node3 = createProcessNode(3, 10);
    enQueue(&Que, node3);

    // 작업할 프로세스 선언용 공용 메모리
    if((shmid_PINFO = shmget(key_PINFO, sizeof(ProcessNode), IPC_CREAT | 0666)) < 0){ perror("shmget"); exit(1); }
    if((shared_ProcessINFO = shmat(shmid_PINFO, NULL, 0)) == (ProcessNode *) -1){ perror("shmat"); exit(1); }
    shared_ProcessINFO->processNum = 0, shared_ProcessINFO->run_time = 0, shared_ProcessINFO->start_time = -1;

    // 작업 기록 구조체를 공용 메모리로 선언
    if((shmid_GINFO = shmget(key_GINFO, sizeof(WorkINFOLIST), IPC_CREAT | 0666)) < 0){ perror("shmget"); exit(1); }
    if((timer = shmat(shmid_GINFO, NULL, 0)) == (WorkINFOLIST *) -1){ perror("shmat"); exit(1); }
    timer->prev_time = 0; timer->work_time = 0; timer->control_turn = 0; timer->gant_count = 0; timer->prev_gant = 0;

    sem = sem_open("/semaphore", O_CREAT, 0644, 1);
    if(sem == SEM_FAILED){ perror("sem_open"); exit(1); }
    sem_init(sem, 1, 1);

    // 프로세스 4개 생성(0 = 통제용 프로세스/ 1~3 = P1,P2,P3 프로세스)
    long ppid = (long)getpid();
    int processTag, prev_processNum = -1, concession = 0;
    for(int i = 0; i < 3; i++){
        if(fork() == 0){ processTag = i+1; break; }
        processTag = 0;
    }

    // 작업 프로세스
    if(processTag != 0 && ppid != (long)getpid()){
        while(1){
            sem_wait(sem);
            if(shared_ProcessINFO->processNum == processTag && timer->control_turn == 1){
                // 간트 차트 및 반환 시간 , 대기시간 용 정리 작업
                timer->prev_time = timer->work_time - (shared_ProcessINFO->start_time - 1);
                if(shared_ProcessINFO->start_time != 1){ rpt = timer->prev_time + (shared_ProcessINFO->start_time - 1); }
                else { rpt = timer->prev_time; }
                for(shared_ProcessINFO->start_time; shared_ProcessINFO->start_time <= shared_ProcessINFO->run_time; shared_ProcessINFO->start_time++){
                    printf("P%d: %2d X %2d = %2d\n", shared_ProcessINFO->processNum, shared_ProcessINFO->start_time, shared_ProcessINFO->processNum, (shared_ProcessINFO->start_time*shared_ProcessINFO->processNum));
                    timer->work_time++;
                    if(timer->work_time == (rpt+1)){ break; }  
                }
                // 종료전까지의 작업의 간트차트와 반환시간 대기시간을 기록
                char info[20];
                if(timer->prev_gant == shared_ProcessINFO->processNum){
                    int start = startTime(timer->gant[timer->gant_count-1]);
                    sprintf(info, "P%d(%d-%d)", shared_ProcessINFO->processNum, start, timer->work_time);
                    strcpy(timer->gant[timer->gant_count-1],info);
                } // 간트 차트의 전 프로세스가 지금 프로세스 정보와 같은 경우 두 개를 병합
                else{
                    sprintf(info, "P%d(%d-%d)", shared_ProcessINFO->processNum, rpt, timer->work_time);
                    strcpy(timer->gant[timer->gant_count],info);
                    timer->gant_count++;
                } // 간트 차트의 전 프로세스가 지금 프로세스 정보와 다른 경우
                timer->prev_gant = shared_ProcessINFO->processNum; // 전 프로세스 정보 갱신
                timer->repo[shared_ProcessINFO->processNum-1].processNum = shared_ProcessINFO->processNum;
                timer->repo[shared_ProcessINFO->processNum-1].return_time = timer->work_time;
                timer->repo[shared_ProcessINFO->processNum-1].wait_time = (timer->work_time - shared_ProcessINFO->run_time);
                timer->control_turn = 0;
                
                // 프로세스 종료 조건
                if(shared_ProcessINFO->start_time >= shared_ProcessINFO->run_time){ shared_ProcessINFO->processNum = 0; break; }
            }
            sem_post(sem);
        }
        sem_post(sem);
    }
    // 통제 프로세스
    else{
        while(1){
            sem_wait(sem);
            if(timer->control_turn == 0){
                int QueSzie;
                //printf("PN: %d\n",shared_ProcessINFO->processNum);
                if(shared_ProcessINFO->processNum != 0){ shared_ProcessINFO->start_time++; enQueue(&Que,shared_ProcessINFO); }
                QueSzie = size_Queue(&Que);
                if(QueSzie != 0){
                    ProcessNode *worktimenode = front_Queue(&Que);
                    shared_processChange(shared_ProcessINFO,worktimenode);
                    prev_processNum = shared_ProcessINFO->processNum;
                    deQueue(&Que);
                }
                timer->control_turn = 1;
                if(QueSzie == 0){ break; } // 통제 반복문 탈출 조건
            }
            sem_post(sem);
        }
        sem_post(sem);
    }

    if(ppid == (long)getpid()){ // 부모인 경우 다른 프로세스의 종료를 대기 후 결과를 출력
        for(int i = 0; i < 5; i++){ wait(NULL); }
        int num = 0, queNum = 0, prev_queNum = 0, quecount = 0;
        char gantP[10];
        while(strcmp(timer->gant[num], "") != 0){ num++; }
        printf("----------------------------------------\n");
        for(int i = 0; i < num; i++){ printf("%s\n",timer->gant[i]); }
        printf("----------------------------------------\n");
        int sumReturnTime = 0, sumWaitTime = 0;
        for(int i = 0; i < 3; i++){
            printf("P%d: 반환시간(%2d) , 대기시간(%2d)\n", timer->repo[i].processNum, timer->repo[i].return_time, timer->repo[i].wait_time);
            sumReturnTime += timer->repo[i].return_time; sumWaitTime += timer->repo[i].wait_time;
        }
        printf("----------------------------------------\n");
        printf("평균반환시간: %.1f / 평균대기시간: %.1f\n", (float)sumReturnTime/3, (float)sumWaitTime/3);

        sem_close(sem); // semaphore 닫기
        sem_unlink("/semaphore"); // semaphore 연결 해제
        // 공유메모리 정리
        shmdt(shared_ProcessINFO); shmctl(shmid_PINFO, IPC_RMID, NULL);
        shmdt(timer); shmctl(shmid_GINFO, IPC_RMID, NULL);
    } // 부모 프로세스 대기
    else{ shmdt(shared_ProcessINFO); shmdt(timer); }

    free(node1); free(node2); free(node3);
}