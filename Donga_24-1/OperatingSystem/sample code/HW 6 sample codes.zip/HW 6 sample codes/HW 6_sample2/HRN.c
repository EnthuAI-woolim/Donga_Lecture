#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <semaphore.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <asm-generic/fcntl.h> // O_CREAT


typedef struct {
    int processNum;
    char name[3];
    int run_time;
    int start_time;
    double priorityNum;
} ProcessNode; // 프로세스 작업 정보 저장 구조체

typedef struct Queue {
    ProcessNode processWork;
    struct Queue* next;
} Queue; // Linked List 구현 Queue

typedef struct {
    char name[3];
    int return_time;
    int wait_time;
} ProcessINFO; // 프로세스 시간 정보 저장 구조체

typedef struct {
    ProcessINFO time[5];
    int work_time;
    int prev_time;
    int control_turn;
    char gant[30][30];
    char prev_gant[3];
    int gant_count;
} INFOLIST; // 프로세스 정보 구조체

ProcessNode* creatProcessNode(int processNum, char name[], int run_time){
    ProcessNode *newNode = (ProcessNode *)malloc(sizeof(ProcessNode));
    newNode->processNum = processNum;
    strcpy(newNode->name,name);
    newNode->run_time = run_time;
    newNode->start_time = 1;
    newNode->priorityNum = 0;
    return newNode;
} // 프로세스 작업 정보 생성
ProcessINFO* creatProcessINFO(char name[]){
    ProcessINFO *newINFO = (ProcessINFO *)malloc(sizeof(ProcessINFO));
    strcpy(newINFO->name,name);
    newINFO->return_time = 0; newINFO->wait_time = 0;
    return newINFO;
}

// Queue 초기화 함수
Queue* init_Queue(){ return NULL; }

void change_processINFO(ProcessNode* processinfo, ProcessNode* node){
    processinfo->processNum = node->processNum;
    strcpy(processinfo->name,node->name);
    processinfo->run_time = node->run_time;
    processinfo->start_time = node->start_time;
    processinfo->priorityNum = (double)node->priorityNum;
}

// Queue 삽입 함수
void enQueue(Queue **head, ProcessNode* node){
    Queue* newNode = (Queue*)malloc(sizeof(Queue));
    newNode->processWork = *node;
    newNode->next = NULL;

    if(*head == NULL){ *head = newNode; }
    else{
        Queue* temp = *head;
        while(temp->next != NULL){ temp = temp->next; }
        temp->next = newNode;
    }
}
// Queue 삭제 함수
ProcessNode* deQueue(Queue **head){
    if(*head == NULL){ return NULL; }
    Queue* tmep = *head;
    *head = (*head)->next;
    ProcessNode* frontnode = &(tmep->processWork);
    free(tmep);
    return frontnode;
}
// Queue 처음 프로세스 정보 출력 함수
ProcessNode* front_Queue(Queue **head){
    if(*head == NULL){ return NULL; }
    ProcessNode* frontnode = &((*head)->processWork);
    return frontnode;
}

void changePriority(Queue** head, INFOLIST* recode){
    if(*head == NULL || (*head)->next == NULL){ return; }
    Queue* temp = *head;
    while(temp != NULL){
        temp->processWork.priorityNum = (double)(temp->processWork.run_time + (recode->work_time - temp->processWork.processNum)) / temp->processWork.run_time;
        temp = temp->next;
    }
}

// 선점에 맞추어서 정렬하는 함수
void prioritySortQueue(Queue** head){
    if(*head == NULL || (*head)->next == NULL){ return; }// 큐가 비어 있거나 노드가 하나인 경우 정렬할 필요 없음
    int swapped;
    Queue* ptr1;
    Queue* lptr = NULL;
    do{
        swapped = 0;
        ptr1 = *head;

        while(ptr1->next != lptr){
            if(ptr1->processWork.priorityNum < ptr1->next->processWork.priorityNum || 
                (ptr1->processWork.priorityNum == ptr1->next->processWork.priorityNum && 
                 ptr1->processWork.processNum > ptr1->next->processWork.processNum)){
                ProcessNode temp = ptr1->processWork;
                ptr1->processWork = ptr1->next->processWork;
                ptr1->next->processWork = temp;
                swapped = 1;
            }
            ptr1 = ptr1->next;
        }
        lptr = ptr1;
    } while(swapped);
}

// 간트차트용 시작시간 추출 함수
int startTime(char* gant_chart_entry) {
    char* open_bracket = strchr(gant_chart_entry, '(');
    if(open_bracket != NULL){ return atoi(open_bracket + 1); }
    return -1;
}

void printQueue(Queue *head) {
    Queue *temp = head;
    while (temp != NULL) {
        printf("Process Num: %d, Name: %s, Run Time: %d, Priority: %f, Start Time: %d\n",
                temp->processWork.processNum, temp->processWork.name,
                temp->processWork.run_time, temp->processWork.priorityNum,
                temp->processWork.start_time);
        temp = temp->next;
    }
}

int main(){
    int rpt = 0;
    int totalTime = 0;
    char process_name[3];
    Queue* Que = init_Queue(); 
    sem_t *sem;
    // 공유 데이터
    int shmidQ_INFO, shmidT_INFO;
    ProcessNode *processINFO;
    INFOLIST *timer;
    key_t keyQ = 1234, keyT = 5678;

    // 공유용 프로세스 정보 저장공간 초기화
    processINFO = creatProcessNode(0," ",0);

    ProcessNode *ProcessWorkList[5]; // 프로세스 준비
    ProcessWorkList[0] = creatProcessNode(0,"P1",10);
    ProcessWorkList[1] = creatProcessNode(1,"P2",28);
    ProcessWorkList[2] = creatProcessNode(2,"P3",6);
    ProcessWorkList[3] = creatProcessNode(3,"P4",4);
    ProcessWorkList[4] = creatProcessNode(4,"P5",14);
    for(int i = 0; i < 5; i++){ totalTime += ProcessWorkList[i]->run_time; }

    ProcessINFO *ProcessTimeList[5]; // 각 프로세스 기록용 구조체 준비
    ProcessTimeList[0] = creatProcessINFO("P1");
    ProcessTimeList[1] = creatProcessINFO("P2");
    ProcessTimeList[2] = creatProcessINFO("P3");
    ProcessTimeList[3] = creatProcessINFO("P4");
    ProcessTimeList[4] = creatProcessINFO("P5");

    if((shmidQ_INFO = shmget(keyQ, sizeof(ProcessNode), IPC_CREAT | 0666)) < 0){ perror("shmget"); exit(1); } // 공용 메모리 세팅(Queue정보용)
    if((processINFO = shmat(shmidQ_INFO, NULL, 0)) == (ProcessNode *) -1){ perror("shmat"); exit(1); } // Queue정보용 공용 메모리 할당

    if((shmidT_INFO = shmget(keyT, sizeof(INFOLIST), IPC_CREAT | 0666)) < 0){ perror("shmget"); exit(1); } // 공용 메모리 세팅(TimeList용)
    if((timer = shmat(shmidT_INFO, NULL, 0)) == (INFOLIST *) -1){ perror("shmat"); exit(1); } // 프로세스 기록용 리스트를 공용 메모리 할당
    for(int i = 0; i < 5; i++){ timer->time[i] = *ProcessTimeList[i]; }
    timer->prev_time = 0; timer->work_time = 0; timer->control_turn = 0; timer->gant_count = 0; strcpy(timer->prev_gant," ");

    sem = sem_open("/semaphore", O_CREAT, 0644, 1);
    if(sem == SEM_FAILED){ perror("sem_open"); exit(1); }
    sem_init(sem,1,1);

    long ppid = (long)getpid();
    for(int i = 0; i < 5; i++){
        if(fork() == 0){
            char temp_num[2];
            char temp[3] = "P";
            sprintf(temp_num,"%d",(i+1));
            strcpy(process_name,strcat(temp,temp_num));
            break;
        }
        strcpy(process_name,"C0");
    } // 총 6개의 프로세스 생성 (C0: Queue제어 프로세스 , P1~P5: 각 프로세스를 담당하여 작업 진행)
    
    if(strcmp(process_name,"C0") != 0 && ppid != (long)getpid()){
        while(1){
            sem_wait(sem);
            if(timer->work_time >= totalTime){ break; }
            if(strcmp(processINFO->name,process_name) == 0 && timer->control_turn == 1){
                // 간트 차트 및 반환 시간 , 대기시간 용 정리 작업
                timer->prev_time = timer->work_time - (processINFO->start_time - 1);
                if(processINFO->start_time != 1){ rpt = timer->prev_time + (processINFO->start_time - 1); }
                else { rpt = timer->prev_time; }
                for(processINFO->start_time; processINFO->start_time <= processINFO->run_time; processINFO->start_time++){
                    printf("%s: %d X %d = %d\n", processINFO->name, processINFO->start_time, (processINFO->processNum+1), (processINFO->start_time*(processINFO->processNum+1)));
                    timer->work_time++;
                    if(timer->work_time < 5){ break; }
                }
                // 종료전까지의 작업의 간트차트와 반환시간 대기시간을 기록
                char info[20];
                if(strcmp(timer->prev_gant,processINFO->name) == 0){
                    int start = startTime(timer->gant[timer->gant_count-1]);
                    sprintf(info, "%s: (%d-%d)", processINFO->name, start, timer->work_time);
                    strcpy(timer->gant[timer->gant_count-1],info);
                } // 간트 차트의 전 프로세스가 지금 프로세스 정보와 같은 경우 두 개를 병합
                else{
                    sprintf(info, "%s: (%d-%d)", processINFO->name, rpt, timer->work_time);
                    strcpy(timer->gant[timer->gant_count],info);
                    timer->gant_count++;
                } // 간트 차트의 전 프로세스가 지금 프로세스 정보와 다른 경우
                strcpy(timer->prev_gant,processINFO->name); // 전 프로세스 정보 갱신
                timer->time[processINFO->processNum].return_time = timer->work_time - processINFO->processNum;
                timer->time[processINFO->processNum].wait_time = timer->prev_time - processINFO->processNum;
                timer->control_turn = 0;
            }
            sem_post(sem);
        }
        sem_post(sem);
    }
    else{
        while(1){
            sem_wait(sem);
            if(timer->work_time >= totalTime){ break; }

            if(timer->control_turn == 0){ // 통제권이 왔을 경우 작업 진행
                if(timer->work_time < 5){ // 새로운 프로세스 진입하는 구간
                    if(timer->work_time == 0){ // 처음 프로세스 진입
                        ProcessNode *newProcess = ProcessWorkList[timer->work_time];
                        change_processINFO(processINFO,newProcess);
                        enQueue(&Que, newProcess);
                    }
                    /* 프로세스가 중간에 작업을 멈추고 온 경우로 작업 중 변경사항을 저장하고 추가된 작업을 넣음 */
                    else{ 
                        processINFO->start_time++;
                        front_Queue(&Que)->start_time = processINFO->start_time;
                        enQueue(&Que,ProcessWorkList[timer->work_time]);
                    }
                }
                if(processINFO->run_time <= processINFO->start_time){ 
                    deQueue(&Que);
                    changePriority(&Que,timer);
                    prioritySortQueue(&Que);
                    ProcessNode *newProcess = front_Queue(&Que);
                    change_processINFO(processINFO,newProcess);
                } // 프로세스가 작업을 완료한 경우 Queue에서 제거하고 다음 작업을 위해 정렬 후 공유 메모리에 올림
                timer->control_turn = 1;
            }
            sem_post(sem);
        }
        sem_post(sem);
    }

    if(ppid == (long)getpid()){ // 부모인 경우 다른 프로세스의 종료를 대기 후 결과를 출력
        for(int i = 0; i < 5; i++){ wait(NULL); }
        int num = 0;
        while(strcmp(timer->gant[num], "") != 0){ num++; }
        printf("----------------------------------------\n");
        for(int i = 0; i < num; i++){ printf("%s\n", timer->gant[i]); }
        printf("----------------------------------------\n");
        int sumReturnTime = 0, sumWaitTime = 0;
        for(int i = 0; i < 5; i++){
            printf("%s: 반환시간(%2d) , 대기시간(%2d)\n", timer->time[i].name, timer->time[i].return_time, timer->time[i].wait_time);
            sumReturnTime += timer->time[i].return_time; sumWaitTime += timer->time[i].wait_time;
        }
        printf("----------------------------------------\n");
        printf("평균반환시간: %.1f / 평균대기시간: %.1f\n", (float)sumReturnTime/5, (float)sumWaitTime/5);
    } // 부모 프로세스 대기


    for(int i = 0; i < 5; i++){ free(ProcessWorkList[i]); free(ProcessTimeList[i]); } // 동적할당 반환
    sem_close(sem); // semaphore 닫기
    sem_unlink("/semaphore"); // semaphore 연결 해제
    // 공유메모리 정리
    shmdt(processINFO);
    shmctl(shmidQ_INFO, IPC_RMID, NULL);
    shmdt(timer);
    shmctl(shmidT_INFO, IPC_RMID, NULL);
}
