#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char processName[5][3];
int arrivalTime[5];
int burstTime[5];
int remainingTime[5];
int waitingTime[5] = { 0 };
int returnTime[5] = { 0 };
int startingTime[5] = { 0 };
int endingTime[5] = { 0 };

typedef struct Node {
    int processIndex;       
    struct Node* next;      
} Node;

Node* queueFront = NULL;
Node* queueRear = NULL;

int isQueueEmpty() {
    return (queueFront == NULL);
}

void enqueueProcess(int processIndex) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->processIndex = processIndex;
    newNode->next = NULL;

    if (isQueueEmpty()) {
        queueFront = newNode;
        queueRear = newNode;
    }
    else {
        queueRear->next = newNode;
        queueRear = newNode;
    }
}

int dequeueProcess() {
    if (isQueueEmpty()) {
        return -1;
    }

    Node* temp = queueFront;
    int processIndex = temp->processIndex;
    queueFront = queueFront->next;

    if (queueFront == NULL) {
        queueRear = NULL;
    }

    free(temp);
    return processIndex;
}

void printGanttChart(int numProcesses, int ganttChartProcesses[], int ganttChartStartTimes[], int ganttChartEndTimes[], int numGanttChartEntries) {
    printf("Gantt Chart:\n");
    for (int i = 0; i < numGanttChartEntries; i++) {
        printf("%s (%d-%d)\n", processName[ganttChartProcesses[i]], ganttChartStartTimes[i], ganttChartEndTimes[i]);
    }
}

void printProcessTimes(int numProcesses) {
    printf("\nProcess Times:\n");
    for (int i = 0; i < numProcesses; i++) {
        printf("%s: ReturnTime = %d, WaitTime = %d\n", processName[i], returnTime[i], waitingTime[i]);
    }
}

int main() {
    int numProcesses = 5;

    strcpy(processName[0], "P1");
    arrivalTime[0] = 0;
    burstTime[0] = 10;

    strcpy(processName[1], "P2");
    arrivalTime[1] = 1;
    burstTime[1] = 28;

    strcpy(processName[2], "P3");
    arrivalTime[2] = 2;
    burstTime[2] = 6;

    strcpy(processName[3], "P4");
    arrivalTime[3] = 3;
    burstTime[3] = 4;

    strcpy(processName[4], "P5");
    arrivalTime[4] = 4;
    burstTime[4] = 14;

    for (int i = 0; i < numProcesses; i++) {
        remainingTime[i] = burstTime[i];
    }

    int currentTime = 0;             
    int completedProcesses = 0;     
    int currentProcessIndex = -1;    

    int ganttChartProcesses[20];
    int ganttChartStartTimes[20];
    int ganttChartEndTimes[20];
    int numGanttChartEntries = 0;   

    while (completedProcesses < numProcesses) {
        int shortestProcessIndex = -1;
        int shortestRemainingTime = 2147483647;

        for (int i = 0; i < numProcesses; i++) {
            if (arrivalTime[i] <= currentTime && remainingTime[i] < shortestRemainingTime && remainingTime[i] > 0) {
                shortestProcessIndex = i;
                shortestRemainingTime = remainingTime[i];
            }
        }

        if (shortestProcessIndex != -1) {
            if (currentProcessIndex != shortestProcessIndex) {
                if (currentProcessIndex != -1) {
                    endingTime[currentProcessIndex] = currentTime;
                    ganttChartEndTimes[numGanttChartEntries - 1] = currentTime;
                    enqueueProcess(currentProcessIndex);
                }
                currentProcessIndex = shortestProcessIndex;
                startingTime[currentProcessIndex] = currentTime;
                ganttChartProcesses[numGanttChartEntries] = currentProcessIndex;
                ganttChartStartTimes[numGanttChartEntries] = currentTime;
                numGanttChartEntries++;
            }

            remainingTime[currentProcessIndex]--;
            currentTime++;

            if (remainingTime[currentProcessIndex] == 0) {
                endingTime[currentProcessIndex] = currentTime;
                ganttChartEndTimes[numGanttChartEntries - 1] = currentTime;
                returnTime[currentProcessIndex] = endingTime[currentProcessIndex] - arrivalTime[currentProcessIndex];
                waitingTime[currentProcessIndex] = returnTime[currentProcessIndex] - burstTime[currentProcessIndex];
                completedProcesses++;
                currentProcessIndex = -1;
            }
        }
        else {
            currentTime++;
        }
    }
    printGanttChart(numProcesses, ganttChartProcesses, ganttChartStartTimes, ganttChartEndTimes, numGanttChartEntries);

    printProcessTimes(numProcesses);

    int totalReturnTime = 0;
    int totalWaitingTime = 0;
    for (int i = 0; i < numProcesses; i++) {
        totalReturnTime += returnTime[i];
        totalWaitingTime += waitingTime[i];
    }
    double avgReturnTime = (double)totalReturnTime / numProcesses;
    double avgWaitingTime = (double)totalWaitingTime / numProcesses;

    printf("\nAverage ReturnTime: %.2lf\n", avgReturnTime);
    printf("Average WaitTime: %.2lf\n", avgWaitingTime);

    return 0;
}