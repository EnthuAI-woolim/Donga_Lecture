#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char processNames[5][3];    
int arrivalTimes[5];       
int burstTimes[5];          


typedef struct Node {
    int processIndex;      
    struct Node* next;      
} Node;


Node* queueFront = NULL;    
Node* queueRear = NULL;     


int isQueueEmpty() {
    return (queueFront == NULL);    
}

void enqueueProcess(int processIndex) {
    Node* newNode = (Node*)malloc(sizeof(Node));    
    newNode->processIndex = processIndex;           
    newNode->next = NULL;                          

    if (isQueueEmpty()) {          
        queueFront = newNode;        
        queueRear = newNode;
    }
    else {                    
        queueRear->next = newNode;   
        queueRear = newNode;        
    }
}

int dequeueProcess() {
    if (isQueueEmpty()) {                      
        printf("Queue is empty. Cannot dequeue.\n");
        return -1;
    }

    Node* temp = queueFront;                    
    int processIndex = temp->processIndex;       
    queueFront = queueFront->next;               

    if (queueFront == NULL) {                   
        queueRear = NULL;                       
    }

    free(temp);                                 
    return processIndex;                         
}


void printGanttChart(int numProcesses) {
    int currentTime = 0;
    printf("Gantt Chart:\n");
    for (int i = 0; i < numProcesses; i++) {
        int processIndex = dequeueProcess();
        printf("%s (%d-%d)\n", processNames[processIndex], currentTime, currentTime + burstTimes[processIndex]);
        currentTime += burstTimes[processIndex];
        enqueueProcess(processIndex);    
    }
}

void printProcessTimes(int numProcesses, int* waitTime, int* returnTime) {
    printf("\nProcess Times:\n");
    for (int i = 0; i < numProcesses; i++) {
        int processIndex = dequeueProcess();
        printf("%s: ReturnTime = %d, WaitTime = %d\n", processNames[processIndex], returnTime[processIndex], waitTime[processIndex]);
        enqueueProcess(processIndex);     
    }
}

int main() {
    int numProcesses = 5;

    strcpy(processNames[0], "P1");
    arrivalTimes[0] = 0;
    burstTimes[0] = 10;

    strcpy(processNames[1], "P2");
    arrivalTimes[1] = 1;
    burstTimes[1] = 28;

    strcpy(processNames[2], "P3");
    arrivalTimes[2] = 2;
    burstTimes[2] = 6;

    strcpy(processNames[3], "P4");
    arrivalTimes[3] = 3;
    burstTimes[3] = 4;

    strcpy(processNames[4], "P5");
    arrivalTimes[4] = 4;
    burstTimes[4] = 14;

    for (int i = 0; i < numProcesses; i++) {
        enqueueProcess(i);
    }

    int waitTime[5] = { 0 };
    int returnTime[5] = { 0 };

 
    int currentTime = 0;
    for (int i = 0; i < numProcesses; i++) {
        int processIndex = dequeueProcess();

        if (currentTime < arrivalTimes[processIndex]) {
            currentTime = arrivalTimes[processIndex];
        }

        waitTime[processIndex] = currentTime - arrivalTimes[processIndex];
        currentTime += burstTimes[processIndex];
        returnTime[processIndex] = currentTime - arrivalTimes[processIndex];

        enqueueProcess(processIndex);    
    }

    int totalReturnTime = 0;
    int totalWaitTime = 0;
    for (int i = 0; i < numProcesses; i++) {
        totalReturnTime += returnTime[i];
        totalWaitTime += waitTime[i];
    }

    double avgReturnTime = (double)totalReturnTime / numProcesses;
    double avgWaitTime = (double)totalWaitTime / numProcesses;

    printGanttChart(numProcesses);

   
    printProcessTimes(numProcesses, waitTime, returnTime);


    printf("\nAverage ReturnTime: %.2lf\n", avgReturnTime);
    printf("Average WaitTime: %.2lf\n", avgWaitTime);

    return 0;
}