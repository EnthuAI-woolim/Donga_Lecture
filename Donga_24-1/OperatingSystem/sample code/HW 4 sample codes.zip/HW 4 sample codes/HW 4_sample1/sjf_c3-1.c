#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

char processNames[5][3];
int arrivalTimes[5];
int burstTimes[5];
int remainingTimes[5];

typedef struct Node {
    int processIndex;
    struct Node* next;
} Node;

Node* queueFront = NULL;
Node* queueRear = NULL;

pthread_mutex_t queueMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t queueCondition = PTHREAD_COND_INITIALIZER;

int isQueueEmpty() {
    return (queueFront == NULL);
}

void enqueueProcess(int processIndex) {
    pthread_mutex_lock(&queueMutex);

    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->processIndex = processIndex;
    newNode->next = NULL;

    if (isQueueEmpty()) {
        queueFront = newNode;
        queueRear = newNode;
    }
    else {
        queueRear->next = newNode;
        queueRear = newNode;
    }

    pthread_cond_signal(&queueCondition);
    pthread_mutex_unlock(&queueMutex);
}

int dequeueProcess() {
    pthread_mutex_lock(&queueMutex);

    while (isQueueEmpty()) {
        pthread_cond_wait(&queueCondition, &queueMutex);
    }

    Node* temp = queueFront;
    int processIndex = temp->processIndex;

    queueFront = queueFront->next;
    if (queueFront == NULL) {
        queueRear = NULL;
    }

    free(temp);

    pthread_mutex_unlock(&queueMutex);

    return processIndex;
}

void* processFunction(void* arg) {
    int processIndex = *((int*)arg);

    for (int i = 1; i <= burstTimes[processIndex]; ++i) {
        pthread_mutex_lock(&queueMutex);

        if (remainingTimes[processIndex] > 0) {
            printf("%s: %d × %d = %d\n", processNames[processIndex], i, processIndex + 1, i * (processIndex + 1));
            remainingTimes[processIndex]--;
        }

        pthread_mutex_unlock(&queueMutex);

        sched_yield();
    }

    return NULL;
}

int main() {
    pthread_t threads[5];

    strcpy(processNames[0], "P1");
    arrivalTimes[0] = 0;
    burstTimes[0] = 10;

    strcpy(processNames[1], "P2");
    arrivalTimes[1] = 1;
    burstTimes[1] = 28;

    strcpy(processNames[2], "P3");
    arrivalTimes[2] = 2;
    burstTimes[2] = 6;

    strcpy(processNames[3], "P4");
    arrivalTimes[3] = 3;
    burstTimes[3] = 4;

    strcpy(processNames[4], "P5");
    arrivalTimes[4] = 4;
    burstTimes[4] = 14;

    for (int i = 0; i < 5; i++) {
        remainingTimes[i] = burstTimes[i];
    }

    for (int i = 0; i < 5; i++) {
        enqueueProcess(i);
    }

    for (int i = 0; i < 5; ++i) {
        int* processIndexPtr = (int*)malloc(sizeof(int));
        *processIndexPtr = i;
        pthread_create(&threads[i], NULL, processFunction, processIndexPtr);
    }

    for (int i = 0; i < 5; ++i) {
        pthread_join(threads[i], NULL);
    }

    return 0;
}