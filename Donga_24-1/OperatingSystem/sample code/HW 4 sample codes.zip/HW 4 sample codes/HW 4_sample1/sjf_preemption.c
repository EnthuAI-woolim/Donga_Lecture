#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <stdbool.h> 

typedef struct Process {
    char name[3];
    int arrival_time;
    int burst_time;
    int remaining_time;
    int waiting_time;
    int return_time;
    int start_time;
    int end_time;
    struct Process* next;
} Process;

Process* head = NULL;

Process* createProcess(const char* name, int arrival_time, int burst_time) {
    Process* newProcess = (Process*)malloc(sizeof(Process));
    strcpy(newProcess->name, name);
    newProcess->arrival_time = arrival_time;
    newProcess->burst_time = burst_time;
    newProcess->remaining_time = burst_time;
    newProcess->waiting_time = 0;
    newProcess->return_time = 0;
    newProcess->start_time = 0;
    newProcess->end_time = 0;
    newProcess->next = NULL;
    return newProcess;
}

void insertProcess(Process* process) {
    if (head == NULL || process->arrival_time < head->arrival_time) {
        process->next = head;
        head = process;
    }
    else {
        Process* current = head;
        while (current->next != NULL && current->next->arrival_time <= process->arrival_time) {
            current = current->next;
        }
        process->next = current->next;
        current->next = process;
    }
}

Process* findShortestRemainingTimeProcess(int current_time) {
    Process* shortestProcess = NULL;
    Process* current = head;
    while (current != NULL) {
        if (current->arrival_time <= current_time && current->remaining_time > 0 &&
            (shortestProcess == NULL || current->remaining_time < shortestProcess->remaining_time)) {
            shortestProcess = current;
        }
        current = current->next;
    }
    return shortestProcess;
}

Process* findNextProcess(int current_time) {
    Process* nextProcess = NULL;
    Process* current = head;
    int shortest_remaining_time = INT_MAX;

    while (current != NULL) {
        if (current->arrival_time <= current_time && current->remaining_time > 0 &&
            current->remaining_time < shortest_remaining_time) {
            nextProcess = current;
            shortest_remaining_time = current->remaining_time;
        }
        else if (current->arrival_time <= current_time && current->remaining_time > 0 &&
            current->remaining_time == shortest_remaining_time &&
            current->arrival_time < nextProcess->arrival_time) {
            nextProcess = current;
        }
        current = current->next;
    }
    return nextProcess;
}

void printGanttChart(Process* gantt_chart[], int size) {
    printf("Gantt Chart:\n");
    int prev_start_time = -1;
    int prev_end_time = -1;
    char prev_process_name[3] = "";

    for (int i = 0; i < size; i++) {
        if (gantt_chart[i] != NULL) {
            if (strcmp(gantt_chart[i]->name, prev_process_name) != 0 || gantt_chart[i]->start_time != prev_start_time) {
                printf("%s (%d-%d)\n", gantt_chart[i]->name, gantt_chart[i]->start_time, gantt_chart[i]->end_time);
                strcpy(prev_process_name, gantt_chart[i]->name);
                prev_start_time = gantt_chart[i]->start_time;
                prev_end_time = gantt_chart[i]->end_time;
            }
        }
    }
}

void printProcessTimes(Process* processes[], int numProcesses) {
    printf("\nProcess Times:\n");
    for (int i = 0; i < numProcesses; i++) {
        printf("%s: ReturnTime = %d, WaitTime = %d\n", processes[i]->name, processes[i]->return_time, processes[i]->waiting_time);
    }
}

void printAverageTimes(Process* processes[], int numProcesses) {
    int totalReturnTime = 0;
    int totalWaitingTime = 0;
    for (int i = 0; i < numProcesses; i++) {
        totalReturnTime += processes[i]->return_time;
        totalWaitingTime += processes[i]->waiting_time;
    }
    double avgReturnTime = (double)totalReturnTime / numProcesses;
    double avgWaitingTime = (double)totalWaitingTime / numProcesses;
    printf("\nAverage ReturnTime: %.2lf\n", avgReturnTime);
    printf("Average WaitTime: %.2lf\n", avgWaitingTime);
}

int main() {
    Process* processes[5];
    processes[0] = createProcess("P1", 0, 10);
    processes[1] = createProcess("P2", 1, 28);
    processes[2] = createProcess("P3", 2, 6);
    processes[3] = createProcess("P4", 3, 4);
    processes[4] = createProcess("P5", 4, 14);

    for (int i = 0; i < 5; i++) {
        insertProcess(processes[i]);
    }

    int numProcesses = 5;
    int currentTime = 0;
    int completedProcesses = 0;
    Process* gantt_chart[100] = { NULL };
    int gantt_chart_size = 0;
    Process* currentProcess = NULL;

    while (completedProcesses < numProcesses) {
        Process* nextProcess = findNextProcess(currentTime);

        if (nextProcess != NULL) {
            if (currentProcess != nextProcess) {
                if (currentProcess != NULL) {
                    currentProcess->end_time = currentTime;
                    gantt_chart[gantt_chart_size++] = currentProcess;
                }
                nextProcess->start_time = currentTime;
                gantt_chart[gantt_chart_size++] = nextProcess;
            }

            nextProcess->remaining_time--;
            currentTime++;
            currentProcess = nextProcess;

            if (nextProcess->remaining_time == 0) {
                nextProcess->end_time = currentTime;
                nextProcess->return_time = nextProcess->end_time - nextProcess->arrival_time;
                nextProcess->waiting_time = nextProcess->return_time - nextProcess->burst_time;
                completedProcesses++;
            }
        }
        else {
            currentTime++;
        }
    }

    if (currentProcess != NULL) {
        currentProcess->end_time = currentTime;
        gantt_chart[gantt_chart_size++] = currentProcess;
    }

    printGanttChart(gantt_chart, gantt_chart_size);
    printProcessTimes(processes, numProcesses);
    printAverageTimes(processes, numProcesses);

    return 0;
}
