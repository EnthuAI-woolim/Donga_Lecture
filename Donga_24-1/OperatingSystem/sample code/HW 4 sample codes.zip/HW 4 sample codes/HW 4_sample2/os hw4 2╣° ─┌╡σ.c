#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include "gant.h"

#define MAX_GANT 11

// 현재 작업중인 스레드 번호 저장
int turn = 1;
// 전체 작업 시간을 나타내는 변수
int t = 0;
// 스레드 작업 진행도를 저장한 배열
int var[6] = {0, 1,1,1,1,1};
// 스레드 작업 함수, turn 변수로 상호배제 된다.
void *work(void *arg) {
        int* arr = (int*)arg;
        // 작업 수행
        while(var[arr[0]] <= arr[1]) {
                while(turn == arr[0] && var[arr[0]] <= arr[1]) {
                        printf("P%d : %d X %d = %d\n", arr[0], var[arr[0]], arr[0], var[arr[0]] * arr[0]);
                        var[arr[0]]++;
                        t++;
                }
        }
        pthread_exit(NULL);
}

// 연결 리스트 구현
typedef struct node {
        int tnum;       // 스레드 번호를 저장하는 int형 변수
        struct node* next;   // 다음 노드를 가리키는 포인터
} Node;
// 현재 작업 실행 시간이 가장 적은 것부터 정렬되도록 삽입하는 함수
void insert(Node** head, int tnum, int warr[6][3]) {
        Node* new_node = (Node*)malloc(sizeof(Node));
        new_node->tnum = tnum;
        // head에 넣기
        if(*head == NULL) {
                new_node->next = *head;
                *head = new_node;
                return;
        }
        // 조건에 맞는 삽입 위치를 찾기
        Node* current = *head;
        while (current->next != NULL &&
                        warr[current->next->tnum][1] - var[current->next->tnum] < warr[tnum][1]-var[tnum]) {
                current = current->next;
        }
        // 삽입
        new_node->next = current->next;
        current->next = new_node;
}
// 연결 리스트의 head 부분을 지우고 해당 스레드 번호를 반환
int delete_head(Node** head) {
        if(*head == NULL) {
                printf("list is empty.\n");
                return -1;
        } else {
                Node* temp = *head;
                int ret = temp->tnum;
                *head = (*head)->next;
                free(temp);
                return ret;
        }
}
int main() {
        // 스레드 작업 배열, [i][0] = 스레드 번호, [i][1] = 작업 시간, [i][2] = 도착 시간
        int warr[6][3] = { {0,0,0}, {1,10,0}, {2,28,1}, {3,6,2}, {4,4,3}, {5,14,4} };
        // isinlist[i] = 0이면 준비 큐에 없고, 1이면 준비 큐에 있다.
        int isinlist[6] = {0,0,0,0,0,0};
        pthread_t tarr[6];
        // 준비 큐
        Node* head = NULL;
        // 작업 종료된 스레드의 개수
        int threadCnt = 0;
        // 간트 차트
        Gant g;
        // 맨 첫번째 스레드를 실행
        pthread_create(&tarr[1], NULL, work, warr[1]);
        gant_push_start(&g, 1, 0);
        turn = 1;
        insert(&head, 1, warr);
        isinlist[1] = 1;
        while(threadCnt < 5) {
                // 준비 큐에 새로운 작업 추가하기
                for(int i = 1; i <= 5; i++) {
                        if(warr[i][2] <= t && isinlist[i] == 0) {
                                insert(&head, i, warr);
                                isinlist[i] = 1;
                        }
                }
                // 문맥 교환이 필요한 상황
                if(turn != head->tnum) {
                        int new_th = head->tnum;
                        // 스레드 생성하기
                        if(var[new_th] == 1) {
                               pthread_create(&tarr[new_th], NULL, work, warr[new_th]);
                        }
                        turn = new_th;
                        gant_swap(&g, t, new_th);
                }
                // 스레드 작업 종료
                if(var[turn] > warr[turn][1]) {
                        pthread_join(tarr[turn], NULL);
                        printf("----- P%d work end -----\n", turn);
                        threadCnt++;
                        delete_head(&head);
                }
                // 현재 스레드가 작업을 1회 수행하고 t를 증가시킬 때까지 잠시 대기
                for(int i = 0; i < 100; i++) {}
        }
        gant_push_end(&g, t);

        gant_print(&g, warr);
        int timearr[6][2];
        double retsum = 0;
        double waitsum = 0;
        for(int i = 1; i <= 5; i++) {
                timearr[i][0] = gant_timeCal(&g, i, warr[i][2], 0);
                timearr[i][1] = gant_timeCal(&g, i, warr[i][2], 1);
                retsum += timearr[i][0];
                waitsum += timearr[i][1];
                printf("P%d 반환 시간 : %d, 대기 시간 : %d\n", i, timearr[i][0], timearr[i][1]);
        }
        printf("평균 반환 시간 : %.1lf, 평균 대기 시간 : %.1lf\n", retsum/5, waitsum/5);

        return 0;
}