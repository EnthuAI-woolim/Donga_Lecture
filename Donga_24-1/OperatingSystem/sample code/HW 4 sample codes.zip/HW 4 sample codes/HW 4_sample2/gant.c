// gant.c
#include "gant.h"
#include <stdio.h>

void init_gant(Gant* g) {
    g->iter = 0;
}

void gant_push_start(Gant* g, int tnum, int startTime) {
    g->tnum[g->iter] = tnum;
    g->startTime[g->iter] = startTime;
}

void gant_swap(Gant* g, int exitTime, int next_tnum) {
    g->exitTime[g->iter] = exitTime;
    g->iter++;
    g->tnum[g->iter] = next_tnum;
    g->startTime[g->iter] = exitTime;
}

void gant_push_end(Gant* g, int exitTime) {
    g->exitTime[g->iter] = exitTime;
    g->iter++;
}

int gant_timeCal(Gant* g, int tnum, int arrive_time, int type) {
    int a = 0;
    int timearr[2][2];
    for(int i = 0; i < g->iter; i++) {
        if(g->tnum[i] == tnum) {
            timearr[a][0] = g->startTime[i];
            timearr[a][1] = g->exitTime[i];
            a++;
        }
    }
    if(type == 0) {
        if(a == 2) return (timearr[1][1] - arrive_time);
        return (timearr[0][1] - arrive_time);
    } else {
        if(a == 2) return (timearr[1][0]-timearr[0][1]);
        return (timearr[0][0] - arrive_time);
    }
}

void gant_print(Gant* g, int warr[6][3]) {
    printf("-----------------------------\n");
    for(int i = 0; i < g->iter; i++) {
        printf("P%d (%d-%d)\n", g->tnum[i], g->startTime[i], g->exitTime[i]);
    }
    printf("-----------------------------\n");
}