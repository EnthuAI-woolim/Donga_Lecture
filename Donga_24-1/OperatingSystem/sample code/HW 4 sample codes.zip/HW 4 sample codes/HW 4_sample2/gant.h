// gant.h
#ifndef GANT_H
#define GANT_H

#define MAX_GANT 10  // 필요에 따라 MAX_GANT 값 조절

typedef struct {
    int iter;
    int tnum[MAX_GANT];
    int startTime[MAX_GANT];
    int exitTime[MAX_GANT];
} Gant;

void init_gant(Gant* g);
void gant_push_start(Gant* g, int tnum, int startTime);
void gant_swap(Gant* g, int exitTime, int next_tnum);
void gant_push_end(Gant* g, int exitTime);
int gant_timeCal(Gant* g, int tnum, int arrive_time, int type);
void gant_print(Gant* g, int warr[6][3]);

#endif