#include <stdio.h>
#include <time.h>


int main() {
  clock_t start_time = clock();

  printf("단일 프로세스 출력\n");
  for (int i = 1; i <= 7000; i++) printf("%5d", i);
  printf("\n");

  clock_t end_time = clock(); 
  double elapsed_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;

  printf("프로세스 종료까지 소요된 시간: %.7f 초\n", elapsed_time);

  return 0;
}