#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <sys/wait.h>

#define NUM_PER_PROCESS 100

void settingStartNum();
int generatingFork();
void calculation(int base_num);

int base_num[10];

int main() {
  clock_t start_time = clock();

  settingStartNum();
  generatingFork();

  clock_t end_time = clock(); 
  double elapsed_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;

  printf("프로세스 종료까지 소요된 시간: %.7f 초\n", elapsed_time);
    
  return 0;
}

// 시작 숫자 세팅 함수
void settingStartNum() {
  for (int i = 0; i < 10; i++) 
    base_num[i] = (i * NUM_PER_PROCESS) + 1;
}

// fork 실행 함수
int generatingFork() {
  pid_t pid1, pid2, pid3, pid4, pid5, pid6, pid7, pid8, pid9;

  pid1 = fork();

  // 프로세스 오류 처리
  if (pid1 < 0) {
    printf("fork 실패\n");
    return 1;
  } 

  if (pid1 == 0) {
    pid2 = fork();

    // 프로세스 오류 처리
    if (pid2 < 0) {
      printf("fork 실패\n");
      return 1;
    }

    if (pid2 == 0) {
      pid4 = fork();

      // 프로세스 오류 처리
      if (pid4 < 0) {
        printf("fork 실패\n");
        return 1;
      }

      if (pid4 == 0) {
        printf("프로세스 1\n");
        calculation(base_num[0]);
      } else {
        printf("프로세스 2\n");
        calculation(base_num[1]);
      }
    } else {
      pid5 = fork();

      if (pid5 < 0) {
        printf("fork 실패\n");
        return 1;
      }

      if (pid5 == 0) {
        printf("프로세스 3\n");
        calculation(base_num[2]);
      } else {
        printf("프로세스 4\n");
        calculation(base_num[3]);
      }
    }
  } else {
    pid3 = fork();

    if (pid3 == 0) {
      pid6 = fork();

      // 프로세스 오류 처리
      if (pid6 < 0) {
        printf("fork 실패\n");
        return 1;
      }

      if (pid6 == 0) {
        printf("프로세스 5\n");
        calculation(base_num[4]);
      } else {
        printf("프로세스 6\n");
        calculation(base_num[5]);
      }
    } else {
      pid7 = fork();

      // 프로세스 오류 처리
      if (pid7 < 0) {
        printf("fork 실패\n");
        return 1;
      }

      if (pid7 == 0) {
        pid8 = fork();

        // 프로세스 오류 처리
        if (pid8 < 0) {
          printf("fork 실패\n");
          return 1;
        }
        
        if (pid8 == 0) {
          printf("프로세스 7\n");
          calculation(base_num[6]);
        } else {
          printf("프로세스 8\n");
          calculation(base_num[7]);
        }
      } else {
        pid9 = fork();

        // 프로세스 오류 처리
        if (pid9 < 0) {
          printf("fork 실패\n");
          return 1;
        }

        if (pid9 == 0) {
          printf("프로세스 9\n");
          calculation(base_num[8]);
        } else {
          printf("프로세스 10\n");
          calculation(base_num[9]);
        }
      }
    }
  }
  
  // 모든 자식 프로세스가 완료될 때까지 대기
  for (int i = 0; i < 9; i++) 
    wait(NULL);

  return 0;
}

// 숫자 계산 함수
void calculation(int base_num) {
  int start = base_num;
  int end = base_num + NUM_PER_PROCESS - 1;
  
  printf("시작 번호: %d(%d), 끝 번호: %d(%d)\n", start * 7, start, end * 7, end);
  for (int j = start; j <= end; ++j) printf("%5d", j * 7);
  printf("\n\n");
}

